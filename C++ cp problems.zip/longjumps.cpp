#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, i;
		cin >> n;
		ll a[n];
		rep(i, 0, n) cin >> a[i];
		ll dp[n + 1];
		memset(dp, 0, sizeof(dp));
		ll ans = 0;
		for (i = n - 1; i >= 0; i--) {
			dp[i + 1] = i + 1 + a[i] > n ? a[i] : a[i] + dp[i + 1 + a[i]];
			ans = max(dp[i + 1], ans);
		}
		cout << ans << line;




	}
}