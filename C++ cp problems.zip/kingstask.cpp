#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, x, i, cnt = -1;
	cin >> n;
	x = 2 * n;
	if (n % 2 == 0) {
		x = 4;
	}
	n = n * 2;
	ll a[n];
	rep(i, 0, n) cin >> a[i];
	for (i = 0; i < x; i++) {
		if (is_sorted(a, a + n)) {
			cnt = i;
			break;
		}
		if (i % 2)for (ll j = 0; j < n / 2; j++)swap(a[j], a[j + (n / 2)]);
		else for (ll j = 0; j < n; j += 2)swap(a[j], a[j + 1]);
	}
	cout << min(cnt, x - cnt);
}