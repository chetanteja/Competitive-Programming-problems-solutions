#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, x;
	cin >> n;
	string s;
	cin >> s;
	ll a[n];
	rep(i, 0, n) {
		cin >> a[i];
	}
	int b[n] = {0};
	ll i = 0;
	while (1) {
		if (i < 0 || i > n - 1) {
			goto done;
		}
		if (b[i] == 1) {
			break;
		}
		b[i] = 1;
		if (s[i] == '>') {
			i = i + a[i];
		}
		else {
			i = i - a[i];
		}
	}
	cout << "INFINITE\n";
	return 0;
done:
	cout << "FINITE\n";
}