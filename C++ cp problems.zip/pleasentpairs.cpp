#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x = 0;
		cin >> n;
		ll a[n];
		map<ll, ll>m;
		rep(i, 0, n) {
			cin >> a[i];
			m[a[i]] = i + 1;
		}
		sort(a, a + n);
		for (ll i = 0; i < n; i++) {
			for (ll j = i + 1; j < n; j++) {
				if (a[i]*a[j] >= 2 * n) break;
				//cout << "hell\n";
				if (m[a[i]] + m[a[j]] == a[i]*a[j]) x++;
			}
		}
		cout << x << line;

	}
}