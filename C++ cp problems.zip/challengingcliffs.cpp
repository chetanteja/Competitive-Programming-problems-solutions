#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, min = INT_MAX;
		cin >> n;
		vector<ll> a;
		rep(i, 0, n) {
			cin >> x;
			a.push_back(x);
		}
		sort(a.begin(), a.end());
		// rep(i, 0, n) {
		// 	cout << a[i] << " ";
		// }
		rep(i, 1, n) {
			if (a[i] - a[i - 1] < min) {
				x = i;
				min = a[i] - a[i - 1];
			}
		}
		//cout << line << x << line;
		// a.erase(a.begin() + x - 1);
		// a.erase(a.begin() + x - 1);
		cout << a[x - 1] << " ";
		rep(i, x + 1, n) {
			cout << a[i] << " ";
		}
		rep(i, 0, x - 1) {
			cout << a[i] << " ";
		}
		cout << a[x] << line;


	}
}