#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl

int main() {
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    int t;
    cin >> t;
    while (t--) {
        ll x = 0, y, z, n, i;
        cin >> n;
        int a[n];
        for (int i = 0; i < n; ++i)
        {
            cin >> a[i];
        }
        sort(a, a + n);
        for ( i = 0; i < n; ++i)
        {
            /* code */
            if (a[i] <= 0) {
                x++;
            }
            else {
                break;
            }
        }
        if ( i == n) {
            printf("%d\n", n);
            continue;
        }
        int min = 2e9;
        for (int j = 1; j < i; ++j)
            min = std::min(min , a[j] - a[j - 1]);
        if (a[i] <= min)
            printf("%d\n", i + 1);
        else
            printf("%d\n", i);

        //cout << x << line;

    }
}