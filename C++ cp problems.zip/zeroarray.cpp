#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, x = 0;
	cin >> n;
	ll a[n];
	rep(i, 0, n) cin >> a[i], x += a[i];
	if (x % 2) goto done;
	rep(i, 0, n) {
		if (a[i] > x / 2) {
			goto done;
		}
	}
	cout << "YES";
	return 0;
done:;
	cout << "NO";
	// sort(a, a + n);
	// x = a[0];
	// for (int i = 1; i < n; i++) {
	// 	a[i] -= x;
	// 	x = a[i];
	// }
	// if(a[n-1]!=0){
	// 	cout<<"NO\n";
	// }
}