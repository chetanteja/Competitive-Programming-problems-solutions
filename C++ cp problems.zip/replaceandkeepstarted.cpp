#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, x, q, k, l, r;
	cin >> n >> q >> k;
	ll a[n];
	rep(i, 0, n) cin >> a[i];
	while (q--) {
		cin >> l >> r;
		x = k + a[r - 1] - a[l - 1] - 2 * (r - l) - 1;
		cout << x << line;

	}
}