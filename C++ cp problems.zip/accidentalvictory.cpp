#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, i;
		cin >> n;
		vector<pair<ll, ll>>a(n);
		rep(i, 0, n) {
			cin >> a[i].first;
			a[i].second = i;
			//cout << a[i].first << " " << a[i].second << line;
		}
		//cout << line;
		sort(a.begin(), a.end());
		// rep(i, 0, n) {
		// 	cout << a[i].first << " " << a[i].second << line;
		// }
		// cout << line;
		vector<ll>ans;
		vector<ll>prefix(n + 1, 0);
		for (ll i = 0; i < n; i++) {
			prefix[i + 1] = prefix[i] + a[i].first;
		}
		ans.push_back(a[n - 1].second + 1);
		for (ll i = n - 2; i >= 0; i--) {
			if (prefix[i + 1] >= a[i + 1].first) {
				ans.push_back(a[i].second + 1);
			}
			else {
				break;
			}
		}
		sort(ans.begin(), ans.end());
		cout << (ans.size()) << endl;
		for (auto &x : ans) {
			cout << x << " ";
		}
		cout << endl;
	}
}