#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		string s;
		ll n;
		cin >> s;
		n = s.size();
		ll x = (n - 2);
		//cout << x << line;
		if (n > 10) {
			cout << s[0] << x << s[n - 1] << line;
		}
		else {
			cout << s << line;
		}

	}
}