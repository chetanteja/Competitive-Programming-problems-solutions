#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x = 0;
		cin >> n;
		ll a[n];
		rep(i, 0, n) {
			cin >> a[i];
			x ^= a[i];
		}
		if (x == 0) {
			cout << "YES\n";
			continue;
		}
		ll cur = 0, c = 0;
		for (int i = 0; i < n; ++i) {
			cur ^= a[i];
			if (cur == x) c++, cur = 0;
		}
		if (c >= 3) cout << "YES\n";
		else cout << "NO\n";
	}
}