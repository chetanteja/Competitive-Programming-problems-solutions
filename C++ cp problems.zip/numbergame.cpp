#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

bool is_prime(int n)
{
	if (n <= 1)
		return false;
	if (n <= 3)
		return true;
	if (n % 2 == 0 || n % 3 == 0)
		return false;

	for (int i = 5; i * i <= n; i = i + 6)
		if (n % i == 0 || n % (i + 2) == 0)
			return false;

	return true;
}

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		//cout << line;
		ll n, x;
		cin >> n;
		if (n == 1) {
			cout 	<< "FastestFinger" << line;
			continue;
		}
		if (n % 2 != 0 || n == 2) {
			cout << "Ashishgup" << line;
			continue;
		}
		x = 1;
		while (n % 2 == 0) {
			//cout << n << line;
			n = n / 2;
			x = 2 * x;
		}
		//cout << n;
		if (n == 1) {
			cout << "FastestFinger" << line;
			continue;
		}
		//cout << x << n << line;
		if (is_prime(n)) {
			if (x == 2) {
				cout << "FastestFinger" << line;
			}
			else {
				cout << "Ashishgup" << line;
			}
		}
		else {
			cout << "Ashishgup" << line;
		}

	}
}