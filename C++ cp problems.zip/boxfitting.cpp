#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)
int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, w, h, i;
		cin >> n >> w;
		multiset<ll> a;
		for (int i = 0; i < n; i++)
		{
			//
			cin >> x;
			//cout << "HELL" << line;
			a.insert(x);
			//cout << "HELLO" << line;
		}
		h = 0;
		//n--;
		//cout << w;
		while (!a.empty()) {

			//cout << "here" << line << a.size();
			//cout << *a.end() << line;
			//ll s = a.size();
			//cout << a[(a.size()) - 1] << "size" << line;
			x = w - *a.rbegin();
			a.erase(--a.end());
			//cout << x << line;
			//a.erase(a.begin() + size-1);
			auto it = a.upper_bound(x);
			//cout << a.size();
			//s = a.size();
			//cout << i << line;
			while (it != a.begin()) {
				--it;
				x = x - *it;
				a.erase(it);
				it = a.upper_bound(x);
				//cout << "hell";
			}
			h++;
			//cout << h;
		}


		cout << h << line;
		a.clear();

	}
}