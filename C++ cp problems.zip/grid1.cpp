#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, m, i, j, mod = 1e9 + 7;
	char x;
	cin >> n >> m;
	ll dp[n][m];
	char a[n][m];
	memset(dp, 0, sizeof(dp));
	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			cin >> a[i][j];
		}
	}
	dp[0][0] = 1;
	for (i = 1; i < n && a[i][0] == '.'; i++) dp[i][0] = dp[i - 1][0];
	for (i = 1; i < m && a[0][i] == '.'; i++) dp[0][i] = dp[0][i - 1];
	for (i = 1; i < n; i++) {
		for (j = 1; j < m; j++) {
			if (a[i][j] == '.') {
				dp[i][j] = (dp[i - 1][j] + dp[i][j - 1]) % mod;
			}
		}
	}
	cout << dp[n - 1][m - 1] << line;




}