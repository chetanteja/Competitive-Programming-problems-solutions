#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x;
		cin >> n;
		ll a[n];
		x = (n * 3);
		cout << x << line;
		rep(i, 0, n) cin >> a[i];
		for (ll i = 0; i < n; i += 2) {
			rep(j, 0, 3) {
				cout << "2 " << i + 1 << " " << i + 2 << line;
				cout << "1 " << i + 1 << " " << i + 2 << line;
			}
		}


	}
}