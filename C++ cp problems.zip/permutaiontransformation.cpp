#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

void build(int l, int r, vector<int> const &a, vector<int> &d, int curD) {
	if (r < l) {
		return;
	}
	if (l == r) {
		d[l] = curD;
		return;
	}
	int m = l;
	for (int i = l + 1; i <= r; i++) {
		if (a[m] < a[i]) {
			m = i;
		}
	}
	d[m] = curD;
	build(l, m - 1, a, d, curD + 1);
	build(m + 1, r, a, d, curD + 1);
}

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		int n;
		cin >> n;
		vector<int> a(n);
		for (int &x : a) {
			cin >> x;
		}
		vector<int> d(n);
		build(0, n - 1, a, d, 0);
		for (int x : d) {
			cout << x << " ";
		}
		cout << endl;




	}
}