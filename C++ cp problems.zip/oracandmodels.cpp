#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, ans = 0;
		cin >> n;
		ll a[n + 1], dp[n + 1];
		rep(i, 1, n + 1) cin >> a[i], dp[i] = 1;
		//ll dp[n + 1] = {1};
		for (int i = 1; i <= n; i++)
		{
			for (int j = i * 2; j <= n; j += i)
			{
				if (a[j] > a[i])
					dp[j] = max(dp[j], dp[i] + 1);
			}
			ans = max(ans, dp[i]);
		}
		cout << ans << line;
	}
}