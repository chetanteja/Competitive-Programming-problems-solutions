#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		int n , k;
		string s;
		cin >> n >> k;
		cin >> s;
		int ok = 1;
		for (int i = 0 ; i < k ; ++i)
			ok = ok && s[i] == s[n - i - 1];
		puts(ok && k * 2 < n ? "YES" : "NO");
	}
}