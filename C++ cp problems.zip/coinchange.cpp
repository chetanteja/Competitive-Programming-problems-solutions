#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, N;
	cin >> N >> n;
	ll a[n];
	rep(i, 0, n + 1) cin >> a[i];
	ll dp[n + 1][N + 1];
	memset(dp, 0, sizeof(dp));
	rep(i, 0, n + 1) dp[i][0] = 1;
	rep(i, 0, n + 1) dp[0][i] = 0;
	rep(i, 1, n + 1) {
		rep(j, 1, N + 1) {
			if (a[i - 1] <= j) {
				dp[i][j] =  (dp[i][j - a[i - 1]] + dp[i - 1][j]);
			}
			else {
				dp[i][j] = dp[i - 1][j];
			}
		}
	}
	// rep(i, 0, n + 1) {
	// 	rep(j, 0, N + 1) {
	// 		cout << dp[i][j] << " ";
	// 	}
	// 	cout << line;
	// }
	cout << dp[n][N];
}