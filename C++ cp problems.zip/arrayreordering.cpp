#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x = 0, y, i, j;
		cin >> n;
		ll a[n];
		vector<int> v;
		rep(i, 0, n) {
			cin >> a[i];
			if (a[i] % 2 == 0) x++;
			else v.push_back(a[i]);
		}
		ll z = 0;
		y = n - x;
		for (i = 0; i < y; i++) {
			for (j = i + 1; j < y; j++) {
				if (gcd(v[i], v[j]) == 1) {
					z++;
				}
			}
		}
		ll ans = ((n - 1) * n) / 2;
		ans -= ((y - 1) * y) / 2;
		ans += ((y * (y - 1)) / 2) - z;
		cout << ans << line;
	}
}