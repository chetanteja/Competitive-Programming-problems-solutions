#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    int n, x, i, ans = 0;
    cin >> n;
    int a[n];
    for (i = 0; i < n; i++) {
        cin >> a[i];
    }
    sort(a, a + n);
    // for(int i=0;i<n;i++){
    //     cout<<a[i];
    // }
    i = 0;
    while (a[i] < 0) {
        i++;
    }
    if (i == 0) {
        ans = a[0] + a[1];
    }
    else if (i == n - 1) {
        ans = a[n - 1] + a[n - 2];
    }
    else {
        ans = a[i] + a[i - 1];
        if (i + 1 < n) {
            ans = min(ans, a[i] + a[i + 1]);
        }
        if (i - 2 >= 0) {
            ans = min(ans, -1 * (a[i - 1] + a[i - 2]));
        }
    }
    cout << ans << line;



}