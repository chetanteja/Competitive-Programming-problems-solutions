#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n;
		cin >> n;
		ll d = 0, m = 0, c = 0, x;
		for (ll i = 2; i * i <= n; i++) {
			c = 0, x = n;
			while (x % i == 0) {c++; x = x / i;}
			if (c > m) { m = c; d = i;}
		}
		if (m == 0) m = 1;
		cout << m << endl;
		for (ll i = 1; i < m; i++) {cout << d << " ";   n = n / d;}
		cout << n << endl;
	}
}