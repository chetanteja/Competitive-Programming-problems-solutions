#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, a, b;
	cin >> n;
	ll s[n];
	a = 0; b = 0;
	rep(i, 0, n) cin >> s[i];

	for (int i = n - 1; i >= 0; i--) {
		if (a > b) {
			b += s[i];
		}
		else {
			a += s[i];
		}
	}
	cout << min(a, b) << " " << max(a, b);



}