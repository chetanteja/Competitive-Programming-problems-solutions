#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, s, flag = 0;
		cin >> n;
		ll a[2 * n];
		rep(i, 0, 2 * n) cin >> a[i];
		sort(a, a + (2 * n));

		x = 2 * n;
		s = 0;
		for (ll i = 2 * n - 1; i >= 1; i = i - 2) {

			if (a[i] - a[i - 1] != 0 || (i != 1 && a[i] == a[i - 2])) {
				flag = 1;
				cout << "NO" << line;
				goto done;
			}
			a[i] = a[i] - s;
			if (a[i] % x != 0 || a[i] <= 0) {
				flag = 1;
				cout << "NO" << line;
				goto done;
			}
			//cout << s << " " << x << " " << a[i] << line;
			s = s + 2 * (a[i] / x);
			x -= 2;


		}
		cout << "YES" << line;
done:;
	}
}