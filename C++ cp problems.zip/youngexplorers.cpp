#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, cnt = 0, y;
		cin >> n;
		ll a[n];
		rep(i, 0, n) cin >> a[i];
		sort(a, a + n);
		ll i = 0;
		y = 0;
		while (i < n) {
			y++;
			x = a[i];
			if (y == x) {
				cnt++;
				y = 0;
			}
			i++;
		}
		cout << cnt << line;

	}
}