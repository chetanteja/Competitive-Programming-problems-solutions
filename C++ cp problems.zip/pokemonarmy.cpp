#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, q;
		cin >> n >> q;
		ll a[n];
		rep(i, 0, n) cin >> a[i];
		ll dp[n + 1][2];
		dp[0][0] = -1 * INT_MAX;
		dp[0][1] = 0;
		for (int i = 0; i < n; ++i) {
			dp[i + 1][0] = max(dp[i][0], dp[i][1] + a[i]);
			dp[i + 1][1] = max(dp[i][1], dp[i][0] - a[i]);
		}
		x = max(dp[n][0], dp[n][1]);
		cout << x << line;

	}
}