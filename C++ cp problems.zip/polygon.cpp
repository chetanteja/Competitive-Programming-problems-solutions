#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, c = 0;
		cin >> n;
		char a[n][n];
		rep(i, 0, n) {
			rep(j, 0, n) {
				cin >> a[i][j];
			}
		}
		rep(i, 0, n - 1) {
			rep(j, 0, n - 1) {
				if (a[i][j] == '1') {

					if (!(a[i + 1][j] == '1' || a[i][j + 1] == '1')) {
						//cout << "Hello\n";
						c = 1;
					}

				}
			}
		}
		if (c == 0) {
			cout << "YES\n";
			continue;
		}
		cout << "NO\n";



	}
}