#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, x;
	cin >> n;
	ll a[n];
	pair<ll, ll>p;
	rep(i, 0, n) {
		cin >> a[i];
		cin >> x;
		make_pair(x, a[i]);
	}
	sort(p, p + n);
	ll N = n, j = 0, i = n - 1, ans = 0;
	while (N--) {
		x = p[j].first;
		if (p[i].second > x) {
			p[i].second -= x;
			ans += 2 * x;
			j++;
		}
		else {
			p[i].second = 0;
			ans += 2 * p[i].second;
			i--;
		}

	}

}