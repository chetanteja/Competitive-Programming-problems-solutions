#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x;
		cin >> n;
		string s, a;
		cin >> s;
		cin >> a;
		vector<ll> v;
		for (ll i = n - 1; i >= 0; i--) {
			if (a[i] != s[i]) {
				if (i) v.push_back(i + 1);
				v.push_back(1);
				if (i) v.push_back(i + 1);
			}
		}
		n = v.size();

		cout << n << " ";
		rep(i, 0, n) {
			cout << v[i] << " ";
		}

		cout << line;
	}
}