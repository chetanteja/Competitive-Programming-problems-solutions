#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, cnt = 0;
		cin >> n;
		int a[n];
		rep(i, 0, n) cin >> a[i];
		int j = 0;
		rep(i, 1, n) {
			j = i - 1;
			if (max(a[i], a[j]) > 2 * min(a[i], a[j])) {
				//cout << i << j << line;
				int k = 1;
				//float f = max(a[i], a[j]) / (k * min(a[i], a[j]));
				//cout << f << line;
				while ( max(a[i], a[j]) > 2 * k * min(a[i], a[j])) {
					k = k * 2;
					cnt++;
				}
				//cout << cnt << "hell" << line;
			}
		}
		cout << cnt << line;
	}
}