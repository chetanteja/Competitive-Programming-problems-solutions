#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, x;
	cin >> n;
	if (n % 2 == 0) {
		x = n / 2 + 1;
		cout << (n / 2 + 1)*x << line;
	}
	else {
		x = 2 * (n / 2 + 1) * (n / 2 + 2);
		cout << x << line;
	}
}