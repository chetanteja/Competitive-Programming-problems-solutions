#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, k;
		char c;
		cin >> n >> k;
		string a;
		string b;
		cin >> a;
		cin >> b;
		//cout << "Hello\n";
		map<char, ll>A, B;
		rep(i, 0, n) {
			A[a[i]]++;
		}
		rep(i, 0, n) {
			A[b[i]]--;
		}

		c = 'a' - 1;
		char j = 'a';
		ll s = 0;
		while (c <= 'z') {
			c++;
			if (A[c] % k != 0) goto done;
			s += A[c];
			if (s < 0) goto done;




// 			c++;
// 			//cout << c << line;
// 			if (A[c] == 0) {
// 				continue;
// 			}
// 			//cout << "hell";
// 			if (A[c] % k != 0) {
// 				goto done;
// 			}
// whl:
// 			while (B[j] == 0) {
// 				j++;
// 			}
// 			if (B[j] % k != 0) {
// 				goto done;
// 			}
// 			//cout << c << j;
// 			//x=(int)c;
// 			if ((int)c > (int) j) {
// 				goto done;
// 			}
// 			if (A[c] > B[j]) {
// 				A[c] -= B[j];
// 				B[j] = 0;
// 				j++;
// 				goto whl;
// 			}
// 			else {
// 				B[j] -= A[c];
// 				A[c] = 0;
// 			}


		}
		cout << "Yes\n";
		continue;

done:
		cout << "No\n";
	}
}