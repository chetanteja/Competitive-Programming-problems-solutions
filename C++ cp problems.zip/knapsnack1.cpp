#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, x, i, W;
	cin >> n >> W;
	ll val[n], wt[n];
	rep(i, 0, n) cin >> wt[i] >> val[i];
	//cout << "hello" << line;
	ll dp[n + 1][W + 1];

	memset(dp, 0, sizeof(dp));

	rep(i, 1, n + 1) {
		rep(j, 1, W + 1) {
			if (wt[i - 1] <= j) {
				dp[i][j] = max((val[i - 1] + dp[i - 1][j - wt[i - 1]]), dp[i - 1][j]);
			}
			else {
				dp[i][j] = dp[i - 1][j];
			}
		}
	}

	cout << dp[n][W];
}