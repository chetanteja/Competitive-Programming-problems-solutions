#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl

ll solve(ll n, ll a[], ll b[], ll c[]) {
    ll i;
    ll dp1[n], dp2[n], dp3[n];
    dp1[0] = a[0]; dp2[0] = b[0]; dp3[0] = c[0];
    for (i = 1; i < n; ++i)
    {
        dp1[i] = a[i] + max(dp2[i - 1], dp3[i - 1]);
        dp2[i] = b[i] + max(dp1[i - 1], dp3[i - 1]);
        dp3[i] = c[i] + max(dp1[i - 1], dp2[i - 1]);
    }
    return max(dp1[n - 1], max(dp2[n - 1], dp3[n - 1]));
}

int main() {
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    ll n, x, y, i, j;
    cin >> n;
    ll a[n], b[n], c[n];
    for ( i = 0; i < n; i++)
    {
        cin >> a[i] >> b[i] >> c[i];

    }
    x = solve(n, a, b, c);
    cout << x;

}