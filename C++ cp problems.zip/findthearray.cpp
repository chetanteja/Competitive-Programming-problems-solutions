#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n;
		cin >> n;
		vector<int> v(n); int sum = 0;
		for (int j = 0; j < n; j++) {
			cin >> v[j];
			sum += v[j];
		}

		int i = n;
		for (i = n; i > 0; i--) {
			if (sum % i == 0) {
				int k = sum / i;
				int s = 0;
				int j;
				for (j = 0; j < n; j++) {
					if (s == k)s = v[j];
					else if (s < k)s += v[j];
					else break;
				}
				if (j == n && s == k)break;
			}
		}
		cout << n - i << "\n";
	}
}