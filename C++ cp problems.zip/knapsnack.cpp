#include <bits/stdc++.h>
using namespace std;

int t, n;
long long w, a, tot;
vector<int> r;

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	scanf("%d", &t);
	while (t--) {
		tot = 0;
		r.clear();
		scanf("%d %lld", &n, &w);
		for (int i = 1; i <= n; i++) {
			scanf("%lld", &a);
			if (a >= (w + 1) / 2 && a <= w) {
				r.clear();
				r.push_back(i);
				tot = a;
			}
			else if (tot + a <= w) {
				tot += a;
				r.push_back(i);
			}
		}
		if (tot < (w + 1) / 2) printf("-1\n");
		else {
			printf("%d\n", r.size());
			for (int i = 0; i < r.size() - 1; i++) printf("%d ", r[i]);
			printf("%d\n", r.back());
		}
	}
	return 0;
}