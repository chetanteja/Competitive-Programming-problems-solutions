#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x;
		int a[4];
		rep(i, 0, 4) {
			cin >> a[i];
		}
		if (max(a[0], a[1]) < min(a[2], a[3])) {
			cout << "NO\n";
			continue;
		}
		if (max(a[2], a[3]) < min(a[0], a[1])) {
			cout << "NO\n";
			continue;
		}
		cout << "YES\n";
	}
}