#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)
ll mod = 1e9 + 7;

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x;
		cin >> n;
		ll a[n], b[n], ans = 1;
		map<ll, ll> m;
		map<ll, ll> M;
		rep(i, 0, n) cin >> a[i];
		rep(i, 0, n) cin >> b[i], m[a[i]] = b[i];
		for (ll i = 0; i < n; i++) {
			if (M[a[i]] == 0) {
				M[a[i]] = 1;
				x = m[a[i]];
				while (x != a[i]) {
					M[x] = 1;
					x = m[x];
				}
				ans = (ans * 2) % mod;

			}
		}
		cout << ans << line;

	}
}