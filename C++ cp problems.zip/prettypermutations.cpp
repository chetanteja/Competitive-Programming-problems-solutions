#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x;
		cin >> n;
		if (n % 2 == 0) {
			for (ll i = 0; i < n - 1; i += 2) {
				cout << i + 2 << " " << i + 1 << " ";
			}
		}
		else {
			for (ll i = 0; i < n - 1; i ++) {
				cout << i + 2 << " ";
				i++;
				if (i != n - 2) {
					cout << i << " ";
				}
				else {
					cout << i + 2 << " " << i;
				}
			}
		}
		cout << line;
	}
}