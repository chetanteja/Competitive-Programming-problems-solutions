#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, s = 0;
		cin >> n;
		ll a[n];
		rep(i, 0, n) cin >> a[i];
		x = 0;
		ll l, r, m;
		if (n == 1) {
			cout << a[0] << line;
			continue;
		}
		rep(i, 0, n) {
			l = -1, r = -1;
			if (i != 0) l = a[i - 1];
			if (i != n - 1) r = a[i + 1];
			if (a[i] > l && a[i] > r) {
				s += a[i] - max(l, r);
				a[i] = max(l, r);
				//cout << s << line;
			}
		}
		s += a[0] + a[n - 1];
		for (int i = 1; i < n; i++)
		{
			s += abs(a[i] - a[i - 1]);
		}
		//s += 2 * (*max_element(a, a + n));
		cout << s << line;
	}
}