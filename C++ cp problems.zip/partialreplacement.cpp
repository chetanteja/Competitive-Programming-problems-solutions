#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x = 0, k, cnt = 2;
		cin >> n >> k;
		string s;
		cin >> s;
		//cout << s << line;
		vector<int> a;
		rep(i, 0, n) {
			if (s[i] == '*') {
				a.push_back(i);
				x++;
			}
		}
		if (x == 1) {
			cout << "1" << line;
			continue;
		}
		if (x == 2) {
			cout << "2" << line;
			continue;
		}
		ll i = *a.begin();
		ll j = a.back();
		//cout << i << " " << j << line;
		if (j - i <= k) {
			cout << "2" << line;
			continue;
		}
		while (j - i > k) {
			x = i + k;
			while (s[x] != '*') {
				x--;
			}
			s[x] = 'x';
			i = x;
			cnt++;
		}
		cout << cnt << line;
		a.clear();
	}
}