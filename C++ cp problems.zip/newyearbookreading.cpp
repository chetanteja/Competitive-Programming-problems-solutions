#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)
map<ll, ll> ma;

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, x, m;
	cin >> n >> m;
	ll a[n], b[m];
	rep(i, 0, n) cin >> a[i];
	rep(i, 0, m) cin >> b[i];
	vector<ll> v;

	rep(i, 0, m) {
		if (ma[b[i]] == 0) {
			ma[b[i]] = 1;
			v.push_back(b[i]);
		}
	}
	ll j, ans = 0;
	rep(i, 0, m) {
		j = 0;
		while (v[j] != b[i]) {
			ans += a[v[j] - 1];
			j++;
		}
		x = v[j];
		v.erase(v.begin() + j);
		v.insert(v.begin(), x);
	}
	cout << ans;
}