#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)
map<ll, ll>m;

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, x, A;
	cin >> n >> A;
	ll a[n];
	rep(i, 0, n) cin >> a[i];
	//ll a = 0, b = 0;
	//ll max = *max_element(a, a + n);
	ll M = 0;
	rep(i, 0, n) {
		x = a[i];
		if (m[x] < m[A]) {
			continue;
		}
		m[x]++;
		if (m[M] < m[A]) {
			cout << "-1";
			return 0;
		}
		if (m[x] > m[M]) {
			M = x;
		}
	}
	cout << M;
	return 0;
	// //max = 0;
	// x = -1;
	// rep(i, 0, max + 1) {
	// 	if (i != A && m[i] > 0) {
	// 		x = i;
	// 		break;
	// 	}
	// }
	// if (x == -1) {
	// 	cout << "-1";
	// 	return 0;
	// }
	// cout << x << line;
}