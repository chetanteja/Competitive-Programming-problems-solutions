#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,n) for (int i = 0; i < (n); ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll a, b;
		cin >> a >> b;
		if (b == 1) {
			cout << "NO" << line;
		}
		else {
			ll x = a * b;

			cout << "YES" << line << a << " " << x << " " << x + a << line;
		}

	}
}