#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, a, b, x = 1000, ans = 0;
		string s;
		cin >> a >> b >> s;
		for (int i = 0; i < s.size(); i++)
		{
			if (s[i] == '1') {
				ans += min(a, b * x); x = 0;
			}
			else x++;
		}
		cout << ans << line;
	}
}