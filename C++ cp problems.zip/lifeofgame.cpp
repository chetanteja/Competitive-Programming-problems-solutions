#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n,  m, z = 0;
		cin >> n >> m;
		string s, x;
		cin >> s;
		s = '0' + s + '0';
		x = s;
		while (m--) {
			rep(i, 1, n + 1) {
				z = 0;
				if (s[i] == '0') {
					if ((s[i - 1] == '0' && s[i + 1] == '1') || (s[i - 1] == '1' && s[i + 1] == '0')) {
						x[i] = '1';
					}
				}
			}
			if (x == s) {
				break;
			}
			s = x;
		}
		rep(i, 1, n + 1) cout << s[i];
		cout << line;
	}
}