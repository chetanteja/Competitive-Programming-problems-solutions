#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, i;
		cin >> n;
		ll a[n + 1];
		a[0] = 0;
		for (i = 1; i <= n; i++)
		{
			cin >> a[i];
		}
		sort(a, a + n + 1);
		ll dp[n + 1];
		dp[0] = 0;
		for (i = 1; i <= n; i++)
		{
			dp[i] = dp[i - 1] + a[i];
		}

		ll ans = 0;
		for (i = n; i >= 3; i--)
		{
			ans += ((i - 2) * a[i] - dp[i - 2]);
		}
		cout << -ans << endl;
	}
}