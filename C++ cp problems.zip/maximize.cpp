#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, x, p, q, r;
	cin >> n;
	ll a[n];
	rep(i, 0, n) cin >> a[i];
	ll dp[n + 1][4];
	memset(dp, 0, sizeof(dp));
	dp[0][0] = -1 * a[0];
	rep(i, 1, n) {
		dp[i][0] = max(dp[i - 1][0], -1 * a[i]);
	}
	dp[0][1] = dp[0][0] + a[0];
	rep(i, 1, n) {
		dp[i][1] = max(dp[i - 1][1], a[i] + dp[i][0]);
	}
	dp[0][3] = dp[0][1] + a[0];
	rep(i, 1, n) {
		dp[i][2] = max(dp[i - 1][2],  -a[i] + dp[i][1]);
	}
	dp[0][3] = dp[0][1] + a[0];
	rep(i, 1, n) {
		dp[i][3] = max(dp[i - 1][3],  a[i] + dp[i][2]);
	}
	cout << dp[n - 1][3];
}