#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, x, s = 0;
	cin >> n;
	priority_queue<long long, vector<long long>, greater<long long> > pq;
	ll a[n];
	rep(i, 1, n + 1) {
		cin >> x;
		s = s + x;
		pq.push(x);
		while (s < 0) {
			s = s - pq.top();
			pq.pop();
		}
	}
	cout << (int) pq.size() << line;
}