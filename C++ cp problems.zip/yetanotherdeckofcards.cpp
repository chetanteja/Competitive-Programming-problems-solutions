#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, x, q;
	cin >> n >> q;
	vector<ll>v;
	rep(i, 0, n) {
		cin >> x;
		v.push_back(x);
	}
	while (q--) {
		cin >> x;
		int p = find(v.begin(), v.end(), x) - v.begin();
		cout << p + 1 << " ";
		rotate(v.begin(), v.begin() + p, v.begin() + p + 1);
	}
	// rep(i, 0, n) {
	// 	cout << v[i] << " ";
	// }

}

