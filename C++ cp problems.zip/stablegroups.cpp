#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, x, k, j = 0;
	cin >> n >> k >> x;
	ll a[n];
	rep(i, 0, n) cin >> a[i];
	vector<ll>v;
	sort(a, a + n);
	rep(i, 1, n) {
		if (a[i] - a[i - 1] > x) {
			v.push_back(a[i] - a[i - 1]);
			j++;
		}
	}
	//cout << j;
	ll N = j;
	sort(v.begin(), v.end());
	rep(i, 0, j) {
		//cout << v[i] << line;
		if (k < 0) {
			break;
		}
		if (k != 0) {
			k -= v[i] / x;
			if (v[i] % x == 0) k++;
			if (k < 0) {
				break;
			}
			N--;
		}
		if (k <= 0) {
			break;
		}
	}
	cout << N + 1 << line;

}