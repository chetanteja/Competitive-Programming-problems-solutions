#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)
ll mod = 1e9 + 7;
ll fact(ll i) {
	if (i <= 1) return 1;
	else return (i * fact(i - 1)) % mod;
}
ll binpow(ll a, ll b, ll m) {
	a %= m;
	ll res = 1;
	while (b > 0) {
		if (b & 1)
			res = (res * a) % m;
		a = (a * a) % m;
		b >>= 1;
	}
	return res;
}
ll modInverse(ll n, ll mod) {
	return binpow(n, mod - 2, mod);
}
ll comb(ll n, ll r, ll p) {
	if (r == 0 or n == r) return 1;
	ll fac[n + 1]; fac[0] = 1;
	for (ll i = 1; i <= n; i++) {fac[i] = fac[i - 1] * i; fac[i] %= p; }
	return (fac[n] * modInverse(fac[r], p) % p * modInverse(fac[n - r], p) % p) % p;
}

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	ll n, m, x;
	cin >> n >> m;
	ll ans = comb(n + 2 * m - 1 , 2 * m , mod);
	// x = (fact(n + 2 * m - 1) % mod);
	// ll y = fact(2 * m) % mod;
	// ll z = fact(n - 1) % mod;
	// x = (x / (y * z)) % mod;
	cout << ans;
}