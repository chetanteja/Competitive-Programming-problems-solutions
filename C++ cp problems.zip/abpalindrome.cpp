#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, a, b, flag = 0;
		cin >> a >> b;
		//cout << "hello";
		string s;
		cin >> s;
		n = a + b;
		for (int i = 0; i < n; ++i)
		{
			if (s[i] == '0') {
				a--;
			}
			if (s[i] == '1') {
				b--;
			}
		}
		for (int i = 0; i < n / 2; ++i)
		{
			if (s[i] != '?' && s[n - 1 - i] == '?') {
				if (s[i] == '1') {
					s[n - i - 1] = '1';
					b--;
				}
				if (s[i] == '0') {
					s[n - i - 1] = '0';
					a--;
				}
			}
			else if (s[i] == '?' && s[n - 1 - i] != '?') {
				if (s[n - i - 1] == '1') {
					s[i] = '1';
					b--;
				}
				if (s[n - i - 1] == '0') {
					s[i] = '0';
					a--;
				}
			}
			if (s[i] != '?' && s[n - i - 1] != '?' && s[i] != s[n - i - 1]) {
				flag = 1;
				break;
			}
		}
		if (a < 0 || b < 0) {
			flag = 1;
		}
		if (flag == 1) {
			cout << "-1" << line;
			continue;
		}
		//cout << a << b << line;
		for (int i = 0; i < n / 2; ++i)
		{
			if (s[i] == '?' && a >= 2) {
				s[i] = '0';
				s[n - i - 1] = '0';
				a = a - 2;
			}
			else if (s[i] == '?' && b >= 2) {
				s[i] = '1';
				s[n - i - 1] = '1';
				b = b - 2;
			}
		}
		for (int i = 0; i < n / 2; ++i)
		{
			/* code */
			if (s[i] == '?') {
				flag = 1;
				break;
			}
		}
		if (flag == 1) {
			cout << "-1" << line;
			continue;
		}
		if (n % 2 != 0) {
			ll i = n / 2;
			if (s[i] == '?') {
				if (a == 1) {
					s[i] = '0';
				}
				else if (b == 1) {
					//cout << "hello" << a << b << i << line;
					s[i] = '1';
					//cout << s[i];
				}
				else if (a != 1 && b != 1) {
					flag = 1;
				}
			}
		}
		if (flag == 1) {
			cout << "-1" << line;
			continue;
		}
		//cout << "yes";
		cout << s << line;
	}
}