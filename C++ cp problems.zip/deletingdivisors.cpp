#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

bool is_prime(int n)
{
	// Corner cases
	if (n <= 1)
		return false;
	if (n <= 3)
		return true;

	// This is checked so that we can skip
	// middle five numbers in below loop
	if (n % 2 == 0 || n % 3 == 0)
		return false;

	for (int i = 5; i * i <= n; i = i + 6)
		if (n % i == 0 || n % (i + 2) == 0)
			return false;

	return true;
}

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x;
		cin >> n;
		if (is_prime(n)) {
			cout << "Bob\n";
			continue;
		}
		if (n % 2) {
			cout << "Bob\n";
			continue;
		}
		x = 0;
		while (n % 2 == 0) {
			n = n / 2;
			x++;
		}
		if (n > 1) cout << "Alice\n";
		else if (x % 2 == 0) cout << "Alice\n";
		else cout << "Bob\n";
	}
}