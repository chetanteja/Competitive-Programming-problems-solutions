#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, l, N;
		cin >> N >> l;
		//cout << "HELLO\n";
		while (N--) {

			cin >> n;
			if (n % l == 0) {
				cout << "YES\n";
			}
			else if (n >= (l * 10)) {
				cout << "YES\n";
			}
			else
			{
				int x = n % 10;
				int y = -1;
				for (int j = 1; j <= 9; j++)
				{
					if (x == (l * j) % 10)
					{
						y = j;
						break;
					}
				}
				long long int z = n - y * l;
				if (z >= 0 && y != -1)
					cout << "YES\n";
				else
					cout << "NO\n";

			}
		}
	}
}