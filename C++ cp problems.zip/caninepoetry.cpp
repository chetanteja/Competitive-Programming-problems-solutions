#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, ans = 0;
		string s;
		cin >> s;
		n = s.size();
		//int a[n] = {0};
		rep(i, 1, n ) {
			if (s[i - 1] == s[i] || s[i - 2] == s[i])
				ans++, s[i] = 0;
		}
		cout << ans << line;
	}
}