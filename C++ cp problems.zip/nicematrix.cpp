#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)
int T, n, m, a[105][105], b[15];
ll ans;

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		cin >> n >> m;
		ans = 0;
		for (int i = 1; i <= n; i++)
			for (int j = 1; j <= m; j++) cin >> a[i][j];
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= m; j++) {
				b[1] = a[i][j], b[2] = a[n - i + 1][j];
				b[3] = a[i][m - j + 1], b[4] = a[n - i + 1][m - j + 1];
				sort(b + 1, b + 5);
				ans += b[4] - b[1];
				ans += b[3] - b[2];
			}
		}
		cout << ans / 4 << line;
	}
}