#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, y;
		cin >> n;
		string s;
		cin >> s;
		x = 0; y = 0;
		map<pair<ll, ll>, ll>a;
		for (int i = 0; i < n; i++) {
			if (s[i] == 'D') {
				x++;
			}
			else {
				y++;
			}
			pair<ll, ll> temp = make_pair(x, y);
			if (temp.first == 0)
			{
				temp.second = 1;
			}
			else if (temp.second == 0)
			{
				temp.first = 1;
			}
			else
			{
				int g = 1;
				g = __gcd(x, y);
				temp.first /= g;
				temp.second /= g;
			}
			cout << ++a[temp] << " ";
		}
		cout << line;
	}
}