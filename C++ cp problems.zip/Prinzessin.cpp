#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, check = 0, i, j;
		cin >> n;
		string s;
		cin >> s;
		map<char, ll> a;
		rep(i, 0, n) {
			a[s[i]]++;
		}
		char c = 'a';
		for (i = 0; i < 26; i++) {
			if (a[c + i] == 0) {
				check = 1;
				break;
			}
		}
		if (check == 1) {
			cout << (char)(c + i) << line;
			continue;
		}
		char d;
		ll dp[26][26];
		memset(dp, 0, sizeof(dp));
		for (i = 0; i < n - 1; i++) {
			c = s[i];
			d = s[i + 1];
			dp[(c - 'a')][(d - 'a')] = 1;
		}
		// for (i = 0; i < 26; i++) {
		// 	for (j = 0; j < 26; j++) {
		// 		cout << dp[i][j] << " ";
		// 	}
		// 	cout << line;
		// }
		for (i = 0; i < 26; i++) {
			for (j = 0; j < 26; j++) {
				if (dp[i][j] == 0) {
					goto done;
				}
			}
		}
		ll p[26][26][26];
		char e;
		memset(p, 0, sizeof(p));
		for (i = 0; i < n - 2; i++) {
			c = s[i];
			d = s[i + 1];
			e = s[i + 2];
			p[(c - 'a')][(d - 'a')][(e - 'a')] = 1;
		}
		// for (i = 0; i < 26; i++) {
		// 	for (j = 0; j < 26; j++) {
		// 		cout << dp[i][j] << " ";
		// 	}
		// 	cout << line;
		// }
		ll k;
		for (i = 0; i < 26; i++) {
			for (j = 0; j < 26; j++) {
				for (k = 0; k < 26; k++) {
					if (p[i][j][k] == 0) {
						goto done1;
					}
				}
			}
		}
done:;
		c = 'a' + i;
		d = 'a' + j;
		cout << c << d << line;
		continue;
done1:;
		c = 'a' + i;
		d = 'a' + j;
		e = 'a' + k;
		cout << c << d << e << line;



	}
}