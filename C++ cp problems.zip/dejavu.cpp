#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

bool palindrome(const string &s) {
	int n = s.length();
	for (int i = 0; i < n; i++) {
		if (s[i] != s[n - i - 1]) return false;
	}
	return true;
}

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		string s;
		cin >> s;
		if (!palindrome(s + 'a')) {
			cout << "YES\n" << s << 'a' << "\n";
		} else if (!palindrome('a' + s)) {
			cout << "YES\n" << 'a' << s << '\n';
		} else {
			cout << "NO\n";
		}
	}
}