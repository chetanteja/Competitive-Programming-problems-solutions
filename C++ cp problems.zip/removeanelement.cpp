#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, x;
	cin >> n;
	ll a[n], j, k, max = -1;
	rep(i, 1, n - 1) {
		if (a[i] > a[i - 1] && a[i] > a[i + 1]) {
			k = i;
			for (j = 1; j < n; j++) {
				if (j == k) {
					j++;
					if (a[j] > a[j - 2])
					}
				if (a[j] > a[j - 1]) {
					x++;
				}
				else {
					if (x > max) {
						max = x;
					}
				}
			}
		}
		else {
			continue;
		}
	}
}
