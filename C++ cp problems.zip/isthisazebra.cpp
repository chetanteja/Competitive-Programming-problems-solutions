#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, x = 0, y = 0;
	cin >> n;
	ll a[n];
	rep(i, 0, n) {
		cin >> a[i];
		if (a[i] == 1) {
			x++;
		}
		else {
			y++;
		}
	}
	if (!x || !y) {
		cout << "YES";
		return 0;
	}
	x = 0; y = 0;
	ll i = 0;
	while (i < n) {
		if (a[i] == 1) {
			y = 0;
			while (a[i] == 1) {
				i++;
				y++;
			}
			if (x != 0 && x != y) {
				cout << "NO";
				return 0;
			}
		}
		if (a[i] == 0) {
			x = 0;
			while (a[i] == 0) {
				i++;
				x++;
			}
			if (y != 0 && x != y) {
				cout << "NO";
				return 0;
			}
		}

	}
	cout << "YES";

}