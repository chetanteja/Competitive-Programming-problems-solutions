#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x;
		cin >> n;
		vector<ll>v[n + 1];
		ll a[n + 1], b[n + 1] = {0};
		rep(i, 1, n + 1) {
			cin >> a[i];
		}
		rep(i, 1, n + 1) {
			cin >> x;
			v[a[i]].push_back(x);
		}
		rep(i, 1, n + 1) {
			sort(v[i].rbegin(), v[i].rend());
			x = v[i].size();
			rep(j, 1, x) {
				v[i][j] += v[i][j - 1];
			}
			rep(j, 1, x + 1) {
				int temp = v[i].size() % j;
				b[j] += v[i][v[i].size() - temp - 1];
			}
		}
		rep(i, 1, n + 1) {
			cout << b[i] << " ";
		}
		cout << endl;
	}
}