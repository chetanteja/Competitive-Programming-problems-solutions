#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll k, x;
		cin >> k;
		ll a[k];
		rep(i, 0, k) cin >> a[i];
		sort(a, a + k);
		x = max(a[0] * a[1] * a[k - 1] * a[k - 2] * a[k - 3],
		        a[0] * a[1] * a[2] * a[3] * a[k - 1]);
		x = max(a[k - 1] * a[k - 2] * a[k - 3] * a[k - 4] * a[k - 5], x);
		cout << x << line;

	}
}