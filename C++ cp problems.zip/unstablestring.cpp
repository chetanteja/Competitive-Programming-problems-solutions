#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, ans = 0, i;
		string s;
		cin >> s;
		n = s.size();
		ll dp[n + 1][2];
		//memset(dp, 0, sizeof(dp));
		dp[0][0] = 0; dp[0][1] = 0;
		for (i = 1; i <= s.size(); i++) {
			if (s[i - 1] != '?') {
				x = s[i - 1] - '0';
				dp[i][x] = dp[i - 1][1 - x] + 1;
				dp[i][1 - x] = 0;
				ans += dp[i][x];
			}
			else {
				dp[i][0] = dp[i - 1][1] + 1;
				dp[i][1] = dp[i - 1][0] + 1;
				ans += max(dp[i][0], dp[i][1]);
			}
		}

		cout << ans << line;
	}
}