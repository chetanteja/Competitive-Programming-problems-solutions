#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, m;
		cin >> n >> m;
		char a[n][m];
		ll dp[n][m];
		memset(dp, 0, sizeof(dp));
		rep(i, 0, n) {
			rep(j, 0, m) {
				cin >> a[i][j];
				if (a[i][j] == '*') dp[i][j] = 1;
				else dp[i][j] = 0;
			}
		}

		for (int i = n - 2; ~i; i--) {
			for (int j = m - 2; j > 0; j--) {
				if (dp[i + 1][j - 1] && dp[i + 1][j] && dp[i + 1][j + 1] && dp[i][j]) {
					dp[i][j] = min({dp[i + 1][j - 1], dp[i + 1][j], dp[i + 1][j + 1]}) + 1;
				}
			}
		}

		// rep(i, 0, n) {
		// 	rep(j, 0, m) {
		// 		if ((a[i][j] == '*') && (i == 0 || j == 0 || i == n - 1 || j == m - 1)) {
		// 			dp[i][j] = 1;
		// 		}
		// 	}
		// }
		// for(i=n-1,i>=0;i--) {
		// 	rep(j, 1, m - 1) {
		// 		if (a[i][j] == '*') {
		// 			dp[i][j] = 1;
		// 			if (i > 0 && j > 0 && j < m - 1) {
		// 				if (a[i][j - 1] == '*' && a[i][j + 1] == '*' && a[i - 1][j] == '*') {
		// 					//dp[i][j] += dp[i - 1][j];
		// 					x = min(dp[i][j + 1], dp[i][j - 1]);
		// 					dp[i][j] += min(x, dp[i - 1][j]);
		// 				}
		// 			}

		// 		}
		// 	}
		// }
		ll ans = 0;
		rep(i, 0, n) {
			rep(j, 0, m) {
				//cout << dp[i][j];
				ans += dp[i][j];
			}
			//cout << line;
		}
		cout << ans << line;
	}
}