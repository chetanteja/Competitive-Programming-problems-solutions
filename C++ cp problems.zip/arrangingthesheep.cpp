#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		int n;
		cin >> n;
		string s;
		cin >> s;
		int cnt = 0;
		for (auto x : s)
			cnt += (x == '*' ? 1 : 0);
		int pos = -1;
		int cur = -1;
		for (int i = 0; i < n; i++)
		{
			if (s[i] == '*')
			{
				cur++;
				if (cur == cnt / 2)
					pos = i;
			}
		}
		long long ans = 0;
		cur = pos - cnt / 2;
		for (int i = 0; i < n; i++)
			if (s[i] == '*')
			{
				ans += abs(cur - i);
				cur++;
			}
		cout << ans << endl;
	}
}