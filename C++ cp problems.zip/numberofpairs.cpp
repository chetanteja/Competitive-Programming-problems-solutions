#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)
map<ll, ll> m;

int binarySearchCount(int arr[], int n, int key, int l, int r)
{
	int left = l;
	int right = r;

	int count = 0;

	while (left <= right) {
		int mid = (right + left) / 2;

		// Check if middle element is
		// less than or equal to key
		if (arr[mid] <= key) {

			// At least (mid + 1) elements are there
			// whose values are less than
			// or equal to key
			count = mid;
			left = mid + 1;
		}

		// If key is smaller, ignore right half
		else
			right = mid - 1;
	}

	return count;
}
int binarySearchCount1(int arr[], int n, int key, int l, int r)
{
	int left = l;
	int right = r;

	int count = 0;

	while (left <= right) {
		int mid = (right + left) / 2;

		// Check if middle element is
		// less than or equal to key
		if (arr[mid] <= key) {

			// At least (mid + 1) elements are there
			// whose values are less than
			// or equal to key
			count = mid;
			left = mid + 1;
		}

		// If key is smaller, ignore right half
		else {
			count = n - mid + 1;
			right = mid - 1;
		}
	}

	return count;
}

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, l, r, ans = 0;
		cin >> n >> l >> r;
		vector<ll> v(n);
		rep(i, 0, n) cin >> v[i];
		//cout << "hee";
		sort(v.begin(), v.end());
		rep(i, 0, n) {
			ll x = upper_bound(v.begin(), v.end(), r - v[i]) - v.begin();
			ll y = lower_bound(v.begin(), v.end(), l - v[i]) - v.begin();
			//cout << x << " " << y << line;
			if (2 * v[i] >= l && 2 * v[i] <= r) {
				ans--;
			}
			ans += x - y;
		}
		cout << ans / 2 << line;


	}
}