#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl

int main() {
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    int t;
    cin >> t;
    while (t--) {
        ll x, y, z, i, m = -1;
        cin >> x;
        vector<int> v(101, 0);
        for ( i = 0; i < x; i++)
        {
            /* code */
            cin >> y;
            v[y]++;
        }
        for ( i = 0; i < 101; i++)
        {
            /* code */
            if (v[i] != 0) {
                //cout<<v[i]<<line;
                break;
            }
        }
        x = x - v[i];
        cout << x << line;
    }
}