#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x = 0, y = 0;
		string s;
		cin >> s;
		ll l = 0, r = 0, u = 0, d = 0;
		n = s.size();
		//cout << n;

		ll X = 0, Y = 0, flag = 0;
		for (int i = 0; i < n; i++)
		{
			if (s[i] == 'L')x--;
			if (s[i] == 'R')x++;
			if (s[i] == 'U')y++;
			if (s[i] == 'D')y--;
			int nx = 0, ny = 0;
			for (int j = 0; j < n; j++)
			{
				int lx = nx, ly = ny;
				if (s[j] == 'L')nx--;
				if (s[j] == 'R')nx++;
				if (s[j] == 'U')ny++;
				if (s[j] == 'D')ny--;
				if (nx == x && ny == y)
					nx = lx, ny = ly;
			}
			if (nx == 0 && ny == 0)
			{
				cout << x << " " << y << endl;
				flag = 1; break;
			}
		}
		if (flag == 0)
			cout << 0 << " " << 0 << endl;
	}


}