#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, x;
	cin >> n;
	float a[n];
	ll b[n] = {0};
	rep(i, 0, n) cin >> a[i];
	int t = 0, s = 0;
	for (ll i = 0; i < n; i++) {
		if (a[i] < 0) {
			b[i] = floor(a[i]);
		}
		else if (a[i] > 0) {
			b[i] = ceil(a[i]);
		}
		else {
			b[i] = 0;
		}
		s += b[i];
	}
	if (s == 0) {
		goto done;
	}
	for (ll i = 0; i < n; i++) {
		if (s > 0) {
			if (a[i] > 0 && a[i] != ceil(a[i])) {
				b[i]--;
				s--;
			}
			if (s == 0) goto done;
		}
		if (s < 0) {
			if (a[i] < 0 && a[i] != floor(a[i])) {
				b[i]++;
				s++;
			}
			if (s == 0) goto done;
		}
		if (s == 0) goto done;

	}
	//cout << s << line;
	// if (s + floor(a[n - 1]) == 0) {
	// 	b[n - 1] = floor(a[n - 1]);
	// }
	// else if (s + ceil(a[n - 1]) == 0) {
	// 	b[n - 1] = ceil(a[n - 1]);
	// }
	// else {
	// 	b[n - 1] = floor(a[i]);
	// 	s += b[n - 1];
	// 	if (s == 0) goto done;
	// 	t=1;
	// 	if (s > 0) t = 0;
	// 	for (ll i = 0; i < n; i++) {
	// 		if (a[i] == floor(a[i])) {
	// 			continue;
	// 		}
	// 		if (t == 0) {
	// 			b[i] = floor(a[i]);
	// 			break;
	// 		}
	// 		else {
	// 			b[i] = ceil(a[i]);
	// 			break;
	// 		}

	// 	}
done:;
	rep(i, 0, n) cout << b[i] << line;

}