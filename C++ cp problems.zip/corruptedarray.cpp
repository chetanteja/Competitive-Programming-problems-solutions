#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x = -1, s = 0;
		cin >> n;
		n += 2;
		int a[n];
		rep(i, 0, n) cin >> a[i];
		sort(a, a + n);
		rep(i, 0, n - 1) s = s + a[i];
		//cout << a[n - 1];
		rep(i, 0, n - 1) {
			//cout << (s - a[i]) << " ";
			if ((s - a[i]) == a[n - 1]) {
				//cout << "hello";
				x = i;
				s = n - 1;
			}
		}
		if (x == -1) {
			s = 0;
			rep(i, 0, n) {
				if (i != n - 2) {
					s = s + a[i];
				}
			}
			rep(i, 0, n) {
				if (i != n - 2) {
					if (s - a[i] == a[n - 2]) {
						//cout << "yes";
						x = i;
						s = n - 2;
					}
				}
			}
		}
		if (x == -1) {
			cout << "-1" << line;
			continue;
		}
		//cout << s << " " << x << line;
		rep(i, 0, n) {
			if (i != s && i != x) {
				cout << a[i] << " ";
			}
		}
		cout << line;
	}
}