#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, m, i, j;
		cin >> n >> m >> i >> j;
		ll x, y, x1, y1;
		if ((i - 1) >= (n - i) && (i - 1) >= (j - 1) && (i - 1) >= (m - j))
		{
			if (m - j >= j - 1)
			{
				x1 = 1; y1 = m;
				x = n; y = 1;
			}
			else
			{
				x = 1; y = 1;
				x1 = n; y1 = m;
			}

		}
		if ((n - i) >= (i - 1) && (n - i) >= (j - 1) && (n - i) >= (m - j))
		{
			if (m - j >= j - 1)
			{
				x1 = n; y1 = m;
				x = 1; y = 1;
			}
			else
			{
				x = 1; y = 1;
				x1 = n; y1 = m;
			}
		}
		if ((j - 1) >= (m - j) && (j - 1) >= (i - 1) && (j - 1) >= (n - i))
		{
			if (n - i >= i - 1)
			{
				x1 = n; y1 = 1;
				x = 1; y = m;
			}
			else
			{
				x = 1; y = 1;
				x1 = n; y1 = m;
			}
		}
		if ((m - j) >= (j - 1) && (m - j) >= (i - 1) && (m - j) >= (n - i))
		{
			if (n - i >= i - 1)
			{
				x1 = n; y1 = m;
				x = 1; y = 1;
			}
			else
			{
				x = 1; y = m;
				x1 = n; y1 = 1;
			}
		}
		cout << x << " " << y << " " << x1 << " " << y1 << endl;
	}
}