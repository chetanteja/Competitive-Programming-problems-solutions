#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, check = 0;
		cin >> n;
		ll a[n];
		rep(i, 0, n) {
			cin >> a[i];
			if (a[i] < 0) check = 1;
		}
		x = *max_element(a, a + n);
		if (check == 0) {
			cout << "YES\n" << x + 1 << line;
			rep(i, 0, x + 1) {
				cout << i << " ";
			}
			cout << line;
			continue;
		}
		cout << "NO\n";
	}
}