#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)


int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, cnt = 0, a;
		cin >> n;
		x = 0;
		while (1) {
			a = n - (111 * x);
			if (a < 0) {
				break;
			}
			if (a % 11 == 0) {
				cnt = 1;
				break;
			}
			x++;
		}
		if (cnt == 1) {
			cout << "YES" << line;
		}
		else {
			cout << "NO" << line;
		}
	}
}