#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, m;
		cin >> n >> m;
		ll a[n][m];
		rep(i, 0, n) {
			rep(j, 0, m) {
				cin >> a[i][j];
			}
		}
		rep(i, 0, n) {
			rep(j, 0, m) {
				if ((i + j) % 2 == 0) {
					if (a[i][j] % 2) {
						a[i][j]++;
					}
				}
				if ((i + j) % 2 != 0) {
					if (a[i][j] % 2 == 0) {
						a[i][j]++;
					}
				}
			}
		}
		rep(i, 0, n) {
			rep(j, 0, m) {
				cout << a[i][j] << " ";
			}
			cout << line;
		}


	}
}