#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

ll a[110][110];
int check[102][102];

int main() {

#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, m, x, i, j, k, y = 0;
		cin >> n >> m;
		for (i = 1; i <= n; i++) {
			for (j = 1; j <= m; j++) {
				cin >> a[i][j];
			}
			sort(a[i], a[i] + m + 1);
		}
		a[0][0] = 1e9 + 10;
		for (int i = 1; i <= m; ++i)
		{
			int I = 0, J = 0;
			for (int j = 1; j <= n; ++j)
			{
				for (int k = 1; k <= m; k++)
				{
					if (!check[j][k] && a[j][k] < a[I][J]) {
						I = j, J = k;
					}
				}
			}

			swap(a[I][J], a[I][i]);
			check[I][i] = 1;
		}
		for (int i = 1; i <= n; i++)
		{
			for (int j = 1; j <= m; j++)
			{
				printf("%d ", a[i][j]);
				a[i][j] = 0;
				check[i][j] = 0;
			}
			printf("\n");
		}


	}
}