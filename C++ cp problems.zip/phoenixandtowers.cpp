#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, M;
		cin >> n >> M >> x;
		ll a[n], b[n];
		vector<pair<int, int>>v;
		for (ll i = 0; i < n; i++)
		{
			cin >> a[i];
			v.push_back({a[i], i});
		}
		sort(v.begin(), v.end());
		for (ll i = 0; i < n; i++)
		{
			b[v[i].second] = i % M + 1;
		}
		cout << "YES\n";
		rep(i, 0, n) {
			cout << b[i] << " ";
		}
		cout << line;
	}
}