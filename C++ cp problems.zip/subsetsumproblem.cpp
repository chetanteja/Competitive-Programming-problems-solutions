#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, x, i, W;
	cin >> n >> W;
	ll a[n];
	rep(i, 0, n) cin >> a[i];
	//cout << "hello" << line;
	ll dp[n + 1][W + 1];
	memset(dp, 0, sizeof(dp));
	rep(i, 0, n + 1) dp[i][0] = 1;
	rep(i, 0, n + 1) dp[0][i] = 0;
	rep(i, 1, n + 1) {
		rep(j, 1, W + 1) {
			if (a[i - 1] <= j) {
				if (((dp[i - 1][j - a[i - 1]]) || dp[i - 1][j])) {
					dp[i][j] = 1;
				}
				else {
					dp[i][j] = 0;
				}
			}
			else {
				dp[i][j] = dp[i - 1][j];
			}
		}
	}
	// rep(i, 0, n + 1) {
	// 	rep(j, 0, N + 1) {
	// 		cout << dp[i][j] << " ";
	// 	}
	// 	cout << line;
	// }

	cout << dp[n][W];
}