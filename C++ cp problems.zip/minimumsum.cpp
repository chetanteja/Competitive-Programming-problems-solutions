#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, x, i;
	cin >> n;
	string s[n];
	//map<char,ll> m;
	ll m[11] = {0};
	rep(i, 0, n) cin >> s[i];
	rep(i, 0, n) {
		x = s[i].size();
		//cout << x << line;
		int temp = x;
		x = 1;
		for (int j = temp - 1; j >= 0; j--) {
			//cout << "hell\n";
			m[s[i][j] - 'a'] += x;
			x *= 10;
			//cout << m[s[i][j] - 'a'] << " " << s[i][j] << j << x << line;
		}
	}
	ll chk[10] = {0};
	ll max = -1, k = 10;
	rep(i, 0, n) {
		chk[s[i][0] - 'a'] = 1;
	}
	rep(i, 0, 10) {
		//cout << i << " " << m[i] << line;
		if (chk[i] == 0) {
			//cout << "yes\n";
			if (m[i] > max) {
				k = i;
				max = m[i];
				//cout << i << line;
			}
		}
	}
	//cout << k << line;
	m[k] = 0;
	sort(m, m + 10);
	x = 1;
	ll ans = 0;
	for (i = 9; i >= 0; i--) {
		ans += x * m[i];
		//cout << m[i] << " " << x << line;
		x++;
	}
	cout << ans;

}