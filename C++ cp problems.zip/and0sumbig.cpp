#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)


int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	ll MOD = 1e9 + 7;
	cin >> t;
	while (t--) {
		ll n, x, ans = 1;
		cin >> n >> x;
		rep(i, 0, x) ans = (ans * n) % MOD;
		cout << ans << line;
	}
}