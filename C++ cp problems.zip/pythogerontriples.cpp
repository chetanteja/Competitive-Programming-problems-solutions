#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, cnt = 0;
		cin >> n;
		ll i = 3;
		while (1) {
			x = i * i - 1;
			x = x / 2;
			if (x + 1 <= n) {
				i += 2; cnt++;
			}
			else {
				break;
			}
		}
		cout << cnt << line;

	}
}