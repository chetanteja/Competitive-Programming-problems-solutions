#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, a = 0, b = 0, flag = 0;
		cin >> n;
		string s, z;
		cin >> s;
		cin >> z;
		rep(i, 0, n) {
			if (s[i] == '0') {
				a++;
			}
			if (s[i] == '1') {
				b++;
			}
			if (s[i] == '0') {
				a++;
			}
			if (s[i] == '1') {
				b++;
			}
			if ((s[i] == z[i]) != (s[i + 1] == z[i + 1])) {
				if (a != b) {
					cout << "NO" << line;
					flag = 1;
					//return 0;
					break;
				}
			}

		}
		if (flag == 1)
		{
			continue;
			/* code */
		}
		cout << "YES" << line;
	}
}