#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)


void Print(vector<ll> v) {
	ll n = v.size();
	cout << v[0];
	ll  i = 1;
	while (i < n) {
		cout << "." << v[i];
		i++;
	}
	cout << line;
}

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, p = 0;
		cin >> n;
		vector<ll> a;
		while (n--) {
			cin >> x;
			if (x == 1) {
				a.push_back(x);
				Print(a);
				continue;
			}
			p = a.back();
			//cout << x << line;
			while (x != p + 1) {
				a.pop_back();
				p = a.back();
			}
			a.pop_back();
			a.push_back(x);
			Print(a);
		}
	}
}