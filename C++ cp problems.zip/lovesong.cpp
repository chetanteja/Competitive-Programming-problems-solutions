#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, x, q, l, r;
	cin >> n >> q;
	string s;
	cin >> s;
	ll dp[n + 1];
	memset(dp, 0, sizeof(dp));
	rep(j, 1, n + 1) {
		dp[j] = (s[j - 1] - 'a') + 1 + dp[j - 1];
		//cout << j << " " << dp[j] << line;
	}
	rep(i, 0, q) {
		x = 0;
		cin >> l >> r;

		x = dp[r] - dp[l - 1];
		cout << x << line;
	}

}