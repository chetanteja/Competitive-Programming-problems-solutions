#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, a, flag = 0;
		cin >> n;
		//cout << x << n;
		x = 1;
		for (ll i = 2; x < n; i++) {
			a = cbrt(n - x);
			if ((a * a * a) == n - x) {
				cout << "YES" << line;
				flag = 1;
				break;
			}
			x = i * i * i;
		}
		if (flag == 0) {
			cout << "NO" << line;
		}
	}
}