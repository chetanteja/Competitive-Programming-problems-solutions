#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, x, a, b, i;
	cin >> n;
	string s;
	cin >> s;

	map<ll, ll> m;
	ll ans = 0;
	m[0] = -1;
	a = 0;
	b = 0;
	for (i = 0; i < n; i++)
	{
		if (s[i] == '1')
		{
			a++;
		}
		else
		{
			b++;
		}
		if (m.find(a - b) != m.end())
		{
			ans = max(ans, i - m[a - b]);
		}
		else
		{
			m[a - b] = i;
		}
	}
	cout << ans << endl;

}