#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, m, i, j = 0, ans = 0;
		cin >> n >> m;
		ll a[n], b[m];
		rep(i, 0, n) cin >> a[i];
		rep(i, 0, m) cin >> b[i];
		sort(a, a + n);
		for (i = n - 1; i >= 0; i--) {
			x = b[a[i] - 1];
			if (b[j] < x) ans += b[j], j++;
			else ans += x;
		}
		//cout << "hell" << line;
		cout << ans << line;


	}
}