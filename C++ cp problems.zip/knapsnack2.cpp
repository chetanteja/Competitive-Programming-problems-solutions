#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)
//const INF 1e18;
#define INF 1e9

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, x, i, W, s = 0, j;
	cin >> n >> W;
	ll val[n + 1], wt[n + 1];
	rep(i, 1, n + 1) {
		cin >> wt[i] >> val[i];
		s = s + val[i];
	}
	wt[0] = 0; val[0] = 0;
	//cout << "hello" << line;

	ll dp[s + 1];
	rep(i, 0, s + 1) dp[i] = INF;
	dp[0] = 0;
	rep(i, 1, n + 1) {
		for (int j = s; j >= val[i]; j--)
		{
			dp[j] = min(dp[j], dp[j - val[i]] + wt[i]);
		}
	}
	for (int i = s; i >= 0; --i)
	{
		if (dp[i] <= W) {
			cout << i << line;
			break;
		}
	}
}