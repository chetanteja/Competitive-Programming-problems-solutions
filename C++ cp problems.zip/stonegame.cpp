#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, y;
		cin >> n;
		vector<ll> v;
		rep(i, 0, n) cin >> x, v.push_back(x);
		x = max_element(v.begin(), v.end()) - v.begin();
		//x = it - v.begin();
		y = min_element(v.begin(), v.end()) - v.begin();
		//y = it1 - v.begin();
		//cout << x << " " << y << line;
		ll ans = min(max(x + 1, y + 1), max(n - x, n - y));
		ans = min(ans, 1 + x + n - y);
		ans = min(ans, 1 + y + n - x);
		cout << ans << line;
	}
}