#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x = -1;
		cin >> n;
		ll a[n];
		rep(i, 0, n) cin >> a[i];
		ll i = 0;
		while (i < n) {
			if (a[i] == 1) {
				i++;
				continue;
			}
			break;
		}
		//cout << i << line;
		if (i != n && i % 2 == 0) {
			x = 1;
		}
		else if (i != n && i % 2 != 0) {
			x = 0;
		}
		if (i == n && i % 2 == 0) {
			x = 0;
		}
		if (i == n && i % 2 != 0) {
			x = 1;
		}
		if (x == 1) {
			cout << "First\n";
		}
		if (x == 0) {
			cout << "Second\n";
		}
	}
}