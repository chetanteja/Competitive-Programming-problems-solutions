#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, l;
		cin >> n >> l;
		int a[n];
		rep(i, 0, n) {
			cin >> a[i];
		}
		ll max = *max_element(a, a + n);
		//cout << max << line;
		max = 10 * l;
		bool dp[max + 1];
		memset(dp, false, sizeof(dp));
		//rep(i,0,10) dp[i]=0;
		//dp[l] = true;
		for (ll i = 1; i < max + 1; i++) {
			if (i % l == 0) {
				//cout << i << line;
				dp[i] = true;
				continue;
			}
			if (i >= 10) {
				dp[i] = dp[i - 10];
			}

		}
		//cout << dp[7] << line;
		rep(i, 0, n) {
			if (a[i] >= max || dp[a[i]]) {
				cout << "YES" << line;
			}
			else {
				cout << "NO" << line;
			}

		}




	}
}