#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, ans = 1e9 + 7;
		cin >> n;
		map <ll, ll>a, b;
		rep(i, 0, n) {
			cin >> x;
			a[x]++;
			b[a[x]]++;
			ans = min(ans, n - a[x] * b[a[x]]);
		}
		cout << ans << line;
	}
}