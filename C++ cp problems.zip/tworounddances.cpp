#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)
ll fac[10] = {1, 1, 2, 6, 24, 120, 720, 5040, 40320, 362880};

ll binomialCoeff(ll n, ll k)
{
	ll C[n + 1][k + 1];
	ll i, j;

	// Calculate value of Binomial Coefficient
	// in bottom up manner
	for (i = 0; i <= n; i++) {
		for (j = 0; j <= min(i, k); j++) {
			// Base Cases
			if (j == 0 || j == i)
				C[i][j] = 1;

			// Calculate value using previously
			// stored values
			else
				C[i][j] = C[i - 1][j - 1] + C[i - 1][j];
		}
	}

	return C[n][k];
}

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, x;
	cin >> n;
	x = n / 2;
	x = fac[x - 1] * fac[x - 1];
	x = x * (binomialCoeff(n, n / 2));
	x = x / 2;
	cout << x;
}