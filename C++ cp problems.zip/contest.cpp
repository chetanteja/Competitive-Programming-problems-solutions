#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, k;
		cin >> n >> k;
		ll a[n];
		rep(i, 0, n) {
			cin >> a[i];
		}
		ll i = 0;
		while (k--) {
			if (i >= n) {
				break;
			}
			if (a[i] > 0) {
				a[i]--;
				a[n - 1]++;
			}
			else {
				i++;
				k++;
			}

		}
		rep(i, 0, n) {
			cout << a[i] << " ";
		}
		cout << line;


	}
}