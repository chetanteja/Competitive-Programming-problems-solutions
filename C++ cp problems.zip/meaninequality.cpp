#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x;
		cin >> n;
		ll a[2 * n], b[2 * n];
		rep(i, 0, 2 * n) {
			cin >> a[i];
			//cout << a[i] << " ";
		}
		ll j = 0, i, N = 2 * n;
		sort(a, a + N);
		//cout << n << line;
		for (i = 0; i < n; i++) {
			b[j] = a[i];
			//cout << b[i] << " ";
			j++;
			b[j] = a[N - 1 - i];
			j++;
		}
		for (i = 0; i < N; i++) {
			cout << b[i] << " ";
		}
		cout << line;

	}
}