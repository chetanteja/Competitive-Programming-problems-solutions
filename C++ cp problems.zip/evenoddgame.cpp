#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x = 0, y = 0, i, j;
		cin >> n;
		ll a[n];
		rep(i, 0, n) cin >> a[i];
		ll ans = 0;
		sort(a, a + n);
		for (i = n - 1; i >= 0; i--) {
			if (a[i] % 2 == 0) ans += a[i];
			i--;
			if (i < 0)break;
			if (a[i] % 2 == 1)ans -= a[i];
		}
		if (ans > 0)cout << "Alice\n";
		else if (ans == 0)cout << "Tie\n";
		else cout << "Bob\n";		if (x > y) {
			cout << "Alice\n";
		}


}
}