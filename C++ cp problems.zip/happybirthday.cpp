#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n = 10, x, ans, i;
		ll a[n];
		rep(i, 0, n) cin >> a[i];
		i = 1;
		x = 1;
		while (1) {
			if (a[i] < x) {
				ans = i;
				break;
			}
			if (i == 0) {
				x++;
			}
			if (i == 9) {
				i = -1;
			}
			i++;
		}
		if (i == 0) {
			//cout << "hello";
			cout << "1";
			rep(j, 0, x) cout << "0";
			cout << line;

			continue;
		}
		//cout << "yes";
		rep(j, 0, a[i] + 1) cout << i;
		cout << line;
	}
}