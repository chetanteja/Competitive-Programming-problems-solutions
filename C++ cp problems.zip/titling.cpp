#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)
int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, i;
	cin >> n;
	ll dp[n + 1];
	dp[0] = 0;
	dp[1] = 1;
	rep(i, 2, n + 1) {
		dp[i] = dp[i - 1] + dp[i - 2];
	}
	cout << dp[n];
}