#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n, x = 1, j;
	cin >> n;
	ll a[n];
	j = 0;
	rep(i, 1, n) {
		if (gcd(i, n) == 1) {
			a[j++] = i;
			x = x * a[j - 1] % n;
			//cout << a[j - 1] << line;
		}
	}
	//cout << x << line;
	if (x != 1) j--;
	cout << j << line;
	rep(i, 0, j) {
		if (a[i] != x || x == 1) {
			cout << a[i] << " ";
		}
	}
}