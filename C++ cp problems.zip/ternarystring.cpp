#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, y, m = 10000000;
		string s;
		cin >> s;
		ll a[3] = { -1, -1, -1};
		for (ll i = 0; i < s.size(); i++) {
			a[s[i] - '1'] = i;
			if (a[0] != -1 && a[1] != -1 && a[2] != -1) {
				x = min(min(a[0], a[1]), a[2]);
				y = max(max(a[0], a[1]), a[2]);
				if (y - x + 1 < m) {
					//cout << i << line;
					m = y - x + 1;
				}
			}
		}
		if (a[0] != -1 && a[1] != -1 && a[2] != -1) {
			cout << m << line;
		}
		else {
			cout << "0\n";
		}
	}
}