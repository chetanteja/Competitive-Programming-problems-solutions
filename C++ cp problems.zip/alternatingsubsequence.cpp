#include<bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl
#define rep(i,x,n) for (ll i = x; i < n; ++i)

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int t;
	cin >> t;
	while (t--) {
		ll n, x, s = 0, m;
		cin >> n;
		ll a[n];
		rep(i, 0, n) cin >> a[i];
		rep(i, 0, n) {
			//cin >> a[i];
			if (a[i] > 0) {
				m = -1 * INT_MAX;
				while (i < n) {
					if (a[i] < 0) {
						i--;
						break;
					}
					m = max(m, a[i]);
					i++;
				}
				s += m;
			}
			else if (a[i] < 0) {
				m = -1 * INT_MAX;
				while (i < n) {
					if (a[i] > 0) {
						i--;
						break;
					}
					m = max(m, a[i]);
					i++;
				}
				s += m;
			}
		}
		cout << s << line;
	}
}