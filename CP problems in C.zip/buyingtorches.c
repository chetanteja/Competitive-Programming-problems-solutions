#include<stdio.h>

int main(){
    int t;
    scanf("%d",&t);
    while (t--)
    {
        long long int x,i,n,y,k;
        scanf("%lld%lld%lld",&x,&y,&k);
        i=(y*k)+k;
        i--;
        n=x-1;
        y=i/n;
        if(i%n!=0){
            y++;
        }
        printf("%lld\n",y+k);

    }
}