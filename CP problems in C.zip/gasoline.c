#include<stdio.h>

int main(){
    int n,t,i,p,count;
    scanf("%d",&t);
    if(t<1||t>100){
        return 0;
    }
    while(t--){
        scanf("%d",&n);
        if(n<1||n>100){
            return 0;
        }
        int a[n];
        for(i=0;i<n;i++){
            scanf("%d",&a[i]);
            if(a[i]<0||a[i]>100){
                return 0;
            }
        }
        p=a[0];
        if(p<1){
            printf("0\n");
            continue;
        }
        p--;
        count=1;
        for(i=1;p+a[i]!=0&&i<n;i++){
            p=p+a[i];
            p--;
            count++;
        }
        count+=p;
        printf("%d\n",count);
    }
}
