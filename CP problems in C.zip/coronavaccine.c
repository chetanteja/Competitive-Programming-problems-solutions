#include<stdio.h>

int main(){
    int v1,v2,d1,d2,p,i=0,sum=0;
    scanf("%d %d %d %d %d",&d1,&v1,&d2,&v2,&p);
        while(1){
            i++;
            if(sum>=p){
                printf("%d",--i);
                break;
            }
            if(i>=d1){
                sum=sum+v1;
            }
            if(i>=d2){
                sum=sum+v2;
            }
        }
}
