#include<stdio.h>

int main(){
    int t,n,q,i;
    scanf("%d %d",&n,&q);
    int a[n+q];
    for(i=q;i<n+q;i++){
        scanf("%d",&a[i]);
    }
    t=q;
    int y=n+q;
    while(t--){
        int k;
        scanf("%d",&k);
        for(i=q;i<y;i++){
            if(a[i]==-1){
                continue;
            }
            if(a[i]==k){
                printf("%d ",i-q+1);
                a[--q]=k;
                a[i]=-1;
                //printf("%d \n",i-q+1);
                break;
            }
        }
    }
    for(i=q;i<y;i++){
        if(a[i]!=-1){
            //printf("%d ",a[i]);
        }
    }
}
