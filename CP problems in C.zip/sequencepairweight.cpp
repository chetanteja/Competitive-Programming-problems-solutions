#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl

int main(){
    int t;
    cin>>t;
    while (t--)
    {
        /* code */
        ll x,y=0,n,i,z=-1,a;
        cin >> n;
        vector<int> v(1000000000,0);
        cin>>x;
        v[x]++;
        z=x;
        for ( i = 1; i < n; i++)
        {
            /* code */
            cin>>x;
            v[x]++;
            if(z!=x){
                y=y+a;
            }
            if(v[x]>1){
            x=v[x];
            a=(x*(x-1))/2;
            y=y+a;
            }
            z=x;
        }
        cout<<y<<line;
        

    }
    

}
