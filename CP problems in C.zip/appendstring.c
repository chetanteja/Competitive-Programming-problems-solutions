#include<stdio.h>

int main(){
    int t,n,i,x,y=0;
    scanf("%d",&t);
    while(t--){
        y++;
        scanf("%d",&n);
        int a[n];
        for(i=0;i<n;i++){
            scanf("%d",&a[i]);
        }
        int count=0;
        i=1;
        while(i<n){
            if(a[i]<=a[i-1]){
                //printf("hell\n");
                a[i]=10*a[i];
                count++;
                x=a[i-1]-a[i];
                if(x>=0&&x-9<0){
                    a[i]=a[i-1]+1;
                }
                continue;
            }
            i++;
        }

        printf("Case #%d: %d\n",y,count);

    }
}
