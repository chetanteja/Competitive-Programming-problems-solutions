5 1 6 1
2
2 0 1
3 2 3 4

Process returned 0 (0x0)   execution time : 6.726 s
Press any key to continue.
