#include<stdio.h>

int main(){
    int t,z=0;
    scanf("%d",&t);
    while(t--){
        z++;
        int n,i,j,x,k;
        scanf("%d",&n);
        char a[n];
        scanf("%s",a);
        printf("Case #%d: ",z);
        for(i=0;i<n;i++){
            x=1;
            j=i-1;
            k=i;
            while(j>=0){
                if(a[j]>=a[k]){
                    break;
                }
                x++;
                j--;
                k--;
            }
            printf("%d ",x);
        }
        printf("\n");

    }
}
