#include<stdio.h>

int GET(int n){
    if(n==0){
        return 0;
    }
    if(n==1){
        return 20;
    }
    if(n==2){
        return 36;
        //34
    }
    if(n==3){
        return 51;
        //48
        //54
        //40-4+20-5
        //51
    }
}

int main(){
    long long int t,n,i,x;
    scanf("%lld",&t);
    while(t--){
        x=0;
        scanf("%lld",&n);
        x=GET(n%4);
        i=n/4;
        x+=11*i*4;
        if(i>=1){
            x+=(4*(4-(n%4)));
        }
        printf("%lld\n",x);
    }
}
