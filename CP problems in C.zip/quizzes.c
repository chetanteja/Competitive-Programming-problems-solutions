#include<stdio.h>
#include<stdlib.h>
int main()
{
	int n,k,i;
	scanf("%d%d",&n,&k);
	char s[n];
	scanf("%s",s);
	for(i=0;i<n;i++)
	{
		if(s[i]=='o')
		{
			k=k+1;
		}
		if(s[i]=='x')
		{
			if(k>0)
			{
				k=k-1;
			}
		}
	}
	printf("%d",k);
}
