#include<stdio.h>

int main(){
    int t;
    float ans,a;
    scanf("%d",&t);
    while(t--){
        scanf("%f",&a);
        ans=1.15*a;
        printf("%.2f\n",ans);
    }
}
