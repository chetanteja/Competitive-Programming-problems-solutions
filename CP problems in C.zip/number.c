#include<stdio.h>

int main(){
    int t,n,x,y,check,z;
    scanf("%d",&t);
    while(t--){
        check=0;
        scanf("%d",&n);
        x=n%10;
        if(1){
            y=x*2021;
            z=n-y;
            if(z%2020==0&&z>=0){
                printf("YES\n");
            }
            else{
                while(y<n){
                    x=x+10;
                    y=x*2021;
                    z=n-y;
                    if(z%2020==0&&z>=0){
                        printf("YES\n");
                        check=1;
                        break;
                    }
                }
                if(check==0){
                    printf("NO\n");
                }
            }
        }
    }
}
