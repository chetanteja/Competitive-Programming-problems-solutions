#include<stdio.h>
int main()
{
	long long int t;
	scanf("%lld",&t);
	while(t--)
	{
		long long int n,m,k;
		scanf("%lld %lld %lld",&n,&m,&k);
		if((n*m)-1 == k)
		{
			printf("YES\n");
		}
		else
		{
			printf("NO\n");	
		}
	}
}