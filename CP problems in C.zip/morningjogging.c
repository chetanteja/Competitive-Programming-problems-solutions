#include<stdio.h>
#include<stdlib.h>
int cmpfunc (const void * a, const void * b) {
   return ( *(int*)a - *(int*)b );
}
int main(){
    int t;
    scanf("%d",&t);
    while(t--){
        int n,i=0,x,m,j,y;
        scanf("%d%d",&n,&m);
        x=0;
        for ( j = 0; j < n; j++)
        {
            int a[m];
            for ( i = 0; i < m; i++)
            {
                /* code */
                scanf("%d",&a[i]);
            }
            qsort(a, m, sizeof(int), cmpfunc);
            for (y=0,i = m-1;y==x; i--,y++)
            {
                /* code */
                printf("%d ",a[i]);
            }
            for ( i = 0; i < x; i++)
            {
                /* code */
                printf("%d ",a[i]);
            }
            printf("\n");
        }

        
    }
}