#include<stdio.h>

int main(){
    int t,n,i,y,sum;
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        char a[n];
        scanf("%s",a);
        y=0;
        int x;
        for(i=0;i<n;i++){
            if(a[i]=='0'){
                x=0;
            }
            else{
                x=1;
            }
            sum=1+x;
            if(y==sum){
                printf("0");
                y=x;
            }
            else{
                printf("1");
                y=sum;
            }
        }
        printf("\n");
    }
}
