#include<stdio.h>
#include<math.h>
int Power(int n)
{
    int i;
    for (i=0; i<26; i++)
    {
        if(n==pow(2,i)){
            return i;
        }
    }
    return -1;
}

int main(){
    int t,n,k,i,j,x;
    scanf("%d",&t);
    while(t--){
        scanf("%d %d",&n,&k);
        int a[n];
        j=0;x=1;
        while(n>0){
            if(k%2!=0){
                n--;
                k--;
                a[j++]=Power(x);
                continue;
            }
            x=2*x;
            k=k/2;
            if(k==1){
               a[j++]=Power(x);
               break;
            }
        }
        printf("%d\n",k);
        if(Power(k)==-1){
            printf("-1\n");
            continue;
        }
        for(i=0;i<j;i++){
            printf("%d\n",a[i]);
        }
    }
}
