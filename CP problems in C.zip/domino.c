#include<stdio.h>
#include<stdlib.h>

int MIN(int a,int b){
    if(a<b){
        return a;
    }
    return b;
}

int MAX(int a,int b){
    if(a>b){
        return a;
    }
    return b;
}

int main(){
    int t,n,i,x,k1,k2,w,b;
    scanf("%d",&t);
    while(t--){
        scanf("%d %d %d",&n,&k1,&k2);
        scanf("%d %d",&w,&b);
        x=abs(k1-k2);
        int y=MIN(k1,k2);
        int a=MAX(k1,k2);
        int z=2*n-(k1+k2);
        if(2*w>k1+k2||2*b>z){
            printf("NO\n");
            continue;
        }
        w=2*w-2*y;
        if(w>x||w%2!=0){
            printf("NO\n");
            continue;
        }
        printf("YES\n");
    }
}
