#include<stdio.h>

int main(){
    long long int n,a,b,k,x,p;
    scanf("%lld %lld %lld",&n,&a,&b);
    if(n>1000000000000000000||n<1||a<0||b<0){
        return 0;
    }
    x=a+b;
    if(x<0||x>1000000000000000000){
        return 0;
    }
    if(n==x){
        printf("%lld",a);
    }
    if(n<x){
        if(n<a){
            printf("%lld",n);
        }
        else{
            printf("%lld",a);
        }
    }
    if(n>x){
        k=n/x;
        p=n%x;
        if(p>=a){
            p=a;
        }
        printf("%lld",k*a+p);
    }
}
