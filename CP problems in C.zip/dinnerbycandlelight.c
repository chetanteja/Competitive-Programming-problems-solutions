#include<stdio.h>
int main(){
    long long int t,n,i,a,x,y;
    scanf("%lld",&t);
    while(t--){
        scanf("%lld %lld %lld",&a,&y,&x);
        if(a>=y){
            printf("%lld\n",x*y);
        }
        else{
            printf("%lld\n",1+x*a);
        }
    }
}
