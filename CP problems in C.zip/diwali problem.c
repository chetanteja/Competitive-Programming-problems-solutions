#include<stdio.h>

int main(){
    long long int n,i,f;
    float c,max;
    scanf("%lld",&n);
    if(n<0||n>100000){
        return 0;
    }
    scanf("%f",&max);
    if(max<0||max>100000000){
        return 0;
    }
    for(i=0;i<n;i++){
        scanf("%lld",&f);
        c=(f*9)/5+32;
        if(c<max){
            printf("YES");
        }
        else{
            printf("NO");
        }
    }


}
