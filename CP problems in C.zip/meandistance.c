#include<stdio.h>
#include<stdlib.h>
int fact(int n)
{
    int res = 1, i;
    for (i = 2; i <= n; i++)
        res *= i;
    return res;
}
int main(){
	int n,i,j,sum1=0,sum2=0;
	scanf("%d",&n);
	int a[n];
	int b[n];
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++){
		scanf("%d",&b[i]);
	}
	int c[9];
	for(i=0;i<9;i++){
		c[i]=0;
	}
	for(i=0;i<n;i++){
		int count=0;
		c[a[i]]++;
		for(j=a[i];j>0;j--){
			if(c[j]==0){
				count++;
			}
		}
			sum1=sum1+(count*fact(n-i-1));
	}
	for(i=0;i<9;i++){
		c[i]=0;
	}
	for(i=0;i<n;i++){
		int count=0;
		c[b[i]]++;
		for(j=b[i];j>0;j--){
			if(c[j]==0){
				count++;
			}
		}
			sum2=sum2+(count*fact(n-i-1));
	}
	printf("%d",abs(sum1-sum2));
}
