#include<stdio.h>
int multiply(int a,int b,int ans){
    if(b==0){
        return ans;
    }
    ans=ans+a;
    b--;
    multiply(a,b,ans);
}

int main(){
    int a,b,ans=0;
    scanf("%d",&a);
    scanf("%d",&b);
    printf("%d",multiply(a,b,ans));
    return 0;
}
