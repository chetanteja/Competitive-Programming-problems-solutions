#include<stdio.h>

int main(){
    int t;
    scanf("%d",&t);
    while (t--)
    {
        /* code */
        int n,x=0,i,y;
        scanf("%d",&n);
        char a[n];
        scanf("%s",a);
        int b[n];
        int j=0;
        for ( i = 0; i < n; i++)
        {
            if(a[i]=='*'){
                b[j]=i;
                j++;
                x=x+i;
            }
        }
        if(j==0){
            printf("0\n");
            continue;
        }
        int c[j];
        int d[j];
        y=0;
        b[j]=-1;
        for ( i = 0; i<j; i++)
        {
            c[i]=y;
            y=y+b[i];
            d[i]=x-y;
        }
        int z=0,min=10000000,q=0;
        for ( i = 0; i<j; i++)
        {
            x=j-i-1;
            y=b[i]+1;
            //n/2*(2*a+n-1)
            z=(x/2)*(2*y+(x-1));
            q=(i/2)*(2*(b[i]-i)+(i-1));
            q=q-c[i];
            z=d[i]-z;
            z=z+q;
            if(z<min){
                min=z;
            }
        }
        printf("%d\n",min);
        
    }
    
}