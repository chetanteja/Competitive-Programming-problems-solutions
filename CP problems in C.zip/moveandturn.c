#include<stdio.h>

int main(){
    int n,x,ans;
        scanf("%d",&n);
        x=n/2;
        if(n==2){
            printf("4\n");
            return 0;
        }
        if(n%2==0){
            if(n%6==0){
                n=0;
            }
            ans=(x*x)+n+1;
            printf("%d\n",ans);
        }
        else{
            ans=4*(x*x)+(n-1)*2+4;
            printf("%d\n",ans);
        }
}
