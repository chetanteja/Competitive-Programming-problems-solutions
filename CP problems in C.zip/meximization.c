#include<stdio.h>
#include<stdlib.h>

int comparator (const void * p1, const void * p2)
{
  return (*(int*)p1 - *(int*)p2);
}

int main(){
    int t,n,i,x;
    scanf("%d",&t);
    int hash[101];
    while(t--){
        scanf("%d",&n);
        int a[n];
        for(i=0;i<=100;i++){
            hash[i]=0;
        }
        int j=0;
        for(i=0;i<n;i++){
            scanf("%d",&x);
            if(hash[x]==0){
                a[j]=x;
                j++;
                hash[x]++;
                continue;
            }
            hash[x]++;
        }
        for(i=0;i<=100;i++){
            if(hash[i]!=0){
                printf("%d ",i);
                hash[i]--;
            }
        }
        for(i=0;i<=100;i++){
            while(hash[i]!=0){
                printf("%d ",i);
                hash[i]--;
            }
        }
        printf("\n");

    }
}
