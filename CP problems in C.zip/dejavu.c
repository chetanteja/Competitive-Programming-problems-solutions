#include<stdio.h>
#include<string.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,i,k=0;
		char s[1000000];
		scanf("%s",&s);
		n=strlen(s);
		for(i=0;i<n;i++){
			if(s[i]!='a'){
				break;
			}
		}
		if(i==n){
			printf("NO\n");
			continue;
		}
		else{
			printf("YES\n");
		}
		for(i=0;i<n;i++){
			if(s[n-1-i]!='a'&&k==0){
				printf("%c",'a');
				k=1;
			}
			printf("%c",s[i]);
		}
		printf("\n");
	}
}
