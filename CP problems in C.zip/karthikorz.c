#include<stdio.h>
#include<string.h>
struct city{
	char s[100];
	int p;
	int index;
};
void swap(struct city *a,struct city *b){
	char t[100];
	strcpy(t,a->s);
	strcpy(a->s,b->s);
	strcpy(b->s,t);
	int x;
	x=a->p;
	a->p=b->p;
	b->p=x;
	x=a->index;
	a->index=b->index;
	b->index=x;
}
int max(struct city *a,struct city *b){
	int t;
	if(a->p<b->p){
		t=b->p;
		b->p=a->p;
		a->p=t;
		t=a->index;
		a->index=b->index;
		b->index=t;
	}
}
int main(){
	int n,i,j;
	scanf("%d",&n);
	struct city a[n];
	for(i=0;i<n;i++){
		scanf("%s",&a[i].s);
		scanf("%d",&a[i].p);
		a[i].index=i+1;
	}
	for(i=0;i<n;i++){
		for(j=i+1;j<n;j++){
			if(strcmp(a[i].s,a[j].s)>0){
				swap(&a[i],&a[j]);
			}
			if(strcmp(a[i].s,a[j].s)==0){
				max(&a[i],&a[j]);
			}
		}
	}
	for(i=0;i<n;i++){
		printf("%d\n",a[i].index);
	}
}
