#include<stdio.h>

int main(){
    int t,i;
    scanf("%d",&t);
    while(t--){
        char a[50];
        scanf("%s",a);
        for(i=0;a[i]!='\0';i++){
            if(i%2==0){
                if(a[i]=='a'){
                    a[i]='b';
                }
                else{
                    a[i]='a';
                }
            }
            else{
                if(a[i]=='z'){
                    a[i]='y';
                }
                else{
                    a[i]='z';
                }
            }
        }
        printf("%s\n",a);
    }
}
