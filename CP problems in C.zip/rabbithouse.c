#include<stdio.h>
#include<stdlib.h>
int count=0;
int chk(int n,int m,int a[n][m]){
    int check=0;
    int i,j;
    for(i=0;i<n;i++){
        for(j=0;j<m;j++){
            if(i>0&&a[i-1][j]-a[i][j]>1){
                count=count+a[i-1][j]-a[i][j]-1;
                a[i][j]=a[i-1][j]-1;
                check=1;
                break;
            }
            if(i<n-1&&a[i+1][j]-a[i][j]>1){
                count=count+a[i+1][j]-a[i][j]-1;
                a[i][j]=a[i+1][j]-1;
                check=1;
                break;
            }
            if(j>0&&a[i][j-1]-a[i][j]>1){
                //printf("hello1\n");
                count=count+a[i][j-1]-a[i][j]-1;
                a[i][j]=a[i][j-1]-1;
                check=1;
                break;
            }
            if(j<m-1&&a[i][j+1]-a[i][j]>1){
                //printf("hello2\n");
                count=count+a[i][j+1]-a[i][j]-1;
                a[i][j]=a[i][j+1]-1;
                check=1;
                break;
            }
            //printf("%d\n",j);
            //printf("hello\n");
        }
        if(check==1){
                //printf("exxx%d\n",j);
                chk(n,m,a);
        }
    }
}
int main(){
    int t,n,k,i,j,x,m,b=0;
    scanf("%d",&t);
    while(t--){
        b++;
        scanf("%d %d",&n,&m);
        int a[n][m];
        for(i=0;i<n;i++){
            for(j=0;j<m;j++){
                scanf("%d",&a[i][j]);
            }
        }
        chk(n,m,a);
        printf("Case #%d: %d\n",b,count);
        count=0;

    }
}

