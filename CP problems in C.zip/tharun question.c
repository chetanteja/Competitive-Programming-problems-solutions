#include<stdio.h>
#include<stdlib.h>
int main(){
    int n,x,i,t;
    scanf("%d",&n);
    int *a=(int *)malloc(n*sizeof(int));
    scanf("%d",&x);
    t=n-1;
    for(i=x;i>1;i--){
        a[t]=t+1;
        t--;
    }
    t++;
    for(i=0;i<n+1-x;i++){
        a[i]=t;
        t--;
    }
    for(i=0;i<n;i++){
        printf("%d ",a[i]);
    }
}
