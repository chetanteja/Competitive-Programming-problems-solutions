#include<stdio.h>

int check(int n,int m,int a[n][m],int i,int j){
    int x=i,y=j;
    while(i<n&&j<m){
        if(a[i][j]!=a[x][y]){
            return 0;
        }
        i++;j++;
    }
    return 1;
}

int main(){
    int t,n,m,i,j,x,y,v,q,z1,z2;
    scanf("%d",&t);
    while(t--){
        scanf("%d %d",&n,&m);
        int a[n][m];
        for(i=0;i<n;i++){
            for(j=0;j<m;j++){
                scanf("%d",&a[i][j]);
            }
        }
        scanf("%d",&q);
        while(q--){
            scanf("%d %d %d",&x,&y,&v);
            a[x-1][y-1]=v;
            for(i=0;i<n-1;i++){
                z1=check(n,m,a,0,i);
                if(z1==0){
                    printf("No\n");
                    break;
                }
            }
            for(j=1;j<m-1&&z1!=0;j++){
                z2=check(n,m,a,j,0);
                if(z2==0){
                    printf("No\n");
                    break;
                }
            }
            if(z1!=0&&z2!=0){
                printf("Yes\n");
            }
        }
    }
}
