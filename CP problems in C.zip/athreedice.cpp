#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl

int main(){
    int a,b,c;
    cin>>a>>b>>c;
    cout<<21-(a+b+c);
}