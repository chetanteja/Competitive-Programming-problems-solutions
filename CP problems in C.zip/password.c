#include<stdio.h>
#include<string.h>
int main(){
	int t;
	scanf("%d",&t);
	char a[26]="abcdefghijklmnopqrstuvwxyz";
	char A[26]="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	char N[10]="0123456789";
	char sp[5]="@#%&?";
	while(t--){
		int n,i,j;
		int s=0,l=0,q=0,ne=0;
		char S[20];
		scanf("%s",&S);
		n=strlen(S);
		if(n<10){
			printf("NO\n");
			continue;
		}
		for(i=1;i<n-1;i++){
			for(j=0;j<26;j++){
				if(S[i]==a[j]){
					s=1;
					break;
				}
			}
			for(j=0;j<26;j++){
				if(S[i]==A[j]){
					l=1;
					break;
				}
			}
			for(j=0;j<10;j++){
				if(S[i]==N[j]){
					ne=1;
					break;
				}
			}
			for(j=0;j<5;j++){
				if(S[i]==sp[j]){
					q=1;
					break;
				}
			}
		}
		for(j=0;j<26;j++){
				if(S[0]==a[j]||S[n-1]==a[j]){
					s=1;
					break;
				}
		}
		if(s==1&&l==1&&q==1&&ne==1){
			printf("YES\n");
		}
		else{
			printf("NO\n");
		}
	}
}
