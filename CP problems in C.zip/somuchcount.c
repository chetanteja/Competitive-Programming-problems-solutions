#include<stdio.h>

int lcm(int a, int b){
    int m = 1;
    while(m%a || m%b) m++;
    return m;
}

int main(){
    int n,m,result,i,x,b;
    scanf("%d %d",&n,&m);
    int a[n];
    result=1;
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
        result = lcm(result, a[i]);
        b=result/a[i];
        if(b%2==0){
            printf("0");
            return 0;
        }
    }
    x=(2*m)/result;
    if(x%2==0){
        printf("%d",x/2);
        return 0;
    }
    printf("%d",x/2+1);
    return 0;
}
