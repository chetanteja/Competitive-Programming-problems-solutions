#include<stdio.h>
int main()
{
	int n,i,count;
	scanf("%d",&n);
	int l[n];
	count=0;
	for(i=0;i<n;i++)
	{
		scanf("%d",&l[i]);
	}
	for(i=1;i<n-1;i++)
	{
		if(l[i-1]>l[i+1])
		{
			if(l[i]<l[i-1]&&l[i]>l[i+1])
			{
				count=count+1;
			}
		}
		else
		{
			if(l[i]>l[i-1]&&l[i]<l[i+1])
			{
				count=count+1;
			}
		}
	}
	printf("%d",count);
}
