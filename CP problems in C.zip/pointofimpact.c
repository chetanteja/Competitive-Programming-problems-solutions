#include<stdio.h>
#include<stdlib.h>

int main(){
    int t,n,k,x,y,z;
    scanf("%d",&t);
    while(t--){
        scanf("%d %d %d %d",&n,&k,&x,&y);
        k=k%4;
        if(x==y){
            printf("%d %d\n",n,n);
            continue;
        }
        if(x>y){
            z=abs(x-y);
            if(k==1){
                x=n;
                y=x-z;
            }
            if(k==2){
                y=n;
                x=y-z;
            }
            if(k==3){
                x=0;
                y=x+z;
            }
            if(k==0){
                y=0;
                x=y+z;
            }
            printf("%d %d\n",x,y);
            continue;
        }
        else{
            z=abs(x-y);
            if(k==1){
                y=n;
                x=y-z;
            }
            if(k==2){
                x=n;
                y=x-z;
            }
            if(k==3){
                y=0;
                x=y+z;
            }
            if(k==0){
                x=0;
                y=x+z;
            }
            printf("%d %d\n",x,y);
            continue;
        }
    }
}
