#include<stdio.h>

int main(){
    int t;
    scanf("%d",&t);
    while(t--){
        int n,i,x;
        scanf("%d",&n);
        int a[n];
        for(i=0;i<n;i++){
            scanf("%d",&a[i]);
        }
        if(a[0]==a[1]){
            x=a[0];
        }
        else{
            x=a[2];
        }
        for(i=0;i<n;i++){
            if(x!=a[i]){
                printf("%d\n",i+1);
            }
        }
    }
}
