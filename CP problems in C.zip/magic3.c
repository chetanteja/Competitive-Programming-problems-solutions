#include<stdio.h>

int main(){
    int n,s,d,i,a,b,flag=0;
    scanf("%d %d %d",&n,&s,&d);
    for(i=0;i<n;i++){
        scanf("%d%d",&a,&b);
        if(a<s&&b>d){
            flag=1;
        }
    }
    if(flag==0){
        printf("No");
    }
    else{
        printf("Yes");
    }
    return 0;
}
