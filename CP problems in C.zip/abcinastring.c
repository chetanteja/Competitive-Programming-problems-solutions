#include<stdio.h>

int main(){
    int n,i,sum=0;
    scanf("%d",&n);
    char a[n];
    scanf("%s",a);
    for(i=0;a[i]!='\0';i++){
            if(a[i]=='A'&&a[i+1]=='B'&&a[i+2]=='C'){
                sum++;
                i=i+2;
            }
    }
    printf("%d",sum);
}

