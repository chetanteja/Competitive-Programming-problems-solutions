#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl

int main(){
    int t;
    cin>>t;
    while (t--)
    {
        /* code */
        ll n,x,y,i,min;
        cin>>n;
        ll a[n];
        min=1e9+7;
        x=-1;
        for ( i = 0; i < n; i++)
        {
            /* code */
            cin>>y;
            if (y < min) min = y, x = i;
        }
       
        cout <<n-1<<line;
        for ( i = 0; i < n; i++)
        {
            if(i==x){
                continue;
            }
            cout << x+1 << ' '<< i+1<<' '<<min<<' '<< abs(i-x)<<line;
        }
        
    }
    
}