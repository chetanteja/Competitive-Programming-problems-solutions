#include<stdio.h>

int MIN(int *a,int l,int b){
    int i,x=0,min=1000000;
    for(i=l;i<=b;i++){
        x++;
        if(a[i]<min){
            min=a[i];
        }
    }
    return x*min;
}

int main(){
    int n,l,b,x,i;
    scanf("%d",&n);
    int a[n];
    int max=0;
    int min=1000000;
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
        if(a[i]>max){
            max=a[i];
        }
        if(a[i]<min){
            min=a[i];
            x=i;
        }
    }
    if(min==a[0]){
        min=MIN(a,1,n-1);
    }
    if(min==a[n-1]){
        min=MIN(a,0,n-2);
    }
    else{
        l=MIN(a,0,x-1);
        b=MIN(a,x+1,n-1);
        if(l>b){
            min=l;
        }
        else{
            min=b;
        }
    }
    if(min>max){
        printf("%d",min);
    }
    else{
        printf("%d",max);
    }
}

