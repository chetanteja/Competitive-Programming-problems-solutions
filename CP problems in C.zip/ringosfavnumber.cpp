#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl

int main(){
    ll t,i,x;
    cin>>t;
    vector<int> v(200,0);
    for ( i = 0; i < t; i++)
    {
        /* code */
        cin>> x;
        v[x%200]++;
    }
    t=0;
    for ( i = 0; i < 200; i++)
    {
        /* code */
        if(v[i]!=0){
            x=v[i];
            x=(x*(x-1))/2;
            t+=x;
        }
    }
    cout<<t;

    
}
