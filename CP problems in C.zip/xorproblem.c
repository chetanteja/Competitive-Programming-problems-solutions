#include<stdio.h>

int main(){
    int t,n,a,b,z,i,count,x,y;
    scanf("%d",&t);
    if(t<1||t>1000){
        return 0;
    }
    while(t--){
        count=0;
        scanf("%d",&x);
        scanf("%d",&y);
        scanf("%d",&n);
        for(i=0;i<=n;i++){
            a=x^i;b=y^i;
            if(a<b){
                count++;
            }
        }
        printf("%d\n",count);
    }
    return 0;
}
