#include<stdio.h>

int GCD(int x,int y) {
    if (y != 0)
        return GCD(y, x % y);
    else
        return x;
}

int main(){
    int a,b,c,n,x,y;
    scanf("%d",&n);
    int i,j,k;
    long long sum=0;
    for(i=1;i<=n;i++){
        for(j=1;j<=n;j++){
            x=GCD(i,j);
            for(k=1;k<=n;k++){
                y=GCD(x,k);
                sum=sum+y;
            }
        }
    }
    printf("%d",sum);
}
