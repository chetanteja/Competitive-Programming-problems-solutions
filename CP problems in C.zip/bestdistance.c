#include<stdio.h>
#include<stdlib.h>

int main(){
    int n,x,j,z,i,min,k;
    scanf("%d",&n);
    int a[n],b[n],c[2*n];
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++){
        scanf("%d",&b[i]);
        c[i]=b[i];
    }
    j=0;
    while(i<2*n){
        c[i++]=b[j++];
    }

    for(j=0;j<n;j++){
        min=abs(a[0]-c[j]);
        i=1;
        k=1;
        z=j+1;
        while(k<n){
            k++;
            x=abs(a[i++]-c[z++]);
            if(x<min){
                min=x;
            }
        }
    printf("%d\n",min);
    }
}
