#include<stdio.h>

int main(){
    long long int t,n,k,x,i,y,count,z;
    scanf("%lld",&t);
    while(t--){
        count=0;
        scanf("%lld %lld",&n,&k);
        scanf("%lld",&x);
        for(i=1;i<n;i++){
            scanf("%lld",&y);
            if(count<(y*100)-(k*x)){
                count=(y*100)-(k*x);
            }
            x=x+y;
        }
        printf("%lld\n",(count+k-1)/k);

    }
}
