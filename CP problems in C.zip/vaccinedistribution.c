#include<stdio.h>

int main(){
    int t,n,d,i,x,y,count;
    scanf("%d",&t);
    while(t--){
        count=0;x=0;y=0;
        scanf("%d %d",&n,&d);
        int a[n];
        for(i=0;i<n;i++){
            scanf("%d",&a[i]);
            if(a[i]<=9||a[i]>=80){
                x++;
            }
        }
        if(d==1){
            printf("%d\n",n);
            continue;
        }
        y=n-x;
        count=x/d;
        if(x%d!=0){
            count++;
        }
        count=count+y/d;
        if(y%d!=0){
            count++;
        }
        printf("%d\n",count);
    }
}
