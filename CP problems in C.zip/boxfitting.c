#include<stdio.h>
int cmpfunc (const void * a, const void * b) {
   return ( *(int*)a - *(int*)b );
}
int main(){
    int t;
    int n,x,i,y,w,h;
    scanf("%d",&t);
    while(t--){
        h=0;
        scanf("%d %d",&n,&w);
        int a[n];
        for(i=0;i<n;i++){
            scanf("%d",&a[i]);
        }
        qsort(a, n, sizeof(int), cmpfunc);
        x=n-1;
        y=0;
        i=x;
        while(1){
            w=w-a[i];
            a[i]=100000;
            x--;
            j=x;
            while(i>=0){
                if(a[i]>w){
                    i--;
                    continue;
                }

            }
            h++;
        }

    }
}

