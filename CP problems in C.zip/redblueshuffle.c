#include<stdio.h>

int main(){
    int t,i,n;
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        char r[n],b[n];
        int countred=0,countblue=0;
        scanf("%s",&r);
        scanf("%s",&b);
        for(i=0;i<n;i++){
            if(r[i]>b[i]){
                countred++;
            }
            if(r[i]<b[i]){
                countblue++;
            }
        }
        if(countblue>countred){
            printf("BLUE\n");
        }
        if(countblue<countred){
            printf("RED\n");
        }
        if(countblue==countred){
            printf("EQUAL\n");
        }
    }
}
