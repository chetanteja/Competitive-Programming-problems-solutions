#include<stdio.h>
int main(){
    int i,z,l,m,j,k;
    scanf("%d",&z);
    for(i=0;i<z;i++){
            int a[4];
        scanf("%d %d",&l,&m);
        if(m%2!=0){
            printf("NO");
            return ;
        }
        for(j=0;j<l;j++){
            for(k=0;k<4;k++){
                scanf("%d",a[k]);
            }
            if(a[0]==a[2]){
                printf("YES");
                return ;
            }
        }
    }
}
