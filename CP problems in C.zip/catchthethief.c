#include<stdio.h>
#include<stdlib.h>
int main()
{
	int t,k,n,x,y,a;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d%d%d",&x,&y,&k,&n);
		a=abs(x-y);
		if(a%2!=0)
		{
			printf("No\n");
			continue;
		}
		a=a/2;
		if(a%k==0)
		{
			printf("Yes\n");
			continue;
		}
		printf("No\n");
	}
}
