#include<stdio.h>

int main(){
    long long int l=0,n,m,i,j,k=0,ans,count;
    scanf("%lld %lld",&n,&m);
    if(n<1||n>100000||m<0||m>100000){
        return 0;
    }
    long long int a[n],b[m],c[m+n];
    for(i=0;i<n;i++){
        scanf("%lld",&a[i]);
        for(j=0;j<i;j++){
            if(a[i]==a[j]){
                return 0;
            }
        }
    }
    for(i=0;i<m;i++){
        scanf("%lld",&b[i]);
        for(j=0;j<i;j++){
            if(b[i]==b[j]){
                return 0;
            }
        }
    }
    count=n+m-1;
    for(i=0;i<n;i++){
        for(j=0;j<m;j++){
            ans=a[i]+b[j];
            k=0;
            while(k<=l&&c[k]!=ans){
                if(k==l){
                    c[l]=ans;
                    printf("%lld %lld\n",i+1,j+1);
                    count--;
                }
                if(count==0){
                    return 0;
                }
                k++;
            }
            l++;
        }
    }
    return 0;
}
