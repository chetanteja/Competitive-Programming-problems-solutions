#include<bits/stdc++.h>
using namespace std;

int gcd(int a, int b){
   if(b==0)
      return a;
    return gcd(b, a % b);
}

int main(){
   int t;
   cin>>t;
   while(t--){
    int n,i,x;
    cin>>n;
        x=gcd(100,n);
        i=100/x;
        cout<<i<<endl;
   }
}

