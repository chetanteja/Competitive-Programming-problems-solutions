#include<stdio.h>

int SEARCH(int a[],int t){
    int i=0;
    while(a[i]!=t){
        i++;
    }
    return i;
}

int main(){
    int t,n,i,j,x;
    scanf("%d",&t);
    while(t--){
        int count=0;
        scanf("%d",&n);
        int w[n],l[n],a[n];
        for(i=0;i<n;i++){
            scanf("%d",&w[i]);
            a[i]=i+1;
        }
        for(i=0;i<n;i++){
            scanf("%d",&l[i]);

        }
        i=SEARCH(w,1);
        for(j=2;j<=n;j++){
            //printf("%d a[i]\n",a[i]);
            x=SEARCH(w,j);
            //printf("%d a[x]\n",a[x]);
            while(a[x]<=a[i]){
                a[x]=a[x]+l[x];
                count++;
            }
            //printf("count %d\n",count);
            i=x;

        }
        printf("%d\n",count);

    }
}
