#include<stdio.h>
#include<stdlib.h>

int main(){
    int t;
    int a,b,x,l,ans;
    scanf("%d",&t);
    while(t--){
        scanf("%d %d",&a,&b);
        printf("%d\n",a^b);
    }
}
