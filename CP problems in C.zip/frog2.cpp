#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl

ll ans=0;

int main(){
    ll i,n,k,j,m=0;
    cin>>n>>k;
    ll a[n];
    for ( i = 0; i < n; i++)
    {
        cin>>a[i];
    }
    vector<ll>d (n,2e9);
    d[0]=0;
    for(int i=1;i<n;i++){
    for(int j=i-1;j>=max(m, i-k);j--) {
        d[i] = min(d[j] + abs(a[i]-a[j]), d[i]); 
    }
  }
    cout<<d[n-1];
}