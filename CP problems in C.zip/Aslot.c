#include<stdio.h>

int main(){
    int n,a,b,x,i;
    scanf("%d %d",&n,&x);
    int sum=0;
    x=x*100;
    for(i=0;i<n;i++){
        scanf("%d %d",&a,&b);
        sum=sum+(a*b);
        if(sum>x){
            printf("%d",i+1);
            return 0;
        }
    }
    printf("-1");
    return 0;
}
