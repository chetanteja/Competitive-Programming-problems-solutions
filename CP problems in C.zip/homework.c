#include<stdio.h>

int main(){
    int n,m,i,sum=0;
    scanf("%d %d",&n,&m);
    int a[m];
    for(i=0;i<m;i++){
        scanf("%d",&a[i]);
        sum=sum+a[i];
    }
    if(sum>n){
        printf("-1");
    }
    else{
        printf("%d",n-sum);
    }

}
