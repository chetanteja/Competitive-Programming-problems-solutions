#include<stdio.h>
#include<stdlib.h>
int main(){
    int t,x,y,i;
    char c[1000000];
    scanf("%d",&t);
    while(t--){
            x=0;y=0;
        scanf("%s",&c);
        for(i=0;c[i]!='\0';i++){
            if(c[i]=='1'){
                x++;
            }
            else{
                y++;
            }
        }
        if(x==0||y==0){
            printf("-1\n");
            continue;
        }
        if(i%2!=0){
            printf("-1\n");
            continue;
        }
        printf("%d\n",abs(x-y)/2);
    }
}
