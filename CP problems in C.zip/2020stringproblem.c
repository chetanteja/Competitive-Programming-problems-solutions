#include<stdio.h>
int main(){
    int t,i,n,c,j,x;
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        char a[n];
        scanf("%s",&a);
        for(i=0;i<n;i++){

        }

    }
}

