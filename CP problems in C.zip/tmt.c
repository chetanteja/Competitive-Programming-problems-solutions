#include<stdio.h>

int main(){
    int t;
    scanf("%d",&t);
    while(t--){
        long long int n,i,x=0,y=0,j,check=0;
        scanf("%lld",&n);
        char a[n];
        scanf("%s",a);
        for(i=0;i<n;i++){
            if(a[i]=='T'){
                x++;
            }
            if(a[i]=='M'){
                y++;
                if(y>x){
                    check=1;
                    break;
                }
            }
        }
        if(2*y!=x){
            printf("NO\n");
            continue;
        }
        x=0,y=0;
        for(i=n-1;i>=0;i--){
            if(a[i]=='T'){
                x++;
            }
            if(a[i]=='M'){
                y++;
                if(y>x){
                    check=1;
                    break;
                }
            }
        }
        if(2*y!=x){
            check=1;
        }
        if(check==1){
            printf("NO\n");
            continue;
        }
        printf("YES\n");
    }
}

