#include<stdio.h>

int main(){
    int t;
    scanf("%d",&t);
    int i,l,r,ans;
    while(t--){
        ans=0;
        scanf("%d %d",&l,&r);
        ans=(2*r)-(2*l)+1;
        printf("%d\n",ans);
    }
}
