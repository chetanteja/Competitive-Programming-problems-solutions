#include<stdio.h>

int main(){
    int t,n,x,i,j,count=0,sum;
    scanf("%d",&t);
    while(t--){
        count=0;
        scanf("%d",&x);
        scanf("%d",&n);
        if(x<1||x>1000||n<1||n>1000){
            return 0;
        }
        int a[n];
        for(i=0;i<n;i++){
            scanf("%d",&a[i]);
            if(a[i]<1||a[i]>1000){
                return 0;
            }
        }
        for(i=0;i<n;i++){
            sum=1;
            for(j=i;j<n;j++){
                sum=sum*a[j];
                if(sum<x){
                    count++;
                }
                else{
                    break;
                }
            }
        }
        printf("%d\n",count);

    }
}
