#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl

int main(){
    ll t,i;
    cin>>t>>i;
    while (i--)
    {
        if(t%200==0){
            t=t/200;
        }
        else{
            t=t*1000+200;
        }
    }
    cout<<t;
}
