#include<stdio.h>

struct bag{
    int b;
    int index;
};

void swap(int *xp, int *yp)
{
    int temp = *xp;
    *xp = *yp;
    *yp = temp;
}

void bubbleSort(struct bag arr[], int n)
{
   int i, j;
   for (i = 0; i < n-1; i++)

       // Last i elements are already in place
       for (j = 0; j < n-i-1; j++)
           if (arr[j].b < arr[j+1].b) {
              swap(&arr[j].b, &arr[j+1].b);
              swap(&arr[j].index, &arr[j+1].index);
           }
}

int main(){
    int t,n,k,i,A,B,C,D;
    scanf("%d",&t);
        while(t--){
        scanf("%d %d",&n,&k);
        struct bag a[n+1];
        for(i=0;i<n+1;i++){
            scanf("%d",&a[i].b);
            a[i].index=i;
        }
        bubbleSort(a,n+1);
        for(i=0;i<n;i++){
            A=a[n-i].index;
            B=a[n-i].b;
            C=k-a[n-i].b;
            a[n-i].b=0;
            D=a[0].index;
            a[0].b=a[0].b-C;
            printf("%d %d %d %d\n",A,B,D,C);
            bubbleSort(a,n+1);
        }

    }
}
