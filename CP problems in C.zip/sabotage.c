#include<stdio.h>

int main(){
    long long int t,n,i,j,k,count,x;
    scanf("%lld",&t);
    while(t--){
        count=0;
        scanf("%lld",&n);
        int a[n];
        for(i=n-1;i>=0;i--){
            a[i]=0;
            k=i+1;
            j=i;
            x=n/k;
            while(x--){
                a[j]++;
                if(a[j]==5){
                    count++;
                }
                if(a[j]==6){
                    count--;
                }
                j=j+k;
            }
        }

        printf("%d\n",count);
    }
}
