#include<stdio.h>

int main (){
    long long int t,n,i;
    scanf("%lld",&t);
    while(t--){
        long long int min,count=1;
        scanf("%lld",&n);
        long long int a[n];
        scanf("%lld",&a[0]);
        min=a[0];
        for(i=1;i<n;i++){
            scanf("%lld",&a[i]);
            if(a[i]<=min){
                if(a[i]==min){
                    count++;
                }
                else{
                    min=a[i];
                    count=1;
                }
            }
        }
        long long int x=min+1000000000,check;
        //printf("%lld\n",count);
        if(count>1){
            for(i=0;i<n;i++){
            //printf("%lld\n",b[i]);
            if(a[i]!=min&&a[i]<x){
                x=a[i];
                check=1;
            }
        }
        }
        if(count==n){
            check=1;
        }
        if(check==1){
            printf("%lld\n",n);
            for(i=0;i<n;i++){
                printf("%lld ",i+1);
            }
            printf("\n");
            continue;
        }
        printf("%lld\n",n-count);
        for(i=0;i<n;i++){
            if(a[i]!=min){
                printf("%lld ",i+1);
            }
        }
        printf("\n");



    }
}
