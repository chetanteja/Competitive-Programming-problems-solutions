#include<stdio.h>

int main(){
    int t,n,k,i,x;
    scanf("%d",&t);
    while(t--){
        scanf("%d %d",&n,&k);
        x=n;
        if(n%2!=0){
            printf("%d %d %d\n",n/2,n/2,1);
        }
        else{
            n=n/2;
            if(n%2==0){
                printf("%d %d %d\n",n,n/2,n/2);
            }
            else{
                printf("%d %d %d\n",n-1,n-1,2);
            }
        }
    }
}

