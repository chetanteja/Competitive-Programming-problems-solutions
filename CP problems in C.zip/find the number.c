#include<stdio.h>
int main(){
    int n,i,m,s,c;
    scanf("%d",&n);
    if(n<1||n>3){
        return 0;
    }
    scanf("%d",&m);
    if(m<0||m>5){
        return 0;
    }
    int a[n];
    for(i=0;i<n;i++){
        a[i]=0;
    }
    for(i=0;i<m;i++){
        scanf("%d",&s);
        if(s<1||s>n){
            return 0;
        }
        scanf("%d",&c);
        if(c<0||c>9){
            return 0;
        }
        if(s==1&&c==0&&n==1){
            printf("0");
            return 0;
        }
        if(s==1&&c==0){
            printf("-1");
            return 0;
        }
        if(a[s-1]!=0&&a[s-1]!=c){
            printf("-1");
            return 0;
        }
        a[s-1]=c;
    }
    if(a[0]==0&&n!=1){
        a[0]=1;
    }
    if(a[0]==0){
        printf("-1");
    }
    else{
        for(i=0;i<n;i++){
            printf("%d",a[i]);
        }
    }
}
