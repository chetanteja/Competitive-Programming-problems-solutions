#include<stdio.h>
#include<stdlib.h>
int main(){
    int t,n,k,i,j,x,r,c,count,b=0;
    int u,d,l,R;
    scanf("%d",&t);
    while(t--){
        b++;
        x=0;
        scanf("%d%d",&r,&c);
        int a[r][c];
        for(i=0;i<r;i++){
            for(j=0;j<c;j++){
                scanf("%d",&a[i][j]);
            }
        }
        int z=0;
        for(i=0;i<r;i++){
            for(j=0;j<c;j++){
                int temp1=i,temp2=j;
                if(a[i][j]==1){
                u=i;d=i;l=j;R=j;
                count=0;
                while(u<r&&a[u][j]==1){
                    if(u!=i){
                        count++;
                    }
                    //printf("%d hello\n",a[u][j]);
                    u++;
                }
                u=count;
                count=0;
                while(d>=0&&a[d][j]==1){
                    if(d!=i){
                        count++;
                    }
                    d--;
                }
                d=count;
                count=0;
                while(l>=0&&a[i][l]==1){
                    if(l!=j){
                        count++;
                    }
                    l--;
                }
                l=count;
                count=0;
                while(R<c&&a[i][R]==1){
                    if(R!=j){
                        count++;
                    }
                    R++;
                }
                R=count;
                ++u,++d,++R,++l;
                //printf("%d %d %d %d\n",++u,++d,++R,++l);
                int I;
                if(u>=2&&l>=2){
                    for(I=2;I<=u;I++){
                        if(2*I<=l){
                            z++;
                        }
                        else{
                            break;
                        }
                    }
                    for(I=2;I<=l;I++){
                        if(2*I<=u){
                            z++;
                        }
                        else{
                            break;
                        }
                    }
                }
                if(u>=2&&R>=2){
                    for(I=2;I<=u;I++){
                        if(2*I<=R){
                            z++;
                        }
                        else{
                            break;
                        }
                    }
                    for(I=2;I<=R;I++){
                        if(2*I<=u){
                            z++;
                        }
                        else{
                            break;
                        }
                    }
                }
                if(d>=2&&l>=2){
                    for(I=2;I<=d;I++){
                        if(2*I<=l){
                            z++;
                        }
                        else{
                            break;
                        }
                    }
                    for(I=2;I<=l;I++){
                        if(2*I<=d){
                            z++;
                        }
                        else{
                            break;
                        }
                    }
                }
                if(d>=2&&R>=2){
                    for(I=2;I<=d;I++){
                        if(2*I<=R){
                            z++;
                        }
                        else{
                            break;
                        }
                    }
                    for(I=2;I<=R;I++){
                        if(2*I<=d){
                            z++;
                        }
                        else{
                            break;
                        }
                    }
                }




                }
                }
            }
            printf("Case #%d: %d\n",b,z);
        }

    }

