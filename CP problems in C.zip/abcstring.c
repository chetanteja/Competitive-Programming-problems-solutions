#include<stdio.h>
#include<string.h>
int MAX(int A,int B,int C)
{


    if (A >= B && A >= C)
        return A;

    if (B >= A && B >= C)
        return B;

    if (C >= A && C >= B)
        return C;

}

int main(){
    int t,n,i,c1=0,c2=0,c3=0,c;
    char a[51];
    scanf("%d",&t);
    while(t--){
    c1=0,c2=0,c3=0;
    c=0;
    scanf("%s",a);
    int b[3];
    for(i=0;i<3;i++){
        b[i]=-1;
    }
    n=strlen(a);
    for(i=0;a[i]!='\0';i++){
        if(a[i]=='A'){
            c1++;
        }
        if(a[i]=='B'){
            c2++;
        }
        if(a[i]=='C'){
            c3++;
        }
    }
    c=MAX(c1,c2,c3);
    //printf("%d max\n%d %d %d",c,c1,c2,c3);
    char x;
    if(c==c1){
        x='A';
    }
    if(c==c2){
        x='B';
    }
    if(c==c3){
        x='C';
    }
    //printf("%c\n",x);
    if(c!=n/2){
        printf("NO\n");
        continue;
    }
    if(a[0]==x){
        int count=0,check=0;
        for(i=0;i<n;i++){
            if(count<0){
                printf("NO\n");
                check=1;
                break;
            }
            if(a[i]==x){
                count++;
            }
            else{
                count--;
            }
        }
        if(check==0){
            printf("YES\n");
            continue;
        }
    }
    else{
        int count=0,check=0;
        for(i=0;i<n;i++){
            if(count<0){
                printf("NO\n");
                check=1;
                break;
            }
            if(a[i]==x){
                count--;
            }
            else{
                count++;
            }
            //printf("%d %d ",count,i);
        }
        if(check==0){
            printf("YES\n");
            continue;
        }
    }
    }


}
