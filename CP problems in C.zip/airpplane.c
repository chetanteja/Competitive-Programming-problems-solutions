#include<stdio.h>
#include<stdlib.h>
int main()
{
	int x,b,c;
	scanf("%d%d%d",&x,&b,&c);
	if(x>=b&&x>=c)
	{
		printf("%d",(b+c));
		return 0;
	}
	if(b>=x&&b>=c)
	{
		printf("%d",(x+c));
		return 0;
	}
	if(c>=b&&c>=x)
	{
		printf("%d",(x+b));
		return 0;
	}
}
