#include<stdio.h>

int main(){
    int n,i;
    scanf("%d",&n);
    n=n*n;
    char a[n];
    scanf("%s",a);
    char b[6]={'I','C','P','A','S','G'};
    for(i=0;a[i]!='\0';i++){
        if(a[i]=='I'){
            b[0]='x';
            continue;
        }
        if(a[i]=='C'){
            b[1]='x';
            continue;
        }
        if(a[i]=='P'){
            b[2]='x';
            continue;
        }
        if(a[i]=='A'){
            b[3]='x';
            continue;
        }
        if(a[i]=='S'){
            b[4]='x';
            continue;
        }
        if(a[i]=='G'){
            b[5]='x';
        }
    }
    for(i=0;i<6;i++){
        if(b[i]!='x'){
            printf("NO");
            return 0;
        }
    }
    printf("YES");
    return 0;
}
