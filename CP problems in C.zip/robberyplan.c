#include<stdio.h>

int main(){
    int t,i,x,y,n,m,a,b;
    scanf("%d",&t);
    while(t--){
        scanf("%d %d",&x,&y);
        scanf("%d %d",&a,&b);
        scanf("%d %d",&n,&m);
        for(i=0;i<a;i++){
            z=x-(n*i);
            if(z<z%m==0){

            }
        }
    }
}
