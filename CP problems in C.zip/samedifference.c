#include<stdio.h>
int h[200000];
int main(){
    int t;
    scanf("%d",&t);
    while (t--)
    {
        int n,x,i,b,c;
        scanf("%d",&n);
        int a[n];
        int b[n];
        for ( i = 0; i < n; i++)
        {
            /* code */
            scanf("%d",&a[i]);

            x=a[i]-i;
            h[x]++;
        }
        b=0;c=0;
        for ( i = 0; i < 200000; i++)
        {
            /* code */
            if(h[i]!=0){
                b=h[i];
                h[i]=0;
                c=c+((b*(b-1))/2);
            }
        }
        printf("%d\n",c);
    }
    
}