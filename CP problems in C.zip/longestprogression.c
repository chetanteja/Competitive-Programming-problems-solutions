#include<stdio.h>

int CHECK(int a[],int n){
    int x=1,max=0,i;
    int b[n-1];
    for(i=1;i<n;i++){
        b[i-1]=a[i]-a[i-1];
    }
    for(i=1;i<n-1;i++){
        //printf("%d ",b[i]);
        if(b[i]!=b[i-1]){
            if(x>max){
                max=x;
            }
            x=1;
        }
        else{
            x++;
        }
    }
    if(x>max){
        max=x;
    }
    //printf("%d\n",max);
    return max+1;
}

int main(){
    int t,z=0;
    scanf("%d",&t);
    while(t--){
        z++;
        int n,i,j,x,k,m,max=-1;
        scanf("%d",&n);
        int a[n];
        for(i=0;i<n;i++){
            scanf("%d",&a[i]);
        }
        printf("Case #%d: ",z);
        if(n<=3){
            printf("%d\n",n);
            continue;
        }
        i=0,j=2;
        max=CHECK(a,n);
        if(max==n||max==n-1){
            printf("%d\n",n);
            continue;
        }
        while(j<n){
            if(a[i]+a[j]!=2*a[i+1]){
                x=a[i]+a[j];
                if(x%2==0){
                    x=x/2;
                    k=a[i+1];
                    a[i+1]=x;
                    m=CHECK(a,n);
                    if(m>max){
                        max=m;
                    }
                    a[i+1]=k;
                }
            }
            if(max==n){
                break;
            }
            i++;j++;
        }
        printf("%d\n",max);
    }
}

