#include<stdio.h>
int main(){
    int t;
    scanf("%d",&t);
    while (t--){
        long long int i,x=0,n=0;
        char a[101];
        scanf("%s",a);
        for ( i = 0; a[i] != '\0' ; i++)
        {
            /* code */
            if(a[i]=='a'){
                x++;
            }
            else{
                n++;
            }
        }
        if(x<n){
            printf("%lld\n",x);
        }
        else{
            printf("%lld\n",n);
        }
    }    
}