#include<stdio.h>
#include<stdlib.h>

int max(int b[],int n){
    int i,max=0,t;
    for(i=0;i<n;i++){
        if(b[i]>=max){
            max=b[i];
            t=i;
        }
    }
    return t;
}

int min(int a[],int n){
    int i,min,t=0;
    min=a[0];
    for(i=1;i<n;i++){
        if(a[i]<min){
            min=a[i];
            t=i;
        }
    }
    return t;
}

int cmpfunc (const void * a, const void * b) {
   return ( *(int*)a - *(int*)b );
}

int main(){
    int t,n,s1,s2,m,x,y,temp,count,i,j;
    scanf("%d",&t);
    while(t--){
        scanf("%d%d",&n,&m);
        int a[n],b[m];
        s1=0,s2=0,count=0;
        for(i=0;i<n;i++){
            scanf("%d",&a[i]);
            s1=s1+a[i];
        }
        for(i=0;i<m;i++){
            scanf("%d",&b[i]);
            s2=s2+b[i];
        }
        qsort(a, n, sizeof(int), cmpfunc);
        qsort(b, m, sizeof(int), cmpfunc);
        i=0;j=m-1;
        while(s1<=s2&&i<n&&j>=0){
            x=i++;
            y=j--;
            temp=a[x];
            a[x]=b[y];
            b[y]=temp;
            s1=s1-b[y]+a[x];
            s2=s2-a[x]+b[y];
            count++;
        }
        if(s1>s2){
            printf("%d\n",count);
        }
        else{
            printf("-1\n");
        }
    }
}
