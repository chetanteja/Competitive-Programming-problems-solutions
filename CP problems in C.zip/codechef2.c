#include<stdio.h>
#include<math.h>
int main(){
    int t,i;
    long long int n,ans;
    scanf("%d",&t);
    if(t<1||t>10){
        return 0;
    }
    for(i=0;i<t;i++){
        scanf("%lld",&n);
        if(n<1||n>1000000000){
            return 0;
        }
        if(n==1){
            printf("2\n");
            continue;
        }
        ans=n*(2*n-1)+1;
        printf("%lld\n",ans);
    }
}
