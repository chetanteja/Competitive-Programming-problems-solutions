#include<stdio.h>
#include<stdlib.h>
int main(){
    int t,n,x[3],i,a,b,c;
    scanf("%d",&t);
    while(t--){
        a=0;b=0;c=0;
        scanf("%d",&n);
        int A[n];
        for(i=0;i<n;i++){
            scanf("%d",&A[i]);
            if(A[i]%3==0){
                a++;
            }
            if(A[i]%3==1){
                b++;
            }
            if(A[i]%3==2){
                c++;
            }
        }
        x[0]=a;
        x[1]=b;
        x[2]=c;
        n=n/3;
        int count=0;
        while(!((x[0]==x[1])&&(x[1]==x[2]))){
            for(i=0;i<3;i++){
                if(x[i]>n){
                    count++;
                    x[i]--;
                    x[(i+1)%3]++;
                }
            }
        }
        printf("%d\n",count);
    }
}
