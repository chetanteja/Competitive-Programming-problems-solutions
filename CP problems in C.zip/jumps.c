#include<stdio.h>
int main(){
    int t,x,n,i;
    scanf("%d",&t);
    while(t--){
        scanf("%d",&x);
        for(i=1;;i++){
            n=i*(i+1)/2;
            if(n>=x){
                break;
            }
        }
        if(n-x==1){
            printf("%d\n",i+1);
            continue;
        }
        printf("%d\n",i);
    }
}
