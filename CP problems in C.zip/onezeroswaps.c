#include<stdio.h>
#include<string.h>

int main(){
    int t,n,i,k,key,j;
    scanf("%d",&t);
    char a[100000],b[100000];
    while(t--){
        key=0;
        scanf("%d",&n);
        scanf("%s",a);
        scanf("%s",b);
        if(!strcmp(a,b)){
            printf("Yes\n");
            continue;
        }
        for(i=0;i<n;i++){
            if(a[i]=='1'&&b[i]=='0'){
                j=i+1;
                while(j<n){
                    if(a[j]=='0'&&b[j]=='1'){
                        a[j]='1';
                        a[i]='0';
                        if(!strcmp(a,b)){
                            printf("Yes\n");
                            key=1;
                            break;
                        }
                    }
                    j++;
                }
            }
            if(key==1){
                break;
            }
        }
        if(key==0){
            printf("No\n");
        }
    }
}
