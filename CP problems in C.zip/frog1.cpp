#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl

ll ans=0;

void solve(ll a[],ll i,ll n,ll d[]){
    if(i>n){
        return ;
    }
    d[i]=min(d[i-1]+abs(a[i-1]-a[i-2]),d[i-2]+abs(a[i-1]-a[i-3]));
    solve(a,++i,n,d);
    return ;
}

int main(){
    ll i,n;
    cin>>n;
    ll a[n];
    for ( i = 0; i < n; i++)
    {
        cin>>a[i];
    }
    ll d[n+1]={0};
    d[1]=0;
    d[2]=abs(a[1]-a[0]);
    solve(a,3,n,d);
    cout<<d[n];
}