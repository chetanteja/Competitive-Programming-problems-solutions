#include<stdio.h>

int main(){
    int t;
    scanf("%d",&t);
    while(t--){
        long long int n,i,j=0,k;
        scanf("%lld",&n);
        long long int a[n],b[n];
        k=n-1;
        for(i=0;i<n;i++){
            scanf("%lld",&a[i]);
            if(a[i]%2==0){
                b[k--]=a[i];
            }
            else{
                b[j++]=a[i];
            }
        }
        for(i=0;i<n;i++){
            printf("%lld ",b[i]);
        }
        printf("\n");

    }
}
