#include<stdio.h>

int main(){
    int t;
    scanf("%d",&t);
    while(t--){
        float r,ans;
        scanf("%f",&r);
        printf("%g",3.14*r*r);
    }
    return 0;
}
