#include<stdio.h>

int main(){
    long long int t,n,x=0;
    int a[7],i;
    scanf("%lld",&t);
    if(t<1||t>100000){
        return 0;
    }
    while(t--){
        x=0;
        scanf("%lld",&n);
        if(n<=0||n>100000000){
            return 0;
        }
        for(i=0;i<7;i++){
            scanf("%d",&a[i]);
            if(a[i]<0||a[i]>100){
                return 0;
            }
            x=x+a[i];
        }
        if(x<1){
            return 0;
        }
        i=n%x;

        if(i==a[0]){
            printf("1 monday\n");
            continue;
        }
        if(i==a[0]+a[1]){
            printf("2 tuesday\n");
            continue;
        }
        if(i==a[0]+a[1]+a[2]){
            printf("3 wednesday\n");
            continue;
        }
        if(i==a[0]+a[1]+a[2]+a[3]){
            printf("4 thursday\n");
            continue;
        }
        if(i==a[0]+a[1]+a[2]+a[3]+a[4]){
            printf("5 friday\n");
            continue;
        }
        if(i==a[0]+a[1]+a[2]+a[3]+a[4]+a[5]){
            printf("6 saturday\n");
            continue;
        }
        if(i==a[0]+a[1]+a[2]+a[3]+a[4]+a[5]+a[6]){
            printf("7 sunday\n");
            continue;
        }
    }
}


