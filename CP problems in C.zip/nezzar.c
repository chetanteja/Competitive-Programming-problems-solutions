#include<stdio.h>

int main(){
    int t,n,i,x;
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        int a[n+1];
        for(i=0;i<=n;i++){
            a[i]=0;
        }
        for(i=1;i<=n;i++){
            scanf("%d",&x);
            a[x]++;
        }
        int max=0;
        for(i=1;i<=n;i++){
            if(max<a[i]){
                max=a[i];
            }
        }
        printf("%d\n",max);
    }
}
