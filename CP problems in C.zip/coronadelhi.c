#include<stdio.h>
#include<stdlib.h>
int main(){
    int n,m,q,i,j,x,y,t,count;
    scanf("%d %d %d",&n,&m,&q);
    if(n<1||m>1000||q>n*m||q<1){
        return 0;
    }
    int a[n+1][m+1];
    for(i=0;i<n+1;i++){
        for(j=0;j<m+1;j++){
            if(i==0||j==0||i==n||j==m){
                a[i][j]=1;
            }
            else{
                a[i][j]=0;
            }
        }
    }
    count=1;
    for(i=0;i<q;i++){
        scanf("%d %d %d",&x,&y,&t);
        if(x<1||x>n||y<1||y>m||t<1||t>3){
            return 0;
        }
        if(t==1){
            if(a[x-1][y-1]==1&&a[x][y]==1){
                count++;
            }
                a[x-1][y-1]=1;
                a[x][y]=1;
        }
        if(t==2){
            if(a[x-1][y]==1&&a[x][y-1]==1){
                count++;
            }
                a[x][y-1]=1;
                a[x-1][y]=1;

        }
        if(t==3){
            int h=1;
            if(a[x-1][y-1]==1&&a[x][y]==1&&a[x-1][y]==1&&a[x][y-1]==1){
                    count=count+3;
                    h--;
            }
            if((a[x-1][y-1]==1&&a[x][y]==1)||(a[x-1][y]==1&&a[x][y-1]==1)&&h){
                    count=count+2;
            }
            a[x][y-1]=1;
            a[x-1][y]=1;
            a[x][y]=1;
            a[x-1][y-1]=1;
        }
        printf("%d\n",count);
    }
}
