
#include<stdio.h>

int main(){
    int t,n,i,j,c,d;
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        int a[n];
        for(i=0;i<n;i++){
            scanf("%d",&a[i]);
        }
        for(i=0;i<n-1;i++){
            if(a[i]%a[i+1]==0||a[i+1]%a[i]==0){
                continue;
            }
            c=a[i+1]/a[i];
            c=a[i]*c;
            d=(a[i+1]/a[i])+1;
            d=a[i]*d;
            if(abs(d-a[i+1])>abs(c-a[i+1])){
                a[i+1]=c;
            }
            else{
                a[i+1]=d;
            }
        }
        for(i=0;i<n;i++){
            printf("%d ",a[i]);
        }
        printf("\n");
    }
}
