#include<stdio.h>

int main(){
    int t;
    scanf("%d",&t);
    int n,x;
    while(t--){
        scanf("%d %d",&n,&x);
        int a[n],i;
        for(o=0;i<n;i++){
            scanf("%d",a[i]);
        }
        x--;
        i=1;
        while(i<=n)
    }
}
