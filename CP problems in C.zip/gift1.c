#include<stdio.h>
#include<math.h>
int CHECK(int x){
    int i=0,count=0;
    while(pow(2,i)<x){
        count++;
        i++;
    }
    if(pow(2,i)==x){
        return count+1;
    }
    return count;
}

int SHIFT(int n,int x){
    return (n >> 1) | (n << ( - 1));
}

int main(){
    int t,p,q,n,x,y,r,z,i;
    //printf("%d",4<<2);
    scanf("%d",&t);
    while(t--){
        scanf("%d %d",&p,&q);
        x=CHECK(p);
        y=CHECK(q);
        //printf("%d %d ",x,y);
        if(x>y){
            z=x;
        }
        else{
            z=y;
        }
        printf("%d %d\n",z,SHIFT(7,z));
        i=0;int max=0;
        while(i<z){
            n=SHIFT(q,z);
            if(n>max){
                max=n;
                r=i;
            }
            i++;
        }
        //printf("%d %d\n",r,max);

    }
}
