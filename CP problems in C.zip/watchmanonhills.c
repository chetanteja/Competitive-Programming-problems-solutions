#include<stdio.h>
#include<stdlib.h>

struct node{
    int data;
    struct node* next;
};

struct stack{
    struct node* head;
};

int STACK_EMPTY(struct stack S){
    if(S.head==NULL){
        return 1;
    }
    return 0;
}

struct node* CREATE_NODE(int k){
    struct node* t=(struct node*)malloc(sizeof(struct node));
    t->next=NULL;
    t->data=k;
    return t;
}

struct stack PUSH(struct stack S,int n){
    struct node* x=CREATE_NODE(n);
    if(STACK_EMPTY(S)){
        S.head=x;
    }
    else{
        x->next=S.head;
        S.head=x;
    }
    return S;
}

struct stack POP(struct stack S){
    if(STACK_EMPTY(S)){
        printf("-1\n");
    }
    else{
    struct node*t;
    printf("%d\n",S.head->data);
    t=S.head;
    S.head=S.head->next;
    t->next=NULL;
    }
    return S;
}

int FIND(struct stack S,int *a,int n){
    S=PUSH(S,a[0]);
    S=PUSH(S,a[1]);
    int i,t,count=0;
    struct node* p;
    for(i=2;i<n;i++){
        p=S.head;
        while(p!=NULL&&a[i]>=p->data){
            if(p==NULL){
                printf("HEEEEE");
            }
            printf("%d yes\n",a[i]);
            count++;
            p=p->next;
            printf("HEY");
            if(p->next==NULL){
                break;
            }
       }
       //printf("HELL");
       S=PUSH(S,a[i]);
       //printf("hello");
    }
    return count+n-1;
}

int main(){
    int n,i,count;
    struct stack S;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    count=FIND(S,a,n);
    printf("%d",count);
    return 0;
}
