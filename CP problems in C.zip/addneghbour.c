#include<Stdio.h>
int main(){
    int n,t,i,j,k;
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        for(i=0;i<n;i++){
            scanf("%d",&a[i]);
        }
        for(i=0;i<n-1;i++){
            j=k-1;;
            k=i+1;
            sum1=a[i];
            sum2=a[i+1];
            while(j!=0){
                sum1=sum1+a[j];
                j--;
            }
            while(k<n){
                sum2=sum2+a[k];
                k++;
            }
            if(sum1==sum2){

            }
        }
    }
}
