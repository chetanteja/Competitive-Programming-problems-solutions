#include<stdio.h>
int main(){
int n,i,x,l,t,test;
scanf("%d",&test);
for(i=0;i<test;i++){
    scanf("%d %d",&n,&x);
    t=n-2;
    for(l=1;t>0;l++){
        t=t-x;
    }
    printf("%d\n",l);
}
}
