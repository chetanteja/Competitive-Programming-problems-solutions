#include<stdio.h>

int main(){
    long long int i,n,k,m,s,count=0,j,t;
    scanf("%lld %lld %lld",&n,&m,&k);
    if(n<1||n>1000||k<1||k>1000||m<1||m>1000000){
        return 0;
    }
    t=n;
    long long int a[n];
    while(t--){
        s=0;
        for(i=0;i<n;i++){
            scanf("%lld",&a[i]);
            if(a[i]<1||a[i]>1000){
                return 0;
            }
            s=s+a[i];
        }
        scanf("%lld",&j);
        if(j<1||j>1000000){
            return 0;
        }
        if(s>=m){
            if(j<=10){
                count++;
            }
        }
    }
    printf("%lld\n",count);
}
