#include<stdio.h>

int main(){
    int t;
    scanf("%d",&t);
    while (t--)
    {
        int i,n,x,s=0,y=-1010;
        scanf("%d %d",&n,&x);
        int a[n];
        for ( i = 0; i < n; i++)
        {
            /* code */
            scanf("%d",&a[i]);

            if(a[i]+s==x){
                y=a[i];
                continue;
            }
            s=s+a[i];
        }
        /* code */
    }
    
}