#include<stdio.h>

int main(){
    long long int t,n,i,count,a,b,x,y,min;
    scanf("%lld",&t);
    while(t--){
        count=0;min=100000001;
        scanf("%lld%lld",&a,&b);
        y=b;
        if(y==1){
            y++;
        }
        while(1){
            count=0;
            x=a;
            while(1){
                if(x<=y){
                    break;
                }
                x=x/y;
                count++;
            }
            if(x==y){
                count+=2;
            }
            if(x<y){
                count++;
            }
            count+=y-b;
            y++;
            if(count<=min){
                min=count;
            }
            if(count>min){
                break;
            }
        }
        printf("%lld\n",min);

    }
}
