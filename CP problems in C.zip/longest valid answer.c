#include<stdio.h>
#include<stdlib.h>
struct node{
    char data;
    struct node* next;
};

struct stack{
    struct node* head;
};

int STACK_EMPTY(struct stack S){
    if(S.head==NULL){
        return 1;
    }
    return 0;
}

struct node* CREATE_NODE(char k){
    struct node* t=(struct node*)malloc(sizeof(struct node));
    t->next=NULL;
    t->data=k;
    return t;
}

struct stack PUSH(struct stack S,struct node* x){
    if(STACK_EMPTY(S)){
        S.head=x;
    }
    else{
        x->next=S.head;
        S.head=x;
    }
    return S;
}

struct stack POP(struct stack S){
    if(STACK_EMPTY(S)){
        printf("-1\n");
    }
    else{
    struct node*t;
    t=S.head;
    S.head=S.head->next;
    t->next=NULL;
    }
    return S;
}

int main(){
    int t,count=0,i,max=0;
    struct stack S;
    S.head=NULL;
    scanf("%d",&t);
    if(t<1||t>500){
        return 0;
    }
    while(t--){
        char str[1000000];
        scanf("%s",str);
        for(i=0;str[i]!='\0';i++){
            if(str[i]=='<'){
                struct node*t=CREATE_NODE(str[i]);
                S=PUSH(S,t);
                count++;
                continue;
            }
            if(str[i]=='>'){
                if(S.head==NULL){
                    continue;
                }
                S=POP(S);
                count++;
                if(count>max){
                    max=count;
                }
                if(S.head==NULL){
                    count=0;
                }
            }
        }
        if(S.head!=NULL){
            printf("0\n");
            return 0;
        }
        if(i>1000000){
            return 0;
        }
            printf("%d\n",max);
    }
}
