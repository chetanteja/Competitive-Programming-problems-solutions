#include<stdio.h>

int MAX(int a[],int x){
    int i,max=0,t;
    for(i=x-1;i>=0;i--){
        if(a[i]>max){
            t=i;
            max=a[i];
        }
    }
    //printf("%d\n",max);
    return t;
}

int main(){
    int t,n,i,x=0,y,z,max=0;
    scanf("%d",&t);
    while(t--){
        max=0;x=0;
        scanf("%d",&n);
        y=n;z=n;
        int a[n];
        for(i=0;i<n;i++){
            scanf("%d",&a[i]);
            if(a[i]>max){
                max=a[i];
                x=i;
            }
        }
        //printf("%d ",max);
        while(n!=0){
        for(i=x;i<n;i++){
            printf("%d ",a[i]);
        }
        n=x;
        if(x==0){
            break;
        }
        x=MAX(a,x);
        }
        printf("\n");
    }
}
