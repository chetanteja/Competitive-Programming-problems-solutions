#include<stdio.h>

int main(){
    long long int t,n,i,m,min;
    scanf("%lld",&t);
    while(t--){
        scanf("%lld",&n);
        long long int a[n];
        scanf("%lld",&a[0]);
        m=a[0];min=a[0];
        for(i=1;i<n;i++){
            scanf("%lld",&a[i]);
            if(a[i]>m){
                m=a[i];
            }
            if(a[i]<min){
                min=a[i];
            }
        }
        printf("%lld\n",2*(m-min));

    }
}
