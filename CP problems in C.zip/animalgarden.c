#include<stdio.h>

int main(){
    int x,y;
    scanf("%d %d",&x,&y);
    int a,b;
    for(a=0;a<=x;a++){
        b=x-a;
        if(((2*a)+(4*b))==y){
            printf("Yes");
            return 0;
        }
    }
    printf("No");
    return 0;
}
