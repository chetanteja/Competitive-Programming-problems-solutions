#include<stdio.h>

int main(){
    int t,n,i,k;
    scanf("%d",&t);
    while(t--){
        scanf("%d %d",&n,&k);
        int a[n],sum=0;
        for(i=0;i<n;i++){
            scanf("%d",&a[i]);
            sum=sum+a[i];
        }
        if(sum%k==0){
            printf("0\n");
        }
        else{
            printf("1\n");
        }
    }
}
