#include<stdio.h>

int REV(int a){
    //printf("%d ",a);
    if(a<10){
        if(a==2){
            a=5;
        }
        else if(a==5){
            a=2;
        }
        //printf("%d rev",a);
        return 10*a;
    }
    int i=a%10;
    if(i==2){
        i=5;
    }
    else if(i==5){
        i=2;
    }
    a=a/10;
    if(a==2){
        a=5;
    }
    else if(a==5){
        a=2;
    }
    //printf("%d rev",(10*i+a));
    return (10*i+a);
}

int CHECK(int c){
    if(c==1||c==2||c==5||c==8||c==0){
        return 1;
    }
    return 0;
}

int HOUR(int x){
    int i;
    while(x!=0){
        i=x%10;
        x=x/10;
        if(CHECK(i)==0){
            return 0;
        }
    }
    return 1;
}

int TIME(int x,int y,int h,int m){
    int i,j;
    i=x;
    j=y;
    while(1){
        if(x==h){
            x=0;y=0;
        }
        if(y==m){
            y=0;x++;
        }
        //  printf("%d %d x y\n",x,y);
        if(x<h&&y<m&&REV(x)<m&&REV(y)<h&&HOUR(x)&&HOUR(y)){
            if(x<10){
                printf("0%d:",x);
            }
            else{
                printf("%d:",x);
            }
            if(y<10){
                printf("0%d\n",y);
            }
            else{
                printf("%d\n",y);
            }
            break;
        }
        y++;
    }
}



int main(){
    int t,h,m,i,j;
    scanf("%d",&t);
    //printf("%d\n",A[5][1]);
    while(t--){
        scanf("%d %d",&h,&m);
        char a[100];
        scanf("%s",a);
        i=0;int x=0;int y=0;
        x=(10*(a[0]-'0'))+(a[1]-'0');
        y=(10*(a[3]-'0'))+(a[4]-'0');
        //printf("%d %d\n",x,y);
        TIME(x,y,h,m);
    }
}

