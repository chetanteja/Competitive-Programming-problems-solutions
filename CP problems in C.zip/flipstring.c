#include<stdio.h>
#include<string.h>

char change(char a){
    if(a=='1'){
        return '0';
    }
    if(a=='0'){
        return '1';
    }
}

int main(){
    int t,count,i,j;
    char a[100000],b[100000];
    scanf("%d",&t);
    if(t<1||t>1000){
        return 0;
    }
    while(t--){
        count=0;
        scanf("%s",a);
        scanf("%s",b);
        if(strlen(a)!=strlen(b)){
            return 0;
        }
        for(i=0;a[i]!='\0';i++){
            if((a[i]!='0'||a[i]=='1')&&(a[i]=='0'||a[i]!='1')){
                return 0;
            }
            if((b[i]!='0'||b[i]=='1')&&(b[i]=='0'||b[i]!='1')){
                return 0;
            }
            if(a[i]!=b[i]){
                a[i]=change(a[i]);
                j=i;
                if(a[j+1]=='\0'&&a[j+2]=='\0'){
                        break;
                    }
                while(a[j+2]!=b[j+2]){
                    j=j+2;
                    if(a[j-1]=='\0'&&a[j]=='\0'){
                        break;
                    }
                    a[j]=change(a[j]);
                }
                count++;
            }
        }
        printf("%d\n",count);
    }
}
