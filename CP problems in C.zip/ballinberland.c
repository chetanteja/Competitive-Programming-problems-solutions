#include<stdio.h>

int main(){
    long long int n,t,i,l,m,k,p;
    scanf("%lld",&t);
    while(t--){
        scanf("%lld %lld %lld",&l,&m,&k);
        long long int a,count=0;
        long long int x[l],y[m];
        for(i=0;i<l;i++){
            x[i]=0;
        }
        for(i=0;i<m;i++){
            y[i]=0;
        }
        for(i=0;i<k;i++){
            scanf("%lld",&a);
            x[a-1]++;
        }
        for(i=0;i<k;i++){
            scanf("%lld",&a);
            y[a-1]++;
        }
        for(i=0;i<l;i++){
            if(x[i]>1){
                p=x[i]*(x[i]-1);
                p=p/2;
                count=count+p;
            }
        }
        for(i=0;i<m;i++){
            if(y[i]>1){
                p=y[i]*(y[i]-1);
                p=p/2;
                count=count+p;
            }
        }
        long long int ans=k*(k-1);
        ans=ans/2;
        ans=ans-count;
        printf("%lld\n",ans);
    }
}
