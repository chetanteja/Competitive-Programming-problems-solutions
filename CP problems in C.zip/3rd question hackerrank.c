#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int MEDIAN(int a,int b,int c){
    int x;
    x=(a+b+c)/3;
    if(b==x){
        return 1;
    }
    return 0;
}

int main() {

    int n,a,b,i,count=0,max,min;
    scanf("%d",&n);
    int arr[n];
    scanf("%d %d",&a,&b);
    if(a>b){
        max=a;
        min=b;
    }
    else{
        max=b;
        min=a;
    }
    for(i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }
    for(i=1;i<=n-2;i++){
        if(MEDIAN(arr[i-1],arr[i],arr[i+1])){
            continue;
        }
        else{
            if(arr[i]==max){
                arr[i]=min;
                count++;
            }
        }

    }
    printf("%d",count);
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */
    return 0;
}
