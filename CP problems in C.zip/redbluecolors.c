#include<stdio.h>
#include<stdlib.h>
int main()
{
	long long int t,r,b,d;
	scanf("%lld",&t);
	while(t--)
	{
		scanf("%lld %lld %lld",&r,&b,&d);
		if(d==0)
		{
			if(r==b)
			{
				printf("YES\n");
				continue ;
			}
			else
			{
				printf("NO\n");
				continue ;
			}
		}
		else
		{
			if(r>b)
			{
				if(((1+d)*b)>=r)
				{
					printf("YES\n");
					continue ;
				}
				else
				{
					printf("NO\n");
					continue ;
				}
			}
			else
			{
				if(((1+d)*r)>=b)
				{
					printf("YES\n");
					continue ;
				}
				else
				{
					printf("NO\n");
					continue ;
				}
			}
		}
	}
}