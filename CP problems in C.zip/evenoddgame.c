#include<stdio.h>

int main(){
    int t,n;
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        int a[n],b[n];
        j=0;k=0
        for(i=0;i<n;i++){
            scanf("%d",&l);
            if(l%2==0){
                a[j++]=
            }
        }
    }
}
