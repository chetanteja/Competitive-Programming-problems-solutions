#include <stdio.h>
#include <stdlib.h>
int main(){
	char S[3];
	int i;
	scanf("%s",&S);
	for(i=0;i<3;i++){
		if(S[i]!='A'&&S[i]!='B'){
			return 0;
		}
	}
	if(S[0]!=S[1]){
		printf("Yes");
		return 0;
	}
	if(S[0]!=S[2]){
		printf("Yes");
		return 0;
	}
	if(S[1]!=S[2]){
		printf("Yes");
		return 0;
	}
	else{
		printf("No");
	}
}
