#include<stdio.h>

int main(){
    int t,i;
    scanf("%d",&t);
    if(t<=0||t>10000){
        return 0;
    }
    for(i=0;i<t;i++){
        scanf("%lld",&n);
        if(n<0||n>1000000000){
            return 0;
        }
        scanf("%lld",&m);
        `if(m<0||m>1000000000){
            return 0;
        }
        scanf("%lld",&k);
        if(k<0||k>1000000){
            return 0;
        }




    }
}
