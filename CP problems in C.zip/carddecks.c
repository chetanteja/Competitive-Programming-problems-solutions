#include<stdio.h>

int MAX(int a[],int x){
    int i,max=0,t;
    for(i=x-1;i>=0;i--){
        if(a[i]>max){
            t=i;
            max=a[i];
        }
    }
    //printf("%d\n",max);
    return t;
}

int main(){
    int t,n,i,x=0,y,z,max=0;
    scanf("%d",&t);
    while(t--){
        max=0;x=0;
        scanf("%d",&n);
        y=n;z=n;
        int a[n];
        int b[n+1];
        for(i=0;i<n;i++){
            scanf("%d",&a[i]);
            b[a[i]]=i;
        }
        //printf("%d ",max);
        x=b[y--];
        while(n!=0){
        for(i=x;i<n;i++){
            printf("%d ",a[i]);
            b[a[i]]=0;
        }
        i=a[x]-1;
        while(b[i]==0){

        }
        n=x;
        x=b[y--];
        }
        printf("\n");
    }
}
