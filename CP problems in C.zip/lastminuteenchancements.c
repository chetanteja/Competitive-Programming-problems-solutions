#include<stdio.h>

int main(){
    int t,n,i,j,count,x,y;
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        int a[n];
        for(i=0;i<n;i++){
            scanf("%d",&a[i]);
        }
        x=0,y=0;
        int count=1;
        for(i=0;i<n-1;i++){
            if(a[i]<a[i+1]){
                if(a[i+1]==x||a[i+1]==y){
                    x=a[i+1];
                    y=a[i+1]+1;
                    a[i+1]++;
                    count++;
                    continue;
                }
                count++;
                continue;
            }
            if(a[i+1]==x||a[i+1]+1==y){
                continue;
            }
            x=a[i];
            y=a[i]+1;
            a[i]++;
            count++;
        }
        printf("%d\n",count);
    }
}
