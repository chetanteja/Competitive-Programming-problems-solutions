#include<stdio.h>

int main(){
    int t,k,n,i;
    scanf("%d",&t);
    while(t--){
        scanf("%d %d",&n,&k);
        int a[n];
        for(i=0;i<n;i++){
            a[i]=i+1;
        }
        i=0;k=n-k;
        while(1){
            if(i>n-1||k<=0){
                break;
            }
            k--;
            a[i]=-(i+1);
            i+=2;
        }
        i=n-2;
        if(n%2==0){
            i=n-1;
        }
        while(k>0){
            a[i]=-(i+1);
            i-=2;
            k--;
            }
        for(i=0;i<n;i++){
            printf("%d ",a[i]);
        }
        printf("\n");
    }
}
