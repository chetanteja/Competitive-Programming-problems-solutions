#include<stdio.h>

int main(){
    int t,a,b,c,x,k;
    scanf("%d",&t);
    while(t--){
        scanf("%d %d %d",&a,&b,&c);
        x=a+b+c;
        k=x/9;
        if(a<k||b<k||c<k){
            printf("NO\n");
            continue;
        }
        if(x%9==0){
            printf("YES\n");
            continue;
        }
        printf("NO\n");
    }
}
