#include<stdio.h>
int main(){
    int t,i,n,c,j,x;
    scanf("%d",&t);
    while(t--){
        int b[5]={2,0,2,0,-1};
        scanf("%d",&n);
        c=0;j=0;x=0;;
        int a[n];
        for(i=0;i<n;i++){
            scanf("%d",&a[i]);
            if(a[i]==b[j]){
                j++;
                if(j==4){
                    if(i==n-1){
                        x++;
                        break;
                    }
                    else{
                        if(c==0){
                            x++;                        }
                    }
                }
                continue;
            }
            c++;j=0;
            printf("hello\n");

        }

        if(x){
            printf("Yes\n");
        }
        else{
            printf("No\n");
        }
    }
}
