#include<stdio.h>

int main(){
    int t,n,a,e,o,i;
    scanf("%d",&t);
    while(t--){
        e=0;o=0;
        scanf("%d",&n);
        for(i=0;i<n;i++){
            scanf("%d",&a);
            if(a%2!=0){
                o++;
            }
        }
        if(o%2==0){
            printf("1\n");
        }
        else{
            printf("2\n");
        }
    }
}
