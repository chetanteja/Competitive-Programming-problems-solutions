#include<stdio.h>

int main(){
    long long int t,n,m,i;
    long long int x;
    scanf("%lld",&t);
    while(t--){
        scanf("%lld%lld%lld",&n,&m,&x);
        long long int a;
        i=x%n;
        if(i==0){
            i=n;
        }
        a=((n*m)-x)/n;
        a=m-a;
        printf("%lld\n",m*(i-1)+a);

    }
}
