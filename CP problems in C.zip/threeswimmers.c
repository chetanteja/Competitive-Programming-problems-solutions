#include<stdio.h>

long long int MIN(long long int a,long long int b,long long int c){
    if(a<=b&&a<=c){
        return a;
    }
    if(b<=a&&b<=c){
        return b;
    }
    else{
        return c;
    }

}

int main(){
    long long int p,a,b,c,x,n,t;
    scanf("%lld",&t);
    while(t--){
        scanf("%lld %lld %lld %lld",&p,&a,&b,&c);
        if(a<p){
            if(p%a==0){
                a=p;
            }
            else{
                a=a*((p/a)+1);
            }
        }
        if(b<p){
            if(p%b==0){
                b=p;
            }
            else{
                b=b*((p/b)+1);
            }
        }
        if(c<p){
            if(p%c==0){
                c=p;
            }
            else{
                c=c*((p/c)+1);
            }
        }
        x=MIN(a,b,c);
        printf("%lld\n",x-p);
    }
}
