#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl

int main(){
    int t;
    cin>>t;
    while (t--)
    {
        ll i,x,y;
        cin>> x;
        ll n;
        n=0;
        y=2;
        while(x>=y){
            y=y*2;
            n++;
        }
        x=pow(2,n)-1;
        cout<<x <<line;
    }
    
}
