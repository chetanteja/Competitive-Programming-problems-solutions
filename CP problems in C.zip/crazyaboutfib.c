#include<stdio.h>

long long int mod=10e9+7;

int main(){
    int t;
    //printf("%d\n",10%3);
    scanf("%d",&t);
    while (t--){
        long long int i,x=0,n=0,a,b;
        scanf("%lld%lld%lld",&a,&b,&n);
        if(n==1){
            printf("%lld\n",a);
            continue;
        }
        if(n==2){
            printf("%lld\n",b);
            continue;
        }
        n=n-3;
        if(n%6==0){
            i=b-a;
        }
        else if (n%6==1){
            i=-a;
        }
        else if (n%6==2){
            i=-b;
        }
        else if (n%6==3){
            i=a-b;
        }
        else if (n%6==4){
            i=a;
        }
        else if (n%6==5){
            i=b;
        }
        //=i % mod;
        //printf("%lld %lld\n",x,i);
        
        if(i<0){
            i=-1*i;
            x=i/mod;
            printf("%lld\n",x);
            n=i-(x*mod);
            i=mod-n;
        }
        else{
            x=i/mod;
            n=i-(x*mod);
            i=n;
        }
        printf("%lld\n",i);
    }
}