#include<stdio.h>
#include<stdlib.h>

int cmpfunc (const void * a, const void * b) {
   return ( *(int*)a - *(int*)b );
}

int main(){
    int t,n,k,s,count,i;
    scanf("%d",&t);
    while(t--){
        s=0,count=0;
        scanf("%d %d",&n,&k);
        int arr[n];
        for(i=0;i<n;i++){
            scanf("%d",&arr[i]);
        }
        qsort(arr, n, sizeof(int), cmpfunc);
        count=2;

		    int sum1=0;
		    int sum2=0;

		    sum1=arr[n-1];
		    sum2=arr[n-2];

		    if(sum1>=k&&sum2>=k)
		    {
		        printf("2\n");
		        continue;
		    }
		    int i=n-3;
		    while((sum1<k||sum2<k)&&i>=0)
		    {
		        if(sum1>=k)
		        {
		            sum2=sum2+arr[i];
		            i--;
		            count++;
		            continue;
		        }

		        if(sum2>=k)
		        {
		            sum1=sum1+arr[i];
		            i--;
		            count++;
		            continue;
		        }


		        if(sum2+arr[i]>=k)
		        {
		          sum2=sum2+arr[i];
		          i--;
		          count++;
		          continue;
		        }
		       if(arr[i]+sum2<=sum1)
		        {
		            sum2=sum2+arr[i];
		            i--;
		            count++;
		        }
		        else
		        {
		            sum1=sum1+arr[i];
		            i--;
		            count++;
		        }
		    }
		    if(sum1<k||sum2<k)
		    printf("-1\n");
		    else
		    printf("%d\n",count);
        }
}
