#include<stdio.h>
int main(){
    int n,i,a[3];
    scanf("%d",&n);
    if(n<111||n>999){
        return 0;
    }
    for(i=2;i>=0;i--){
        a[i]=n%10;
        n=n/10;
        if(a[i]!=1&&a[i]!=9){
            printf("printf");
            return 0;
        }
    }
    for(i=0;i<3;i++){
        if(a[i]==9){
            a[i]=1;
        }
        else{
            a[i]=9;
        }
        printf("%d",a[i]);
    }
}
