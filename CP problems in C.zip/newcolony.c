#include<stdio.h>

int main(){
    long long int t,n,check,x,i;
    long long int k;
    scanf("%lld",&t);
    while(t--){
        check=0;
        scanf("%lld %lld",&n,&k);
        long long int a[n];
        scanf("%lld",&a[0]);
        for(i=1;i<n;i++){
            scanf("%lld",&a[i]);
        }
        i=1;
        while(i<n){
            //printf("hello %lld\n",i);
            //printf("%d helo\n",k);
            if(a[i]>a[i-1]){
                //printf("hello\n");
                a[i-1]++;
                k--;
                if(k==0){
                    printf("%lld\n",i);
                    check++;
                    break;
                }
                if(i>1){
                    i=i-1;
                    continue;
                }
                else{
                    continue;
                }
            }
            i++;
        }
        if(check==0){
            printf("-1\n");
        }

    }
}
