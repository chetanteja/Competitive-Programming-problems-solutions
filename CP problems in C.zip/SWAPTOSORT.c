#include<stdio.h>

int check(int n,int a[n][n],int x,int y){
    if(){

    }

}


int main(){
	int n,k,i,l,m;
	scanf("%d",&n);
	scanf("%d",&k);
	int a[n][n];
	for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            a[i][j]=0;
        }
	}
	while(k--){
        scanf("%d %d",&l,&m);
        a[l][m]=1;
        a[m][l]=1;

	}
	for(i=0;i<(n/2);i++){
        if(a[i][n-i-1]==1){
            continue;
        }
        if(check(n,a,i,n-i-1)==0){
            printf("No");
            return 0;
        }
	}
	printf("Yes");


}
