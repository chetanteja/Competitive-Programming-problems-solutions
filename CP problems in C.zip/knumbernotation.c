#include<stdio.h>

int main(){
    long long int n;
    int k,r,count=0;
    scanf("%lld %d",&n,&k);
    if(n<1||n>1000000000||k<2||k>10){
        return 0;
    }
    while(n!=0){
        count++;
        n=n/k;
    }
    printf("%d",count);
    return 0;
}
