#include<stdio.h>

int main(){
    char a[100];
    scanf("%s\n",a);
    while(a!='\n'){
        printf("NO\n");
        fflush(stdin);
        fflush(stdout);
        scanf("%s",a);
    }
}
