#include<stdio.h>
#include<stdlib.h>
int cmpfunc (const void * a, const void * b) {
   return ( *(int*)a - *(int*)b );
}

int CHECK(int *a,int n,int w){
    int i=n-1,c=0;
    while(a[i]>w&&i>=0){
        if(a[i]==100000){
            //printf("1 ");
            c++;
        }
        i--;
    }
    if(c==n){
        return -2;
    }
    if(i<0){
        //printf("hello\n");
        return 0;
    }
    //printf("hello\n");
    w=w-a[i];
    a[i]=100000;
    if(c==n-1){
        return -2;
    }
    //printf("%d\n",w);
    return w;
}

int main(){
    int t;
    int n,x,i,y,w,h;
    scanf("%d",&t);
    while(t--){
        h=0;
        scanf("%d %d",&n,&w);
        int a[n];
        for(i=0;i<n;i++){
            scanf("%d",&a[i]);
        }
        qsort(a, n, sizeof(int), cmpfunc);
        x=n-1;
        y=0;
        i=x;
        h=1;
        int temp=w;
        while(1){
            //printf("%d-%d ",w,h);
            w=CHECK(a,n,w);
            if(w==-2){
                break;
            }
            if(w==0){
                //printf("hell");
                h++;
                w=temp;
                continue;
            }
        }
        printf("%d\n",h);
    }
}


