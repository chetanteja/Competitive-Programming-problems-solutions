#include<stdio.h>

int main(){
    int t,n,m,i;
    scanf("%d",&t);
    while(t--){
        scanf("%d%d",&n,&m);
        int a[m],count=0;
        for(i=0;i<m;i++){
            scanf("%d",&a[i]);
            while(1){
                if(a[i]%n==0){
                    break;
                }
                n--;
                count++;
            }
        }
        printf("%d\n",count);
    }
}
