#include<stdio.h>

int main(){
    int t,n,i,sum;
    scanf("%d",&t);
    while(t--){
        sum=0;
        scanf("%d",&n);
        char x[n];
        scanf("%s",x);
        for(i=0;x[i]!='\0';i++){
            if(x[i]=='1'){
                sum=sum+1;
            }
        }
        sum=sum+120-n;
        if(sum>=90){
            printf("YES\n");
        }
        else{
            printf("NO\n");
        }
    }
}
