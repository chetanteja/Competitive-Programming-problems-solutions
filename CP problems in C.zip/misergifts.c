#include<stdio.h>

int main(){
    int t,n,i,sum;
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        int a[n];
        for(i=0;i<n;i++){
            scanf("%d",&a[i]);
        }
        i=0;
        while(i<n-1){
            a[i+1]=a[i+1]^a[i];
            a[i]=0;
            i++;
        }
        sum=0;
        for(i=0;i<n;i++){
            sum=sum+a[i];
        }
        printf("%d\n",sum);
    }
}
