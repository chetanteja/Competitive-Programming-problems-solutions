#include<stdio.h>
#include<stdlib.h>
int swap(int *a,int *b){
    int temp=*a;
    *a=*b;
    *b=temp;
}

int quick_sort(int *a,int p,int r){
    if(p<r){
        int q;
        q=partition(a,p,r,r);
        quick_sort(a,p,q-1);
        quick_sort(a,q+1,r);
    }
}

int partition(int *a,int p,int q,int r){
    int pivot=a[q];
    int i=p-1;
    int j=p;
    while(j<q){
        if(a[j]<=pivot){
            swap(&a[j],&a[++i]);
        }
        j++;
    }
    swap(&a[i+1],&a[q]);
    i++;
    return i;
}

int main(){
    long long int t,a,n,k,i;
    scanf("%lld",&t);
    for(a=0;a<t;a++){
        scanf("%lld %lld",&n,&k);
        long long int *A;
        A=(long long int *)malloc(n*sizeof(int));
        for(i=0;i<n;i++){
            scanf("%lld",A+i);
        }
        quick_sort(A,0,n-1);
        for(i=0;i<k;i++){
                A[n-1]+=A[n-i-2];
                A[n-i-2]=0;
            }
        printf("%lld ",A[n-1]);
        }
    }
