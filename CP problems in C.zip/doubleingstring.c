#include<stdio.h>
int count;
void CHECK(char s[],int n,int l,int r,int k,int *cnt){
	int i,index=0,flag=0;
	for(i=l+1;i<=l+k;i++){
		if(s[i]=='X'){
			flag=1;
			break;
		}
		if(s[i]=='*'){
			index=i;
		}
	}
	if(flag==1){
		return;
	}
	s[index]='X';
	*cnt++;
	//printf("%d\n",count);
	CHECK(s,n,index,r,k,cnt);
}
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int k,n,i,cnt=0,i1=0,i2=0;
		scanf("%d %d",&n,&k);
		char s[n];
		scanf("%s",&s);
		for(i=0;i<n;i++){
			if(s[i]=='*'){
				s[i]='X';
				i1=i;
				cnt++;
				break;
			}
		}
		for(i=0;i<n;i++){
			if(s[i]=='*'){
				i2=i;
			}
		}
		if(i2!=0){
			s[i2]='X';
			cnt++;
		}
		//printf("%d ",count);
		if(cnt<2){
			printf("%d\n",cnt);
			continue;
		}
		CHECK(s,n,i1,i2,k,&cnt);
		cnt=0;
		for(i=0;i<n;i++){
			if(s[i]=='X'){
				cnt++;
			}
		}
		printf("%d\n",cnt);
	}
}
