#include<stdio.h>
#include<stdlib.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int n,m,ans;
		scanf("%d%d",&n,&m);
        if(n==1){
            printf("%d\n",0);
            continue;
        }
        if(n==2){
            printf("%d\n",m);
            continue;
        }
		ans=n+(2*m)-3;
		printf("%d\n",ans);
	}
}