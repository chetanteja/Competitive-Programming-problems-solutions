#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl

int main(){
    int n,i,x,y;
    cin>>n;
    vector<int> a,b,c;
    for ( i = 0; i < n; i++)
    {
        /* code */
        cin>>x;
        a.push_back(x-1);
    }
    for ( i = 0; i < n; i++)
    {
        /* code */
        cin>>x;
        b.push_back(x-1);
    }
    for ( i = 0; i < n; i++)
    {
        /* code */
        cin>>x;
        c.push_back(x-1);
    }
    vector<int> d(n,0);
    for ( i = 0; i < n; i++)
    {
        /* code */
        d[b[c[i]]]++;
    }
    ll ans=0;
    for ( i = 0; i < n; i++)
    {
        /* code */
        ans=ans+d[a[i]];
    }
    cout<<ans;
    


}