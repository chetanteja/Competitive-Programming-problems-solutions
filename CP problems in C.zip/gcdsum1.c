#include<stdio.h>
int a[37]={2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97,101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157};
long long int GET(long long int n){
    long long int x=n,i=0;
    while(x!=0){
        i=i+(x%10);
        x=x/10;
    }
    return i;
}

/*long long int GCD(long long int a,long long b){
    if(b==0){
        return a;
    }
    return GCD(b,a%b);
}*/

int main(){
    int t;
    long long int n,x,i,y;
    scanf("%d",&t);
    while(t--){
        scanf("%lld",&n);
        int check=0;
        i=0;
        while(check==0){
            x=GET(n);
            i=0;
            while(a[i]<=x){
                if(x%a[i]==0&&n%a[i]==0){
                    check=1;
                    break;
                }
                i++;
            }
            n++;
        }
        if(check==1){
            printf("%lld\n",--n);
        }
    }

}
