#include<stdio.h>

int main(){
    int t,n,q,i,j,k,x,y,count,max;
    scanf("%d",&t);
    if(t<1||t>20){
        return 0;
    }
    scanf("%d",&n);
    if(n<1||n>100000){
        return 0;
    }
    int a[n];
    scanf("%d",&q);
    if(q<1||q>100000){
        return 0;
    }
    for(i=0;i<t;i++){
        for(j=0;j<n;j++){
            scanf("%d",&a[j]);
            if(a[i]>1000000){
                return 0;
            }
        }
        for(j=0;j<q;j++){
            scanf("%d%d",&x,&y);
            a[x-1]=y;
            count=1;
            max=1;
            for(k=0;k<n-1;k++){
                if(a[k]!=a[k+1]){
                    count++;
                }
                else{
                    count=1;
                    k++;
                }
                if(max<count){
                    max=count;
                }
            }
            printf("%d\n",max);
        }
    }
}
