#include<stdio.h>
int main(){
    int n,i,j,count,max1,max2,ans,x,y;
    scanf("%d",&n);
    if(n<2||n>100000||n%2!=0){
        return 0;
    }
    int a[n];
    for(i=0;i<n;i++){
      scanf("%d",&a[i]);
      if(a[i]<1||a[i]>100000){
        return 0;
      }
    }
    int count1,count2=0;
    max1=0,max2=0;
    for(i=0;i<n;i=i+2){
        count1=0;count2=0;
        for(j=0;j<n;j=j+2){
            if(a[i]==a[j]){
                count1++;
            }
            if(a[i+1]==a[j+1]){
                count2++;
            }
        }
        if(count1>max1){
            max1=count1;
            x=a[i];
        }
        if(count2>max2){
            max2=count2;
            y=a[i+1];
        }
    }
    if(x==y){
        printf("%d",n/2);
        return 0;
    }
    ans=n-max1-max2;
    printf("%d",ans);
}
