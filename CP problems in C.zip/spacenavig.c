#include<stdio.h>

int main(){
    int t,n1,n2,l,u,d,r,i,check;;
    scanf("%d",&t);
    char a[100000];
    while(t--){
        l=0;r=0;d=0;u=0;check=0;
        scanf("%d %d",&n1,&n2);
        scanf("%s",a);
        for(i=0;a[i]!='\0';i++){
            if(a[i]=='R'){
                r++;
            }
            if(a[i]=='U'){
                u++;
            }
            if(a[i]=='L'){
                l++;
            }
            if(a[i]=='D'){
                d++;
            }
        }
        //  printf("%d %d %d %d \n",u,d,r,l);
        if(n1>=0&&r>=n1){
           // printf("YES\n");
           check++;
        }
        if(n1<0&&l>=(-1*n1)){
           // printf("YES\n");
            check++;
        }
        if(n2>=0&&u>=n2){
           // printf("YES\n");
            check++;
        }
        if(n2<0&&d>=(-1*n2)){
           // printf("YES\n");
            check++;
        }
        if(check==2){
            printf("YES\n");
        }
        else{
            printf("NO\n");
        }
    }
}
