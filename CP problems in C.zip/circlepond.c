#include<stdio.h>

int main(){
    float r,ans;
    scanf("%f",&r);
    ans=2*3.141592*r;
    printf("%f",ans);
}
