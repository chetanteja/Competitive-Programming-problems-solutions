#include<stdio.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int n;
		scanf("%d",&n);
		int a[n][n];
		int x,y,i,j;
		x=1;
		y=2;
		if(n==1||n==2)
		{
			if(n==1)
			{
				printf("1\n");
				continue ;
			}
			if(n==2)
			{
				printf("-1\n");
				continue ;
			}
		}
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				if(x<=(n*n))
				{
					printf("%d ",x);
					x=x+2;
				}
				else
				{
					printf("%d ",y);
					y=y+2;
				}
			}
			printf("\n");
		}
	}
}