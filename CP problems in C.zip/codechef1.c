#include<stdio.h>
#include<string.h>
#include<math.h>

int main(){
int n,i,count,j,x,ans;
char s[21];
scanf("%d",&n);
if(n<1||n>1000){
    return 0;
}
for(i=0;i<n;i++){
    ans=0;
    scanf("%s",s);
    x=strlen(s);
    if(x>20){
        return 0;
    }
    count=0;
    for(j=0;s[j]!='\0';j++){
        if(s[j]=='a'){
            count++;
        }
        if(s[j]=='r'){
            return 0;
        }
    }
    if(count==0){
        printf("0\n");
        continue;
    }
    while(count!=0){
        ans=ans+pow(2,x-1);
        x--;
        count--;
    }
    printf("%d\n",ans);
}
}
