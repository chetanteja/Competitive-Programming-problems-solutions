#include<stdio.h>
#include<stdlib.h>
int main(){
    int t,n,k,i,j,x;
    scanf("%d",&t);
    while(t--){
        x=0;
        scanf("%d%d",&n,&k);
        char a[n];
        scanf("%s",a);
        i=0;
        j=n-1;
        while(i<=j){
            if(a[i]!=a[j]){
                x++;
            }
            i++;
            j--;
        }
        printf("%d\n",abs(k-x));
    }
}
