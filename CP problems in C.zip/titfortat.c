#include<stdio.h>

int main(){
    int t,n,i,x,j;
    scanf("%d",&t);
    while(t--){
        scanf("%d%d",&n,&x);
        int a[n];
        for(i=0;i<n;i++){
            scanf("%d",&a[i]);
        }
        i=0;j=n-1;
        while(i<j){
            if(x<=0){
                break;
            }
            if(a[i]<=0){
                i++;
            }
            if(a[i]-x>0){
                a[i]=a[i]-x;
                a[j]=a[j]+x;
                break;
            }
            if(x>=a[i]){
                a[j]=a[j]+a[i];
                a[i]=0;
                i++;
            }
        }
        for(i=0;i<n;i++){
            printf("%d ",a[i]);
        }
        printf("\n");
    }
}
