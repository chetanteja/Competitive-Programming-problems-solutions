#include<stdio.h>
int main(){
    int n,i,a,x=0;
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&a);
        if(a==1){
            x++;
        }
    }
    int cnt=0;
    if(x!=n){
        cnt=1;
    }
    cnt=cnt+x;
    printf("%d\n",cnt);
}
