#include<stdio.h>

long long int MIN(long long int *a,long long int n){
    long long int i,x,min=1000000;
    for(i=0;i<n;i++){
        if(a[i]<min){
            min=a[i];
            x=i;
        }
    }
    return x;
}

int main(){
    long long int n,t,i,p,count;
    scanf("%lld",&t);
    if(t<1||t>10){
        return 0;
    }
    while(t--){
        scanf("%lld",&n);
        if(n<1||n>200000){
            return 0;
        }
        long long int a[n],b[n],c[n];
        for(i=0;i<n;i++){
            scanf("%lld",&a[i]);
            if(a[i]<0||a[i]>1000000000){
                return 0;
            }
        }
        for(i=0;i<n;i++){
            scanf("%lld",&b[i]);
            c[i]=a[i]*b[i];
            if(b[i]<0||b[i]>1000000000){
                return 0;
            }
        }
        count=0;p=n;
        while(p>0){
            i=MIN(c,n);
            p=p-a[i];
            if(p>=0){
                count=count+c[i];
            }
            else{
                count=count+b[i]*(p+a[i]);
            }
            c[i]=100000000000000000;
        }
        printf("%lld\n",count);
    }
}
