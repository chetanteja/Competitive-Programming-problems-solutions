#include<stdio.h>

int main(){
    int t,n,x,y,cur,temp,sum;
    scanf("%d",&t);
    sum=0;
    while(t--){
        scanf("%d",&n);
        if(n==1){
            scanf("%d %d",&x,&y);
            if(x==2){
                if(y<=3){
                    continue;
                }
                else{
                    y=y%4;
                    if(y==1||y==0){
                        sum=sum+1;
                    }
                }
            }
            if(x==4){
                if(y==1){
                    continue;
                }
                if(y%2==0){
                    sum=sum+1;
                }
            }
        }
        else{
            printf("%d\n",sum%2);
        }
    }
}
