#include<stdio.h>
#include<stdlib.h>
void swap(long long int* a, long long int* b)
{
	int t = *a;
	*a = *b;
	*b = t;
}
int partition (long long int arr[],long long int b[], int low, int high)
{
	int pivot = arr[high]; // pivot
	int i = (low - 1); // Index of smaller element

	for (int j = low; j <= high- 1; j++)
	{
		// If current element is smaller than the pivot
		if (arr[j] < pivot)
		{
			i++; // increment index of smaller element
			swap(&arr[i], &arr[j]);
			swap(&b[i], &b[j]);
		}
	}
	swap(&arr[i + 1], &arr[high]);
	swap(&b[i+1],&b[high]);
	return (i + 1);
}

/* The main function that implements QuickSort
arr[] --> Array to be sorted,
low --> Starting index,
high --> Ending index */
void quickSort(long long int arr[],long long int b[], int low, int high)
{
	if (low < high)
	{
		/* pi is partitioning index, arr[p] is now
		at right place */
		int pi = partition(arr,b, low, high);

		// Separately sort elements before
		// partition and after partition
		quickSort(arr,b, low, pi - 1);
		quickSort(arr,b, pi + 1, high);
	}
}
int main(){
    long long int t,i,n,A,B,check,x,y;
    scanf("%lld",&t);
    while(t--){
        check=0;x=0;y=0;
        scanf("%lld %lld %lld",&A,&B,&n);
        long long int a[n],b[n];
        for(i=0;i<n;i++){
            scanf("%lld",&a[i]);
        }
        for(i=0;i<n;i++){
            scanf("%lld",&b[i]);
        }
        quickSort(a,b,0,n-1);
        for(i=0;i<n-1;i++){
            x=b[i]/A;
            if(b[i]%A!=0){
                x++;
            }
            B=B-(x*a[i]);
            if(B<=0){
                printf("NO\n");
                check++;
                break;
            }
        }
        if(check==0){
            x=B/a[i];
            if(B%a[i]!=0){
                x++;
            }
            y=b[i]/A;
            if(b[i]%A!=0){
                y++;
            }
            if(x>=y){
                printf("YES\n");
            }
            else{
                printf("NO\n");
            }
        }

    }
}
