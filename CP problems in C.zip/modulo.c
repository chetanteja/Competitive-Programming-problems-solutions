
#include<stdio.h>
#include<stdlib.h>
int main(){
    int t,n,i,x;
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        int a[n];
        for(i=0;i<n;i++){
            scanf("%d",&a[i]);
        }
        if(n<=2){
            printf("0\n");
            continue;
        }
        int c1=-1000,c2=-1000;
        int check=0;
        x=a[1]-a[0];
        if(x>0){
            c1=x;
        }
        else{
            c2=x;
        }
        for(i=2;i<n-1;i++){
            x=a[i+1]-a[i];
            if(x>0){
                if(c1==-1000){
                    c1=x;
                }
                if(x!=c1){
                    check=1;
                    break;
                }
                continue;
            }
            if(x<0){
                if(c2==-1000){
                    c2=x;
                }
                if(x!=c2){
                    check=1;
                    break;
                }
            }
        }
        if(check==1){
            printf("-1\n");
            continue;
        }
        if(c1!=-1000&&c2!=-1000){
            int m=c1-c2;
            printf("%d %d\n",m,c1);
            continue;
        }
        if(c2==-1000){
            printf("%d %d\n",a[n-1]+1,c1);
        }
        if(c1==-1000){
            printf("%d %d\n",a[0]+1,c2);
        }


        int b[n-1];
        int j=0,check=0;
        for(i=1;i<n;i++){
            b[j]=a[i]-a[i-1];
            if(b[j]!=0){
                check=1;
            }
           // printf("%d ",b[b[j]);
            j++;
        }
        if(check==0){
            printf("0\n");
            continue;
        }
        int c[n-2];
        j=0;
        for(i=1;i<n-1;i++){
            c[j]=abs(b[i]-b[i-1]);
            j++;
        }
        long long int min=1000000000000;
        for(i=0;i<n-2;i++){
            if(c[i]<min&&c[i]!=0){
                min=c[i];
            }
        }
        check=0;
        //printf("%lld\n",min);
        for(i=0;i<n;i++){
            if(a[i]>min){
                check=1;
                break;
            }
        }
        int che=a[1]-a[0];
        if(che<0){
            che=min+che;
        }
        if(che>=min){
            check=1;
        }
        if(check==0){
            printf("%lld %d\n",min,che);
        }
        else{
            printf("-1\n");
        }
    }
}

