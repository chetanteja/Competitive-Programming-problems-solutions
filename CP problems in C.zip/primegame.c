#include<stdio.h>

int a[1000000];
int g=6;

int Is_Prime(int x){
    int i=1,check=1;
    while(i<=x){
        if(x%a[i]!=0){
            check=0;
            break;
        }
        i++;
    }
    return check;
}

int PRIME(int x){
    while(g==x){
        g++;
        if(Is_Prime(g)){
            a[g]=a[g-1]++;
        }
    }
    g--;
}

int main(){
    int t,x,y;
    scanf("%d",&t);
    a[0]=0;
    a[1]=0;
    a[2]=1;
    a[3]=2;
    a[4]=2;
    a[5]=3;
    a[6]=3;
    while(t--){
        scanf("%d %d",&x,&y);
        if(y==1){
            if(x>2){
                printf("Divyam\n");
            }
            else{
                printf("Chef\n");
            }
            continue;
        }
        if(x<=g){
            if(a[x]>y){
                printf("Divyam\n");
            }
            else{
                printf("Chef\n");
            }
            continue;
        }
        int temp=PRIME(x);
        if(temp>y){
                printf("Divyam\n");
            }
            else{
                printf("Chef\n");
            }





    }
}
