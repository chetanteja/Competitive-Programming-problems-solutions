#include<stdio.h>

int prime(int a){
    int i;
    while(1){
    for(i=2;i<a;i++){
        if(a%i==0){
            break;
        }
    }
    if(i==a){
        return a;
    }
    a++;
    }
}

int main(){
    int t,d,x,y;
    scanf("%d",&t);
    while(t--){
        scanf("%d",&d);
        x=1+d;
        x=prime(x);
        y=x+d;
        y=prime(y);
        printf("%d\n",x*y);
    }
}
