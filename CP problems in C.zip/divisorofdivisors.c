#include<stdio.h>

int main(){
    int t,a;
    while(){
        scanf("%d",&a);
        if(a==0){
            return 0;
        }



    }
}

