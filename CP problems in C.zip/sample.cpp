#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl

int main(){
    int a[10][10]={0};
    vector<int> v(10,0);
    //memset(a,0,sizeof(a));
    cout<<a[0][0]<<a[1][1]<<a[2][2];


}