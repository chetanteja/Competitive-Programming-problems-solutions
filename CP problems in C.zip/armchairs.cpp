#include<bits/stdc++.h>
using namespace std;

int CHECK(int a[],int n,int i){
    int j=i,x,k=i;
    while(1){
        if(j>=0){
            if(a[j]==0){
                return j;
            }
            j--;
        }
        if(k<n){
            if(a[k]==0){
                return k;
            }
            k++;
        }
        if(j==-1&&k==n){
            return -1;
        }
    }
}

int main(){
   int t;
    int n,i,x=0,y;
    cin>>n;
    int a[n];
    for(i=0;i<n;i++){
        cin>>a[i];
    }
    if(a[0]==1){
        y=CHECK(a,n,0);
        a[0]=2;
        a[y]=2;
        x=y;
    }
    if(a[n-1]==1){
        y=CHECK(a,n,n-1);
        a[n-1]=2;
        a[y]=2;
        x=x+abs(y-(n-1));
    }
    i=0;
    while(i<n){
        if(a[i]==1){
            a[i]=2;
            y=CHECK(a,n,i);
            a[y]=2;
            x=x+abs(y-i);
        }
        i++;
    }
    cout<<x<<endl;
}


