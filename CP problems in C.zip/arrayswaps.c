#include<stdio.h>

int main(){
    long long int n,m,min,i,count=0;
    scanf("%lld %lld",&n,&m);
    int a[n],b[m];
    scanf("%lld",&a[0]);
    min=a[0];
    for(i=1;i<n;i++){
        scanf("%lld",&a[i]);
        if(a[i]<min){
            min=a[i];
        }
    }
    for(i=0;i<m;i++){
        scanf("%lld",&b[i]);
    }
    for(i=0;i<m;i++){
        if(b[i]<min){
            count=count+n;
        }
    }
    printf("%lld",count);
}
