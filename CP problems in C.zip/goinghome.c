#include<stdio.h>
long long int hash[10000000];
long long int CHECK(long long int x,long long int b,long long int a[],long long int n){
    long long int i;
    for(i=0;i<n;i++){
        if(a[b]+a[i]==x&&i!=hash[x]){
            return i;
        }
    }
    return -1;
}

int main(){
        long long int t,n,i,j,x,y;
        long long int z=0;
        scanf("%lld",&n);
        long long int a[n];
        for(i=0;i<n;i++){
            scanf("%lld",&a[i]);
        }
        for(i=0;i<n;i++){
            for(j=i+1;j<n;j++){
                x=a[i]+a[j];
                //printf("%d\n",x);
                if(hash[x]>0){
                    //printf("%d %d %d\n",i,j,hash[x]);
                    y=CHECK(x,hash[x],a,n);
                    //printf("%d %d %d %d y\n",i,j,hash[x],y);
                    if(y==i||y==j||hash[x]==i||hash[x]==j){
                        continue;
                    }
                    z=1;
                    break;
                }
                if(hash[x]==0){
                    //printf("hello\n");
                    hash[x]=j;
                }
            }
            if(z==1){
                break;
            }
        }
        if(z==1){
            printf("YES\n%lld %lld %lld %lld\n",i+1,j+1,hash[x]+1,y+1);
        }
        else{
            printf("NO\n");
        }
}
