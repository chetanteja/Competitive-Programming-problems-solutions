#include<stdio.h>


int main(){
    int t,n,k,x,i;
    scanf("%d",&t);
    while(t--){
        scanf("%d%d",&n,&k);
        x=k/2;
        if(k%2!=0){
            x++;
        }
        printf("%d\n",n-x);
        for(i=x;i<=n;i++){
            if(i==k){
                continue;
            }
            printf("%d ",i);
        }

        printf("\n");
        //printf("%lld\n",FACT(n)-x);
    }
}
