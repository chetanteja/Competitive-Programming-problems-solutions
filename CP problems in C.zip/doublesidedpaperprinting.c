#include<stdio.h>

int main(){
    int n,i;
    scanf("%d",&n);
    if(n<1||n>100){
        return 0;
    }
    if(n%2==0){
        printf("%d",n/2);
    }
    else{
        n=n/2;
        printf("%d",n+1);
    }
}
