#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl

int main(){
    int t;
    cin>>t;
    while (t--)
    {
        int x=0,y=0,n,i;
        cin>>n;
        string str;
        cin>> str;
        for(string::iterator itr=str.begin();itr!=str.end();++itr) {
            if(*itr=='1'){
                x++;
            }
            else{
                y++;
            }
        }
        if(n%2==0){
            cout<<"BOB"<<line;
        }
        else{
            if(str[n/2]!='0'||y==1){
                cout<<"BOB"<<line;
            }
            else{
                cout<<"ALICE"<<line;
            }
        }        
    }
    

}
