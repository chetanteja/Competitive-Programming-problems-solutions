#include<stdio.h>
#include<stdlib.h>


int main(){
    int t,n,m,i,x;
    scanf("%d",&t);
    while(t--){
        scanf("%d %d",&n,&m);
        int a[n];
        int b[m];
        for(i=0;i<m;i++){
            b[i]=0;
        }
        for(i=0;i<n;i++){
            scanf("%d",&a[i]);
            b[a[i]%m]++;
        }
        int count=0;
        if(b[0]>0){
            count++;
        }
        i=1;
        int j=m-1;
        while(i<=j){
            x=abs(b[i]-b[j]);
            if(b[i]==0&&b[j]==0){
                i++;
                j--;
                continue;
            }
            if(x>1){
                count+=x;
            }
            else{
                count++;
            }
            i++;
            j--;
        }
        printf("%d\n",count);
    }
}

