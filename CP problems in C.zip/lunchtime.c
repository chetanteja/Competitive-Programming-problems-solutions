#include<stdio.h>

int main(){
    int t,n,i,j;
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        int a[n],res[n];
        for(i=0;i<n;i++){
            scanf("%d",&a[i]);
        }
        for(i=0;i<n;i++){
            res[i]=0;
        }
        for(i=0;i<n;i++){
            for(int j = i -1; j >= 0; --j){
                if(a[j] > a[i]) break;
                if(a[i] == a[j]) res[i]++;
            }
            for(int j = i +1; j < n; ++j){
                if(a[i] < a[j]) break;
                if(a[i] == a[j]) res[i]++;
            }
        }
        for(i=0;i<n;i++){
            printf("%d ",res[i]);
        }
    }
}
