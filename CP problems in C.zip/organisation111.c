#include<stdio.h>

struct bag{
    int b;
    int index;
};

void swap(int* a, int* b)
{
    int t = *a;
    *a = *b;
    *b = t;
}

int partition (struct bag arr[], int low, int high)
{
    int pivot = arr[high].b;    // pivot
    int i = (low - 1);  // Index of smaller element

    for (int j = low; j <= high- 1; j++)
    {
        // If current element is smaller than the pivot
        if (arr[j].b > pivot)
        {
            i++;    // increment index of smaller element
            swap(&arr[i].b, &arr[j].b);
            swap(&arr[i].index, &arr[j].index);
        }
    }
    swap(&arr[i + 1].b, &arr[high].b);
    swap(&arr[i + 1].index, &arr[high].index);
    return (i + 1);
}

void quickSort(struct bag arr[], int low, int high)
{
    if (low < high)
    {
        /* pi is partitioning index, arr[p] is now
           at right place */
        int pi = partition(arr, low, high);

        // Separately sort elements before
        // partition and after partition
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

int main(){
    int t,n,k,i,A,B,C,D;
    scanf("%d",&t);
        while(t--){
        scanf("%d %d",&n,&k);
        struct bag a[n+1];
        for(i=0;i<n+1;i++){
            scanf("%d",&a[i].b);
            a[i].index=i;
        }
        quickSort(a, 0, n);
        for(i=0;i<n;i++){
            A=a[n-i].index;
            B=a[n-i].b;
            C=k-a[n-i].b;
            a[n-i].b=0;
            D=a[0].index;
            a[0].b=a[0].b-C;
            printf("%d %d %d %d\n",A,B,D,C);
            quickSort(a, 0, n);
        }

    }
}
