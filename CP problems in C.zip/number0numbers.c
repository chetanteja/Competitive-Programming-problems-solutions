
// Sample code to perform I/O:
#include <stdio.h>

int main(){
	int num;
	scanf("%d", &num);              			// Reading input from STDIN
	while(num--){
		int n,i,x;
		scanf("%d",&n);
		int a[n];
		for(i=0;i<n;i++){
			scanf("%d",&a[i]);
		}
		scanf("%d",&x);
		x--;
		int y=0,c=0;
		for(i=0;i<n;i++){
			if(a[i]<y){
				c=1;
				y=a[i];
			}
			else{
				y=a[i];
				c++;
			}
			if(c==x){
                //printf("hel%d\n",y);
				break;
			}
		}
		//printf("%d\n",y);
		int min=1000000;
		while(i<n){
			if(a[i]>y&&a[i]<min){
				min=a[i];
			}
			i++;
		}
		printf("%d\n",min);


	}

	      // Writing output to STDOUT
}

// Warning: Printing unwanted or ill-formatted data to output will cause the test cases to fail

// Write your code here

