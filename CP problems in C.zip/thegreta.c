#include<stdio.h>

int main(){
    long long int t,i,n,A,B,check,x,y;
    scanf("%lld",&t);
    while(t--){
        check=0;x=0;y=0;
        scanf("%lld %lld %lld",&A,&B,&n);
        long long int a[n],b[n];
        for(i=0;i<n;i++){
            scanf("%lld",&a[i]);
        }
        for(i=0;i<n;i++){
            scanf("%lld",&b[i]);
        }
        long long c[n];
        x=b[i]/A;
        if(b[i]%A!=0){
            x++;
        }
        c[i]=x*a[i];
        min=c[i];y=0;
        for(i=1;i<n;i++){
            x=b[i]/A;
            if(b[i]%A!=0){
                x++;
            }
            c[i]=x*a[i];
            if(c[i]<min){
                min=c[i];
                y=i;
            }
        }


    }
}
