#include<stdio.h>

int main(){
    long long n,t,i,x;
    scanf("%lld",&t);
    while(t--){
        x=0;
        i=1;
        scanf("%lld",&n);
        while(i<=n){
            if(i==n){
                x=1;
                break;
            }
            i=i*2;
        }
        if(x==1){
            printf("NO\n");
        }
        else{
            printf("YES\n");
        }
    }
}
