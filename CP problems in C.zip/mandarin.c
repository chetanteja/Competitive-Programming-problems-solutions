#include<stdio.h>

int MIN(int *a,int l,int b){
    int i,x=0,min=1000000;
    for(i=l;i<=b;i++){
        x++;
        if(a[i]<min){
            min=a[i];
        }
    }
    return x*min;
}

int main(){
    int n,i;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++){

    }
}
