#include<stdio.h>

int main(){
    int t;
    scanf("%d",&t);
    while(t--){
        int n,i,x,j;
        scanf("%d",&n);
        int max=0,sum=0;
        int a[n+2];
        for(i=0;i<n+2;i++){
            scanf("%d",&a[i]);
            sum=sum+a[i];
            if(a[i]>max){
                max=a[i];
                j=i;
            }
        }
        n=n+2;
        x=sum-(2*max);
        int k,f=0;
        for(i=0;i<n;i++){
            if(a[i]==x&&i!=j){
                k=i;
                f=1;
            }
        }
        if(f==0){
            x=max;
        int k,f=0;
        int z=-1;
        for(i=0;i<n;i++){
            if(a[i]>z&&i!=j){
                z=a[i];
                k=i;
            }
        }
        if(sum-x==2*z){
            f=1;
        }
        }
        if(f==1){
            for(i=0;i<n;i++){
            if(i!=k&&i!=j){
                printf("%d ",a[i]);
            }
        }
        printf("\n");
        }
        else{
            printf("-1\n");
        }


    }
}
