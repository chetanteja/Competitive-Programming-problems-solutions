#include<stdio.h>
int main(){
    long long int i;
    char a[1000];
    scanf("%s",a);
    for(i=0;a[i]!='\0';i++){
        if(a[i]=='.'){
            break;
        }
        printf("%c",a[i]);
    }
}
