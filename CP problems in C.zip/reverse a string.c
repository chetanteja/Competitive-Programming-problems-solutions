#include<stdio.h>

int main(){
    int t,i=0;
    scanf("%d",&t);
    char s[100000];

    while(t--){
        scanf("%s",s);
        while(s[i]!='\0'){
            i++;
        }
        while(--i>=0){
            printf("%c",s[i]);
        }
    }
}
