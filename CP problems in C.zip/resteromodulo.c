#include<stdio.h>
#include<stdlib.h>
int main(){
    int t,n,i,x;
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        int a[n];
        for(i=0;i<n;i++){
            scanf("%d",&a[i]);
        }
        if(n<=2){
            printf("0\n");
            continue;
        }
        int b[n-1];
        int j=0,check=0;
        for(i=1;i<n;i++){
            b[j]=a[i]-a[i-1];
            if(b[j]!=0){
                check=1;
            }
           // printf("%d\n",c[i]);
           // printf("%d ",b[b[j]);
            j++;
        }
        if(check==0){
            printf("0\n");
            continue;
        }
        int c[n-2];
        j=0;
        check=0;
        for(i=1;i<n-1;i++){
            c[j]=abs(b[i]-b[i-1]);
            if(c[j]!=0){
                check=1;
            }
            j++;
        }
        if(check==0){
            printf("0\n");
            continue;
        }
        long long int min=1000000000000;
        check=0;
        x=c[0];
        for(i=0;i<n-2;i++){
            if(c[i]<min&&c[i]!=0){
                min=c[i];
            }
        }
        check=0;
        //printf("%lld\n",min);
        for(i=0;i<n;i++){
            if(a[i]>min){
                check=1;
                break;
            }
        }
        int che=a[1]-a[0];
        if(che<0){
            che=min+che;
        }
        if(che>=min){
            check=1;
        }
        if(check==0){
            printf("%lld %d\n",min,che);
        }
        else{
            printf("-1\n");
        }
    }
}
