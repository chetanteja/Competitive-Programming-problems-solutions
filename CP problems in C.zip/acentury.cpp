#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl

int main(){
    int t;
    cin>>t;
    int n=t/100;
    if(t%100!=0){
        n++;
    }
    cout<<n;
}
