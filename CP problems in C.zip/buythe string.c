#include<stdio.h>


int main(){
    int t,c0,c1,h,n,i;
    char x[100];
    scanf("%d",&t);
    if(t<1||t>10){
        return 0;
    }
    while(t--){
        scanf("%d",&n);
        if(n<1||n>1000){
            return 0;
        }
        scanf("%d",&c0);
        if(c0<1||c0>1000){
            return 0;
        }
        scanf("%d",&c1);
        if(c1<1||c1>1000){
            return 0;
        }
        scanf("%d",&h);
        if(h<1||h>1000){
            return 0;
        }
        int a[n];
        int n1=0,n2=0;
        scanf("%s",x);
        for(i=0;x[i]!='\0';i++){
            a[i]=(int)(x[i]-48);
            if(a[i]==0){
                n1++;
            }
            if(a[i]==1){
                n2++;
            }
        }
        int a1,a2,a3,min;
        a1=(n1*c0)+(n2*c1);
        a2=(n2*h)+(n*c0);
        a3=(n1*h)+(n*c1);
        if(a1<=a2&&a1<=a3){
            printf("%d\n",a1);
            continue;
        }
        if(a2<=a1&&a2<=a3){
            printf("%d\n",a2);
            continue;
        }
        if(a3<=a1&&a3<=a2){
            printf("%d\n",a3);
            continue;
        }
    }
}
