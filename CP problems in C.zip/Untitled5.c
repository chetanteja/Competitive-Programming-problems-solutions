#include<stdio.h>
int main(){
    int n,i,j,k=0,a[3][3],l=0,I,x;
    for(i=0;i<3;i++){
        for(j=0;j<3;j++){
            scanf("%d",&a[i][j]);
            t=a[i][j];
            if(a[i][j]<1||a[i][j]>100){
                return 0;
            }
        }
    }
    for(i=0;i<3;i++){
        for(j=0;j<3;j++){
            if(a[i][j]==)
            t=a[i][j];
        }
    }
    scanf("%d",&n);
    while(k<n)
    {
		k++;
        scanf("%d",&I);
        for(i=0;i<3;i++)
		{
            for(j=0;j<3;j++)
			{
                if(a[i][j]==I)
				{
                    a[i][j]=0;
                }
            }
        }
    }
    for(i=0;i<3;i++){
        x=0;
        for(j=0;j<3;j++){
            if(a[i][j]==0){
                x++;
            }
            else{
                break;
            }
        }
        if(x==3){
            printf("YES");
            return 0;
            l=1;
            break;
        }
    }


    for(i=0;i<3;i++){
        x=0;
        for(j=0;j<3;j++){
            if(a[j][i]==0){
                x++;
            }
            else{
                break;
            }
        }
        if(x==3){
            printf("Yes");
            return 0;
            l=1;
            break;
        }
    }
    if(a[0][0]==0&&a[1][1]==0&&a[2][2]==0){
        printf("Yes");
        return 0;
        l=1;
    }
    if(a[0][2]==0&&a[1][1]==0&&a[2][0]==0){
        printf("Yes");
        return 0;
        l=1;
    }
    if(l==0){
        printf("No");
        return 0;
    }

}
