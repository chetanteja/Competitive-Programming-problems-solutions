#include<stdio.h>

int main(){
    int t,n,sum,l,m,a,b,i,x;
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        int arr[n];
        for(i=0;i<n;i++){
            arr[i]=0;
        }
        for(i=0;i<n;i++){
            scanf("%d %d %d",&x,&a,&b);
            l=a;m=b-1;
            while(l<=m){
                if(x>arr[l]){
                    arr[l]=x;
                }
                l++;
            }
        }
        sum=0;
        for(i=0;i<n;i++){
            sum=sum+arr[i];
        }
        printf("%d\n",sum);
    }
}
