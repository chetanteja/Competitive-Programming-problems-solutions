#include<stdio.h>
#include<string.h>
int main(){
    int t,n,i,k,x;
    scanf("%d",&t);
    while(t--){
        scanf("%d %d",&n,&k);
        char a[n];
        char b[n];
        scanf("%s",a);
        for(i=0;i<n;i++){
            b[i]=a[n-i-1];
        }
        b[i]='\0';
        if(k==0){
            printf("YES\n");
            continue;
        }
        if(n==2*k){
            printf("NO\n");
            continue;
        }
        if(strcmp(a,b)==0){
            printf("YES\n");
        }
        else{
            printf("NO\n");
        }
    }
}
