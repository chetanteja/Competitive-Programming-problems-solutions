#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define gcd __gcd
#define line endl

int main(){
    string a;
    vector<char> v;
    cin>>a;
    int i;
    for ( i = a.size()-1; i >=0; i--)
    {
        /* code */
        if(a[i]=='9'){
            v.push_back('6');
        }
        else if(a[i]=='6'){
            v.push_back('9');
        }
        else{
            v.push_back(a[i]);
        }
    }
    for ( i = 0; i < v.size(); i++)
    {
        /* code */
        cout<<v[i];
    }
    
    
}