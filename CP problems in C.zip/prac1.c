#include<stdio.h>
#include<math.h>

int main(){
    long long t,i,j;
    long double area,s,a[3];
    scanf("%lld",&t);
    if(t<1||t>100000){
        return 0;
    }
    for(i=0;i<t;i++){
        for(j=0;j<3;j++){
            scanf("%Lf",&a[j]);
            if(a[j]<1||a[j]>10000000){
                return 0;
            }
        }
        if(a[0]+a[1]<a[2]){
            printf("NO\n");
            continue;
        }
        if(a[1]+a[2]<a[0]){
            printf("NO\n");
            continue;
        }
        if(a[2]+a[0]<a[1]){
            printf("NO\n");
            continue;
        }
        s=(a[0]+a[1]+a[2])/2;
        area=sqrt(s*(s-a[0])*(s-a[1])*(s-a[2]));
        printf("YES %.5Lf\n",area);
    }
}
