#include<stdio.h>
int main(){
    int t;
    long long int a,b,i,j,l,m;
    scanf("%d",&t);
    while(t--){
        scanf("%lld %lld",&a,&b);
        i=a/2;
        if(a%2==0){
            j=i;
        }
        else{
            j=i+1;
        }
        l=b/2;
        if(b%2==0){
            m=l;
        }
        else{
            m=l+1;
        }
        printf("%lld\n",(i*l)+(j*m));
    }
}
