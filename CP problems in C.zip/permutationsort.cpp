#include<bits/stdc++.h>
using namespace std;

int main(){
   int t;
   cin>>t;
   while(t--){
    int n,i,x;
    x=0;
    cin>>n;
    int a[n],b[n];
    for(i=0;i<n;i++){
        cin>>a[i];
        if(i!=0&&a[i]<a[i-1]){
            x=1;
        }
    }
    if(x==0){
        cout<<"0"<<endl;
        continue;
    }
    if(a[0]==1||a[n-1]==n){
        cout<<1<<endl;
        continue;
    }
    if(a[0]==n&&a[n-1]==1){
        cout<<3<<endl;
        continue;
    }
    else{
        cout<<2<<endl;
    }
   }
}


