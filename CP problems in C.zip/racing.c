#include<stdio.h>
long long int MIN(long long int a,long long int b){
    if(a<b){
        return a;
    }
    return b;
}
int main(){
    long long int t,n,x,r,m;
    scanf("%lld",&t);
    while(t--){
        scanf("%lld %lld %lld",&x,&r,&m);
        r=60*r;
        m=60*m;
        long long int i=MIN(x,r);
        if(x<r){
            i=i+(2*(r-x));
        }
        if(i<=m){
            printf("YES\n");
            continue;
        }
        printf("NO\n");
    }
}
