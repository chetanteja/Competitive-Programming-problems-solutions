#include<stdio.h>
int a1[10]={10,1,2,3,4,5,6,7,8,9};
int a2[10]={5,-1,1,-1,2,-1,3,-1,4};
int a3[10]={10,7,4,1,8,5,2,9,6,3};
int a4[10]={5,-1,3,-1,1,-1,4,-1,2,-1};
int a5[10]={2,-1,-1,-1,-1,1,-1,-1,-1,-1};
int a6[10]={5,-1,2,-1,4,-1,1,-1,3,-1};
int a7[10]={10,3,6,9,2,5,8,1,4,7};
int a8[10]={5,-1,4,-1,3,-1,2,-1,1,-1};
int a9[10]={10,9,8,7,6,5,4,3,2,1};
int main(){
    int t,n,i,d,l,x,m,N;
    scanf("%d",&t);
    while(t--){
        scanf("%d %d",&N,&d);
        for(i=0;i<N;i++){
            scanf("%d",&n);
            l=n%10;
        m=n/10;
        if(m>=d){
            printf("YES\n");
            continue;
        }
        if(n%d==0){
                printf("YES\n");
                continue;
        }
        if(d==1&&a1[l]!=-1){
            x=a1[l]*d;
            if(x>n){
                printf("NO\n");
            }
            else{
                printf("YES\n");
            }
            continue;
        }
        if(d==2&&a2[l]!=-1){
            x=a2[l]*d;
            if(x>n){
                printf("NO\n");
            }
            else{
                printf("YES\n");
            }
            continue;
        }
        if(d==3&&a3[l]!=-1){
            x=a3[l]*d;
            if(x>n){
                printf("NO\n");
            }
            else{
                printf("YES\n");
            }
            continue;
        }
        if(d==4&&a4[l]!=-1){
            x=a4[l]*d;
            if(x>n){
                printf("NO\n");
            }
            else{
                printf("YES\n");
            }
            continue;
        }
        if(d==5&&a5[l]!=-1){
            x=a5[l]*d;
            if(x>n){
                printf("NO\n");
            }
            else{
                printf("YES\n");
            }
            continue;
        }
        if(d==6&&a6[l]!=-1){
            x=a6[l]*d;
            if(x>n){
                printf("NO\n");
            }
            else{
                printf("YES\n");
            }
            continue;
        }
        if(d==7&&a7[l]!=-1){
            x=a7[l]*d;
            if(x>n){
                printf("NO\n");
            }
            else{
                printf("YES\n");
            }
            continue;
        }
        if(d==8&&a8[l]!=-1){
            x=a8[l]*d;
            if(x>n){
                printf("NO\n");
            }
            else{
                printf("YES\n");
            }
            continue;
        }
        if(d==9&&a9[l]!=-1){
            x=a9[l]*d;
            if(x>n){
                printf("NO\n");
            }
            else{
                printf("YES\n");
            }
            continue;
        }
        printf("NO\n");
        }
    }
}
