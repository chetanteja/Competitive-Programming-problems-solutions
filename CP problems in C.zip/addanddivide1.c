#include<stdio.h>
int main()
{
	long long int count,min;
	long long int t,ans;
	long long int a,b,B,A;
	scanf("%lld",&t);
	while(t--)
	{
		min=1000000;
		scanf("%lld%lld",&a,&b);
		B=b;
		A=a;
		if(b==1)
		{
			b=b+1;
		}
		while(1)
		{

			count=0;
			a=A;
			while(1)
			{
				if(a<=b)
				{
					break ;
				}
				a=a/b;
				count=count+1;

			}
			if(a==b)
			{
				count=count+2;
			}
			if(a<b)
			{
				count=count+1;
			}
			count=count+b-B;
			b=b+1;
			if(count<=min)
			{
				min=count;
			}
			if(count>min)
			{
				break ;
			}
		}
		printf("%lld\n",min);
	}
}
