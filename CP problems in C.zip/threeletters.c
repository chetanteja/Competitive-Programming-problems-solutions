#include<stdio.h>

int main(){
    int t,n,i,x,count;
    scanf("%d",&t);
    while(t--){
        count=0;
        int b[26];
        for(i=0;i<26;i++){
            b[i]=0;
        }
        char a[100000];
        scanf("%s",a);
        for(i=0;a[i]!='\0';i++){
            x=a[i]-'a';
            b[x]++;
        }
        n=i;
        for(i=0;i<26;i++){
            count=count+(b[i]/2);
        }
        printf("%d\n",count);
        if(count>(n/3)){
            printf("%d\n",n/3);
        }
        else{
            printf("%d\n",count);
        }
    }
}
