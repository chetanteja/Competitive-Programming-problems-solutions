    #include<stdio.h>
    #include<math.h>

    int main(){
        int t;
        scanf("%d",&t);
        double x=sqrt(t);
        if(x*x==t){
            printf("%d",(int)x);
        }
        else{
            printf("%d",(-1)*t);
        }
    }
