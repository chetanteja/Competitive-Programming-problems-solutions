#include<stdio.h>
#include<math.h>

int code(char a[],int n,int l,int r,int x){
    int i=x;
    if(l==r){
        return r;
    }
    if(a[i]=='1'){
        l=l+n;
        n=n/2;
    }
    if(a[i]=='0'){
        r=r-n;
        n=n/2;
    }
    i++;
    code(a,n,l,r,i);
}

int main(){
    int t,n,x,y,i,j,r,l;
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        x=n/4;
        char a[n];
        scanf("%s",a);
        for(i=0;i<x;i++){
            printf("%c",code(a,8,0,15,(4*i))+97);
        }
        printf("\n");
    }
}
