#include<stdio.h>

int main(){
    int a,b,c,k;
    scanf("%d %d %d %d",&a,&b,&c,&k);
    if(a>=k){
        printf("%d",k);
        return 0;
    }
    if(a<k){
        k=k-a;
        if(b<k){
            k=k-b;
            if(k>0){
                printf("%d",a-k);
                return 0;
            }
        }
    }
    printf("%d",a);

}
