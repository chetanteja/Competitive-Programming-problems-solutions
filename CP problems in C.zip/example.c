#include<stdio.h>

int main(){
    int n,t1,t2,t3,i=0;
    scanf("%d %d %d %d",&n,&t1,&t2,&t3);
    int a[n],ans[5];
    ans[0]=0;ans[1]=0;ans[2]=0;ans[3]=0;ans[4]=0;
    i=n-1;
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
        char c[1000];
        while(a[i]--){
            scanf("%s",c);
        }
        //printf("hello\n");
    }
    if(2*t1>n){
        if(n%2!=0){
            ans[2]=(n-1)/2;
            ans[2]--;
            ans[3]++;
            n=n-(2*ans[2])-(3*ans[3]);
        }
        else{
            ans[2]=n/2;
            n=n-(2*ans[2]);
        }
    }
    else{
        ans[2]=t1;
        n=n-(2*t1);
        //printf("%d n\n",n);
        if(3*t2>n){
        if(n%3!=0){
            if(n-1%3==0){
                ans[4]++;
                n=n-4;
                ans[3]=ans[3]+n/3;
                n=n-(3*ans[3]);
            }
            if(n%3==2){
                ans[2]--;
                ans[4]++;
                n=n-2;
                ans[3]=n/3;
                n=n-(3*ans[3]);
            }
        }
        else{
            ans[3]=n/3;
            n=n-(3*ans[3]);
        }
    }
    else{
        ans[3]=t2;
        //printf("%d n\n",n);
        n=n-(3*ans[3]);
        //printf("%d n\n",n);
            if(n%4!=0){
            if(n%4==1){
                   // printf("hello\n");
                ans[3]--;
                n=n+3;
                ans[4]=n/4;
                n=n-(4*ans[4]);
            }
            if(n%4==2){
                ans[2]--;
                n=n+2;
                ans[4]=n/4;
                n=n-(4*ans[4]);
            }
            if(n%4==3){
                ans[2]--;
                ans[3]--;
                n=n+5;
                ans[4]=n/4;
                n=n-(4*ans[4]);
            }
            }
            else{
                ans[4]=n/4;
                n=n-ans[4]*4;
            }
    }

    }
   // printf("%d %d %d\n",ans[2],ans[3],ans[4]);
    if(ans[4]>t3){
        ans[4]=t3;
        ans[2]=t1;
        ans[3]=t2;
    }
    int j=0;
    printf("%d\n",ans[2]+ans[3]+ans[4]);
    //printf("%d %d %d\n",ans[2],ans[3],ans[4]);
        while(ans[2]--){
            printf("2 ");
            printf("%d %d\n",j,j+1);
            j+=2;
        }
        while(ans[3]--){
            printf("3 ");
            printf("%d %d %d\n",j,j+1,j+2);
            j+=3;
        }
        while(ans[4]--){
            printf("4 ");
            printf("%d %d %d %d\n",j,j+1,j+2,j+3);
            j+=4;
        }

}

