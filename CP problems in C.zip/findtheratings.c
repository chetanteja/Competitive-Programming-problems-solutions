#include<stdio.h>

int main(){
    int n,k,ans;
    scanf("%d",&n);
    scanf("%d",&k);
    if(n<1||n>100||k<0||k>4111){
        return 0;
    }
    if(n<10){
        ans=k+(100*(10-n));
    }
    else{
        ans=k;
    }
    printf("%d",ans);
    return 0;
}
