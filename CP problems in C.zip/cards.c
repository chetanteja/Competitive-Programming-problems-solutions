#include<stdio.h>
int main()
{
	int t,n,i,j,flag,z,temp;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		int a[n],b[n];
		j=0;
		b[j]=0;
		flag=0;
		for(i=0;i<n;i++)
		{
			scanf("%d",&a[i]);
			if(i!=0)
			{

				if(a[i]>a[i-1]&&a[b[j]]<a[i])
				{
					j=j+1;
					b[j]=i;

				}
			}
		}

			for(i=j;i>=0;i--)
			{
				if(i==j)
				{
					for(z=b[i];z<n;z++)
					{
						printf("%d ",a[z]);
					}
				}
				else
				{
					for(z=b[i];z<b[i+1];z++)
					{
						printf("%d ",a[z]);
					}
				}
			}
			printf("\n");
	}
}
