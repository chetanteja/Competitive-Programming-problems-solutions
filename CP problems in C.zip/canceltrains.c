#include<stdio.h>

int main(){
    int i,t,count,m,n;
    scanf("%d",&t);
    if(t<1||t>100){
        return 0;
    }
    while(t--){
        count=0;
        scanf("%d %d",&m,&n);
        int a[100];
        for(i=0;i<100;i++){
            a[i]=0;
        }
        for(i=0;i<m;i++){
            int l;
            scanf("%d",&l);
            if(l<1||l>100){
                return 0;
            }
            a[--l]=1;
        }
        int b[100];
        for(i=0;i<100;i++){
            b[i]=0;
        }
         for(i=0;i<n;i++){
            int l;
            scanf("%d",&l);
            if(l<1||l>100){
                return 0;
            }
            b[--l]=1;
        }
        for(i=0;i<100;i++){
            if(a[i]==1&&b[i]==1){
                count++;
            }
        }
        printf("%d\n",count);
    }
}
