#include<stdio.h>

int main(){
    long long int t,n,x,y,i;
    scanf("%lld",&t);
    if(t<1||t>1000){
        return 0;
    }
    while(t--){
        scanf("%lld",&n);
        if(n<1||n>1000){
            return 0;
        }
        x=0;y=0;
        long long int a[n];
        for(i=0;i<n;i++){
            scanf("%lld",&a[i]);
            if(a[i]<0||a[i]>1000000000){
                return 0;
            }
            if(a[i]%2==0){
                x++;
            }
            else{
                y++;
            }
        }
        if(n==1){
            printf("0\n");
            continue;
        }
        if(x==0||y==0){
            printf("%lld\n",n);
            continue;
        }
        if(x>y){
            printf("%lld\n",n-2+y);
        }
        else{
            printf("%lld\n",n-2+x);
        }
    }
}
