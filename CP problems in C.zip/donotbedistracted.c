#include<stdio.h>
int a[26];
int main(){
    int t;
    scanf("%d",&t);
    while (t--)
    {
        /* code */
        int n,x,i,y,check=0;
        scanf("%d",&n);
        for ( i = 0; i < 26; i++)
        {
            /* code */
            a[i]=0;
        }
        
        char b[n];
        scanf("%s",b);
        for ( i = 0; b[i]!='\0'; i++)
        {
            /* code */
            y=(int)b[i]-'A';
            if(x!=y&&a[y]!=0){
                check=1;
            }
            else{
                a[y]=1;
                x=y;
            }
        }
        if(check==0){
            printf("YES\n");
        }
        else{
            printf("NO\n");
        }
    }
    
}