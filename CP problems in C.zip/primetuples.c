#include<stdio.h>

int main(){
    int t,n,i,ans;
    int p[4];
    p=
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        i=0;
        while(n>p[i]){
            i++;
            if(p[i]+2==p[i+1]){
                ans++;
            }
        }
        printf("%d\n",ans);
    }
}
