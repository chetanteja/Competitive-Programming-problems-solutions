#include<stdio.h>

int main(){
    int t,n,i,j,count,x;
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        int a[n],b[49];
        count=0,x=0;
        scanf("%d",&a[0]);
        for(i=1;i<n;i++){
            scanf("%d",&a[i]);
        }
        for(i=0;i<49;i++){
            b[i]=0;
        }
        for(i=0;i<n;i++){
            for(j=i+1;j<n;j++){
                x=a[j]-a[i];
                b[x-1]=1;
            }
        }
        for(i=0;i<49;i++){
            if(b[i]==1){
                count++;
            }
        }
        printf("%d\n",count);
    }
}
