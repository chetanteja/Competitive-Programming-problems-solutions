#include<stdio.h>

int main(){
    int t;
    scanf("%d",&t);
    while(t--){
        int n,i,j,x[2],y[2],z=0;
        scanf("%d",&n);
        char a[n];
        for(i=0;i<n;i++){
            scanf("%s",a);
            for(j=0;j<n;j++){
                if(a[j]=='*'){
                    x[z]=i;
                    y[z]=j;
                    z++;
                    //printf("%d %d\n",i,j);
                }
            }
        }
        //printf("hhe\n");
        //printf("%d %d %d %d\n",x[0],x[1],y[0],y[1]);
        int x1=x[0],x2=x[1],y1=y[0],y2=y[1];
        if(x2==x1){
			int b=n-x2-1;
			if(b>0){
				x2++;
			}
			else{
				x2--;
			}
		}
		if(y1==y2){
			int b=n-y2-1;
			if(b>0){
				y2++;
			}
			else{
				y2--;
			}
		}
        //printf("%d %d %d %d\n",x1,x2,y1,y2);
        int a1,a2,b1,b2;
        a1=x1;
        b1=y2;
        a2=x2;
        b2=y1;
        for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				if(i==x1&&j==y1){
					printf("*");
				}
				else if(i==a2&&j==b2){
					printf("*");
				}
				else if(i==a1&&j==b1){
					printf("*");
				}
				else if(i==x2&&j==y2){
					printf("*");
				}
				else{
					printf(".");
				}
			}
			printf("\n");
		}
    }
}

