#include<stdio.h>

int main(){
    long long int t,n,k,x;
    scanf("%lld",&t);
    while(t--){
        scanf("%lld %lld",&n,&k);
        if(n<=k){
            x=k/n;
            if(k%n!=0){
                x++;
            }
            printf("%lld\n",x);
        }
        else{
            if(n%k==0){
                printf("1\n");
            }
            else{
                printf("2\n");
            }
        }
    }
}
