#include<stdio.h>

int main(){
    int a,b,c,n;
    scanf("%d %d %d %d",&a,&b,&c,&n);
     if(a<0||a>10||b<0||b>10||c<0||c>10||n<1||n>20){
        return 0;
     }
     if(a<1||b<1||c<1||n<3||a+b+c<n){
        printf("NO");
        return 0;
     }
     printf("YES");
     return 0;
}
