#include<stdio.h>
long long int a1,b1;
long long int HCF(long long int a,long long int b)
{
    if (a == 0)
        return b;
    return HCF(b % a, a);
}

// Function to return LCM of two numbers
long long int LCM(long long int a,long long int b)
{
    return (a / HCF(a, b)) * b;
}

void factor(long long int a){
    long long int i,x,min=a+2,sum;
    if(a==1){
        a1=1;b1=1;
        return ;
    }
    for(i=1;i<=a/2;i++){
        if(a%i==0){
            x=a/i;
            sum=x+i;
            if(HCF(x,i)==1&&LCM(x,i)==a){
                if(sum<min){
                    min=sum;
                    a1=i;
                    b1=x;
                }
            }
        }
    }
}

int main(){
    long long int t,sum;
    long long int x,k;
    scanf("%lld",&t);
    if(t<1||t>40){
        return 0;
    }
    while(t--){
        scanf("%lld %lld",&k,&x);
        if(k<2||k>1000000||x<2||x>1000000){
            return 0;
        }
        k--;
        sum=0;
        while(k--){
            factor(x);
            x=a1;
            sum=sum+b1;
        }
        sum=sum+a1;
        printf("%lld\n",sum);
    }
}
