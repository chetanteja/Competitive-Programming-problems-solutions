#include<stdio.h>
#include<string.h>
int main(){
    int t,n,i,count,x,y;
    scanf("%d",&t);
    char a[100];
    while(t--){
        int q=0;
        scanf("%s",a);
        n=strlen(a);
        for(i=0;i<n;i++){
            if(a[i]=='?'){
                q++;
            }
        }
        if(a[0]==')'||a[n-1]=='('||q%2!=0){
            printf("NO\n");
        }
        else{
            printf("YES\n");
        }
    }
}
