#include<stdio.h>
#include<math.h>
 
int CUBE(long long int x){
    int check=0,i=1,j=1;
    while(!check&&pow(i,3)<x){
        j=1;
        while(pow(j,3)<x){
            if((pow(i,3)+pow(j,3))==x){
                check=1;
            }
            //printf("%d %d %d\n",i,j,check);
            j++;
        }
        i++;
    }
    return check;
}

int main(){
    int t,i;
    long long int n;
    scanf("%d",&t);
    while(t--){
        scanf("%lld",&n);
        if(CUBE(n)){
            printf("YES\n");
        }
        else{
            printf("NO\n");
        }

    }
}