#include<stdio.h>

int main(){
    int t;
    scanf("%d",&t);
    while(t--){
        long long int n,i=0,x;
        scanf("%lld",&n);
        if(n%2050!=0){
            printf("-1\n");
            continue;
        }
        x=n/2050;
        while(x!=0){
            i=i+(x%10);
            x=x/10;
        }
        printf("%d\n",i);
    }
}