#include<stdio.h>
#include<stdlib.h>

int cmpfunc (const void * a, const void * b) {
   return ( *(int*)a - *(int*)b );
}

int main(){
    long long int n,i,j=0,k;
    scanf("%lld",&n);
    int a[n];
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    qsort(a, n, sizeof(int), cmpfunc);
    for(i=1;i<n;i++){
        //printf("%d ",a[i]);
        j=j+a[i]-a[0];
    }
    printf("%lld\n",j);
}
