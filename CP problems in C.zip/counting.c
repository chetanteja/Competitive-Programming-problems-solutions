#include<stdio.h>

int main(){
    int x,k;
    scanf("%d %d",&k,&x);
    if(k*500>=x){
        printf("Yes");
        return 0;
    }
    printf("No");
}
